"""Integridad de política permanente ADHD en Codex v18 y actualización conservadora."""
import hashlib
import importlib.util
import re
import shutil
import tempfile
import tomllib
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILLS = ROOT/'.agents/skills'
ROLES = ('research', 'plan', 'create', 'debug', 'test', 'review', 'refactor', 'docs', 'skill-creator', 'quality-gate')


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


installer = module(ROOT/'scripts/install.py','codex_adhd_v18_installer')
validator = module(ROOT/'scripts/validate.py','codex_adhd_v18_validator')


class ADHDAlwaysOnV18(unittest.TestCase):
    def test_policy_is_auto_injected_in_root_not_manual_skill_only(self):
        s=(ROOT/'AGENTS.md').read_text()
        self.assertIn('I Have ADHD siempre activo',s)
        self.assertIn('sin `$i-have-adhd`',s)
        self.assertIn('10)',s)
        self.assertIn('No',s)
        self.assertIn('normal mode',s)
        self.assertLessEqual(len(s.split()),300)
        self.assertIn('adhd-always-on.md',s)

    def test_policy_has_ten_output_rules_and_all_role_profiles(self):
        s=(SKILLS/'_shared/adhd-always-on.md').read_text()
        for n in range(1,11):
            self.assertRegex(s, rf'(?m)^{n}\. \*\*')
        for role in ROLES:
            self.assertIn('`'+role+'`',s)
        self.assertIn('no asumir',s.lower())
        self.assertIn('Ponytail',s)
        self.assertIn('Quality Gate',s)
        self.assertIn('No añadir agentes ni hooks',s)

    def test_roles_have_distinct_contracts_and_no_public_output_limits(self):
        specifics=set()
        for role in ROLES:
            data=tomllib.loads((ROOT/'.codex/agents'/f'{role}.toml').read_text())
            instr=data['developer_instructions']
            self.assertIn('Perfil I Have ADHD (operativo, siempre activo)',instr)
            self.assertIn('No apliques formato público',instr)
            self.assertIn('status success|partial|blocked',instr)
            self.assertIn('quality_gate',instr)
            self.assertIn(f'.agents/skills/{role}/SKILL.md',instr)
            specifics.add(instr.split('Perfil I Have ADHD (operativo, siempre activo): ')[1].split(' No apliques')[0])
            self.assertNotIn('Lee .agents/skills/i-have-adhd/SKILL.md',instr)
        self.assertEqual(len(specifics),10)

    def test_quality_and_review_and_test_are_not_compressed(self):
        for role in ('test','review','quality-gate'):
            instr=tomllib.loads((ROOT/'.codex/agents'/f'{role}.toml').read_text())['developer_instructions']
            self.assertIn('conserva todas las evidencias',instr)
        self.assertIn('no limitar suites',tomllib.loads((ROOT/'.codex/agents/test.toml').read_text())['developer_instructions'])
        self.assertIn('nunca limitar número de hallazgos',tomllib.loads((ROOT/'.codex/agents/review.toml').read_text())['developer_instructions'])
        self.assertIn('runner exacto',tomllib.loads((ROOT/'.codex/agents/quality-gate.toml').read_text())['developer_instructions'])

    def test_original_skill_and_manual_invocation_still_available(self):
        s=(SKILLS/'i-have-adhd/SKILL.md').read_text()
        self.assertIn('name: i-have-adhd',s)
        self.assertIn('disable-model-invocation: true',s)
        self.assertIn('### 10. No preamble',s)
        self.assertIn('without manual invocation',s)
        self.assertTrue((SKILLS/'i-have-adhd/LICENSE').is_file())
        self.assertTrue((SKILLS/'i-have-adhd/agents/openai.yaml').is_file())

    def test_no_mcp_or_model_or_hook_changed_from_package_contract(self):
        config=tomllib.loads((ROOT/'.codex/config.toml').read_text())
        self.assertEqual((config['model'],config['model_reasoning_effort']),('gpt-6-astra','medium'))
        self.assertEqual(set(config['mcp_servers']),{'context7','engram','playwright'})
        self.assertEqual(len(list((ROOT/'.codex/agents').glob('*.toml'))),10)
        self.assertFalse((ROOT/'.codex/hooks').exists())
        self.assertFalse((ROOT/'hooks').exists())
        self.assertFalse((SKILLS/'concise-output').exists())

    def test_fresh_install_is_always_on_without_command(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            installer.install(d)
            self.assertEqual(validator.validate(d),[])
            self.assertIn('I Have ADHD siempre activo',(d/'AGENTS.md').read_text())
            self.assertTrue((d/'.agents/skills/_shared/adhd-always-on.md').is_file())
            self.assertEqual(len(list((d/'.codex/agents').glob('*.toml'))),10)

    def test_upgrade_from_old_managed_block_preserves_outside_content(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            legacy='PREFACIO PRIVADO\n\n<!-- agent-teams-basic:start -->\n# antiguo estilo opt-in\n<!-- agent-teams-basic:end -->\n\nMI SECCIÓN FINAL\n'
            (d/'AGENTS.md').write_text(legacy)
            # Instalar primero sin forzar: mantener bloque del usuario y señalar conflicto.
            logs=installer.install(d,force=False)
            self.assertTrue(any('CONFLICTO AGENTS.md' in x for x in logs))
            self.assertEqual((d/'AGENTS.md').read_text(),legacy)
            # Migración explícita: reemplazar solo el bloque gestionado; respaldo.
            logs=installer.install(d,force=True)
            self.assertTrue(any('ACTUALIZAR bloque gestionado' in x for x in logs))
            self.assertEqual(validator.validate(d),[])
            s=(d/'AGENTS.md').read_text()
            self.assertTrue(s.startswith('PREFACIO PRIVADO\n\n'))
            self.assertTrue(s.endswith('\n\nMI SECCIÓN FINAL\n'))
            self.assertIn('I Have ADHD siempre activo',s)
            self.assertEqual(len(list(d.glob('AGENTS.md.bak.*'))),1)
            self.assertEqual(next(d.glob('AGENTS.md.bak.*')).read_text(),legacy)

    def test_upgrade_existing_agent_requires_force_and_creates_backup(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            installer.install(d)
            f=d/'.codex/agents/create.toml'
            old=f.read_text().replace('Perfil I Have ADHD (operativo, siempre activo)', 'Perfil LEGADO (opt-in)')
            f.write_text(old)
            before=hashlib.sha256(old.encode()).hexdigest()
            logs=installer.install(d,force=False)
            self.assertTrue(any('CONFLICTO' in x and 'create.toml' in x for x in logs))
            self.assertEqual(hashlib.sha256(f.read_bytes()).hexdigest(),before)
            logs=installer.install(d,force=True)
            self.assertIn('Perfil I Have ADHD (operativo, siempre activo)',f.read_text())
            self.assertTrue(list(f.parent.glob('create.toml.bak.*')))
            self.assertEqual(validator.validate(d),[])

    def test_dry_run_is_read_only(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            (d/'AGENTS.md').write_text('texto usuario\n')
            logs=installer.install(d,force=True,dry_run=True)
            self.assertTrue(any('AÑADIR bloque' in x for x in logs))
            self.assertEqual([x.name for x in d.iterdir()],['AGENTS.md'])
            self.assertEqual((d/'AGENTS.md').read_text(),'texto usuario\n')

    def test_repeated_install_does_not_duplicate_or_back_up_again(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            installer.install(d,force=True)
            a=(d/'AGENTS.md').read_text()
            logs=installer.install(d,force=True)
            self.assertEqual(a,(d/'AGENTS.md').read_text())
            self.assertEqual(a.count('I Have ADHD siempre activo'),1)
            self.assertEqual(len(list(d.glob('AGENTS.md.bak.*'))),0)
            self.assertEqual(validator.validate(d),[])

    def test_validator_rejects_missing_activation_and_role(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            installer.install(d)
            root=d/'AGENTS.md'
            s=root.read_text().replace('I Have ADHD siempre activo','estilo opcional')
            root.write_text(s)
            self.assertTrue(any('no activa I Have ADHD' in x for x in validator.validate(d)))
            root.write_text((ROOT/'AGENTS.md').read_text())
            agent=d/'.codex/agents/test.toml'
            agent.write_text(agent.read_text().replace('Perfil I Have ADHD (operativo, siempre activo)','Perfil ausente'))
            self.assertTrue(any('Falta perfil ADHD operativo en test' in x for x in validator.validate(d)))

    def test_custom_mcp_and_external_agents_content_survive_install(self):
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            installer.install(d)
            conf=d/'.codex/config.toml'
            conf.write_text(conf.read_text()+'\n[mcp_servers.custom]\ncommand = "custom-exec"\n')
            installer.install(d,force=True)
            self.assertIn('[mcp_servers.custom]',conf.read_text())
            self.assertEqual(validator.validate(d),[])


if __name__ == '__main__':
    unittest.main()
