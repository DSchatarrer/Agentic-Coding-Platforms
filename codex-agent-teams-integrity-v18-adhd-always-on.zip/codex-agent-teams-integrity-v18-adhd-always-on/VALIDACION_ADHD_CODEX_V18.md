# Validación ADHD Codex v18

## Resultado sobre paquete v18

- **124/124 pruebas unitarias superadas**, incluidas 13 pruebas específicas de política siempre activa.
- `scripts/validate.py --project-root .`: OK (10 agentes, 11 skills, configuración y enlaces).
- `scripts/audit_integrity.py --project-root . --source`: OK (70 documentos Markdown, 206 enlaces locales, 23 comandos Python, 10 roles).
- `build_registry.py --project-root . --check`: OK (11 skills descubiertas y cinco convenciones, sin ampliar el registro de estándares).

## Actualización real v17 → v18

Instalación previa efectuada con `scripts/install.py` del **ZIP Codex v17**; luego simulación `--force --dry-run` y actualización real `--force` con el instalador v18. Resultado: PASS.

- `--dry-run` sin cambios de bytes.
- Diez perfiles de agente actualizados con copias `.bak.*`; `AGENTS.md` respaldado con personalizaciones externas preservadas.
- MCP adicional personalizado conservado; los MCP conocidos y los modelos conservan sus contratos.
- Validación de instalación resultante: cero errores.
- Segunda instalación `--force` idempotente (sin reescrituras adicionales).

## Límites

Esta batería valida **estructura, instalación, preservación y coherencia documental**, no demuestra el cumplimiento efectivo de un modelo conversando en Codex. Para verificarlo, inicia una sesión nueva del proyecto, no invoques `$i-have-adhd` y solicita una tarea de varios pasos; inspecciona los handoffs de `test`, `review` y `quality-gate` sin perder evidencias.
