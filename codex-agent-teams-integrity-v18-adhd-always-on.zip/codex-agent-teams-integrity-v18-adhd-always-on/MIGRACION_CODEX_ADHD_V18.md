# Migración Codex Agent Teams v17 → v18: I Have ADHD siempre activo

## Cambio funcional

`i-have-adhd` pasa de ser una **skill opt-in** a una **política del proyecto**: las diez reglas de salida al usuario son instrucciones explícitas y resumidas dentro de `AGENTS.md`, que Codex carga al trabajar en el proyecto. La skill original continúa disponible, pero **no necesitas invocar `$i-have-adhd`**. Política extensa: `.agents/skills/_shared/adhd-always-on.md`.

Los diez subagentes obtienen solo sus **hábitos operativos por rol** en `developer_instructions` de `.codex/agents/<rol>.toml`. No heredan límites de presentación ni sacrifican evidencias, cobertura, revisión o Quality Gate.

No se modifican la selección de modelos, `.codex/config.toml`, Ponytail, Engram, Context7, Playwright, estándares aprobados o número de agentes. No se incorporan hooks ni plugins globales. La activación se limita al proyecto instalado; no convierte Codex entero en un modo global.

## Instalar desde PowerShell (directorio del ZIP extraído)

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto" --force --dry-run
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto" --force
```

Usa `--force` tras **revisar el dry-run**: permite actualizar las instrucciones de agentes ya presentes, crea copias `.bak.<fecha>` y reemplaza únicamente el bloque entre `<!-- agent-teams-basic:start -->` / `<!-- agent-teams-basic:end -->` de `AGENTS.md`; el resto se conserva. Si ya tienes instrucciones contradictorias fuera del bloque, deberás resolverlas manualmente. Sin `--force`, los archivos personalizados quedan sin actualizar. **No uses `--no-agents-md`**: impediría la activación permanente.

`--force` afecta a otras piezas gestionadas por el instalador (scripts, skills y perfiles); no sobrescribe a ciegas archivos ajenos fuera de sus destinos conocidos. El instalador continúa retirando `concise-output` solo si coincide exactamente con la v16, manteniendo cualquier personalización.

## Verificar

```powershell
py -3 scripts/validate.py --project-root "C:\ruta\a\mi-proyecto"
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root "C:\ruta\a\mi-proyecto" --check
```

Reinicia Codex abriendo una sesión nueva **dentro del proyecto**; pide una tarea de varios pasos **sin** `$i-have-adhd`. Comprueba respuesta pública orientada a acción/estado y que los handoffs de `test`, `review` y `quality-gate` retienen evidencias completas. Un comando de verificación puede comprobar la configuración, **no certificar** el cumplimiento del modelo en vivo.

## Límites y precedencia

1. Una petición expresa del usuario de otro estilo o una explicación exhaustiva prevalece en esa sesión; el proyecto vuelve a la política por defecto en una sesión nueva.
2. Seguridad, instrucciones de prioridad superior, requisitos y formatos del usuario, JSON/código, pruebas, logs y contratos técnicos prevalecen sobre presentación.
3. Esta adaptación no garantiza cumplimiento literal de la IA ni que todas las herramientas de Codex implementen idéntica carga de contexto; la prueba conductual real queda pendiente.
