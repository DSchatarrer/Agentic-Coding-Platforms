# Catálogo descubierto automáticamente

> Inventario informativo del proyecto, **no son estándares aprobados**. Actualiza con `python .agents/skills/skill-creator/scripts/build_registry.py --project-root .`. Las reglas aprobadas están en `project-skill-registry.md`.

| Skill | Cuándo usarla (metadatos) | SKILL.md |
|---|---|---|
| `create` | Implementa cambios concretos; usa cuando haya que crear código o módulos. | `.agents/skills/create/SKILL.md` |
| `debug` | Reproduce y corrige fallos; usa cuando hay un error que investigar. | `.agents/skills/debug/SKILL.md` |
| `docs` | Actualiza documentación; usa cuando la funcionalidad cambia o se pide documentar. | `.agents/skills/docs/SKILL.md` |
| `i-have-adhd` | Shape output for a reader with ADHD: lead with the next action, number multi-step work, restate state across turns, suppress tangents, give specific time estimates, make wins visib | `.agents/skills/i-have-adhd/SKILL.md` |
| `plan` | Planifica cambios complejos, arquitectura y dependencias; usa también para crear, auditar, continuar, actualizar o replanificar TODO.md con evidencias, sin implementar código. | `.agents/skills/plan/SKILL.md` |
| `quality-gate` | Verifica evidencias y bloquea entregas; usa al cerrar cambios de código. | `.agents/skills/quality-gate/SKILL.md` |
| `refactor` | Mejora diseño sin cambiar comportamiento; usa cuando un refactor está justificado. | `.agents/skills/refactor/SKILL.md` |
| `research` | Investiga código y documentación sin editar; usa cuando se necesite evidencia técnica. | `.agents/skills/research/SKILL.md` |
| `review` | Audita código sin editar; usa para riesgos, seguridad y regresiones. | `.agents/skills/review/SKILL.md` |
| `skill-creator` | Crea y valida skills; usa cuando se soliciten nuevas skills o agentes. | `.agents/skills/skill-creator/SKILL.md` |
| `test` | Diseña y ejecuta tests; usa cuando hay nuevos contratos o cobertura insuficiente. | `.agents/skills/test/SKILL.md` |

### Propuestas de reglas (revisión manual obligatoria)

Ninguna skill contiene una sección explícita `## Compact Rules` / `## Reglas compactas` de la que puedan extraerse reglas literalmente. No se han inventado resúmenes.

### Convenciones detectadas

| Archivo | Motivo |
|---|---|
| `.agents/skills/_shared/adhd-always-on.md` | Referencia directa de AGENTS.md |
| `.agents/skills/_shared/handoff.md` | Referencia directa de AGENTS.md |
| `.agents/skills/_shared/project-skill-registry.md` | Referencia directa de AGENTS.md |
| `.agents/skills/_shared/skill-resolver.md` | Referencia directa de AGENTS.md |
| `AGENTS.md` | Convención del proyecto |
