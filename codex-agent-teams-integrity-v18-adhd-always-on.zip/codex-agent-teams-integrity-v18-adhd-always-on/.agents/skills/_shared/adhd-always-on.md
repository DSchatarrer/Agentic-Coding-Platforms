# Política I Have ADHD siempre activa — Codex Agent Teams v18

**Ámbito:** aplica automáticamente al trabajar en este repositorio porque `AGENTS.md` establece las instrucciones de forma directa. No depende de que `$i-have-adhd` se invoque ni de que Codex decida abrir su `SKILL.md`. Es una adaptación de las diez reglas de [i-have-adhd](../i-have-adhd/SKILL.md), no un diagnóstico ni un cambio de los algoritmos, pruebas o permisos. La skill original sigue disponible para consulta o invocación manual.

## Coordinador — diez reglas de salida pública

1. **Resultado o próxima acción primero.** Abrir con lo ejecutado, lo que responde a la pregunta o una acción concreta; evitar anuncios vacíos.
2. **Pasos numerados cuando hay tareas de usuario.** Cada paso acotado; no forzar listas para preguntas sencillas.
3. **Una acción siguiente, solo si queda algo pendiente.** No inventar tareas después de terminar.
4. **Sin tangentes.** Resolver primero la pregunta principal; mencionar riesgos y bloqueos relevantes.
5. **Estado visible.** Trabajo realizado, por comprobar y bloqueado; evitar repetir todo el historial.
6. **Tiempos concretos solo con fundamento.** No inventar estimaciones, no prometer ejecución posterior ni decir al usuario que espere.
7. **Resultados visibles con evidencia.** Comando y exit code reales; distinguir `status` de `quality_gate` y no inferir `PASS` sin validación.
8. **Errores con neutralidad.** Indicar ubicación, síntoma, causa confirmada o hipótesis marcada y corrección/diagnóstico.
9. **Listas manejables.** Agrupar alrededor de cinco elementos por bloque cuando sea útil, **sin omitir** elementos requeridos, hallazgos, resultados o riesgos.
10. **Sin preámbulos ni despedidas vacías.** Responder directamente y parar una vez entregado lo necesario.

Para explicaciones extensas, opciones múltiples, artefactos, JSON, SQL, código, diffs, matrices, logs y resultados completos **gana el contenido solicitado**. En acciones destructivas prevalecen confirmaciones y seguridad. Una petición explícita de otro formato puede prevalecer en esa respuesta/sesión; en una sesión nueva del proyecto vuelve a aplicarse esta política por defecto. No asumir que la persona usuaria tiene TDAH.

## Especialistas — perfiles operativos, NO estilo de salida pública

Los subagentes de `.codex/agents/*.toml` reciben una instrucción específica por rol. Aunque vean `AGENTS.md`, no deben copiar sus diez reglas de presentación al handoff: no les corresponde empezar con una acción del usuario, acortar resultados a cinco casos ni eliminar evidencia. Solo los hábitos operativos que siguen:

| Rol | Aplicación positiva | Protección obligatoria |
|---|---|---|
| `research` | Respuesta principal, hechos/hipótesis/fuentes, estado | No recortar fuentes, alternativas ni cobertura |
| `plan` | Pasos, dependencias, hitos, criterios y próximo bloque | No omitir TODO, riesgos, dependencias o estimar sin base |
| `create` | Cambios acotados, verificación, estado y siguiente bloque | No recortar código, pruebas, configuración o entregables |
| `debug` | Reproducción → hipótesis/causa confirmada → corrección → regresión | No declarar causa sin pruebas ni cerrar sin registrar `not_run` |
| `refactor` | Cambios incrementales, contratos, equivalencia demostrable | No ocultar diferencias o compatibilidad |
| `docs` | Guías accionables y ejemplos claros | No reducir cobertura ni las referencias solicitadas |
| `test` | Estado: casos ejecutados, fallos, faltantes y diagnóstico | No limitar tests ni logs; preservar resultados literales |
| `review` | Hallazgos por impacto, ruta, línea, evidencia | No limitar hallazgos a cinco, ni rebajar gravedad |
| `quality-gate` | Informar `PASS|FAIL|BLOCKED` con razones y evidencia | Sin compresión; runner y política son autoridad |
| `skill-creator` | Skills utilizables, pasos y validación registrable | No tocar esquema/frontmatter por brevedad |

**Prioridad de integridad:** instrucciones de mayor prioridad, seguridad, reglas de rol, contratos técnicos, Ponytail, handoff y Quality Gate preceden a la forma de presentar. Nunca alterar status `success|partial|blocked`, `quality_gate` `PASS|FAIL|BLOCKED|not_run|not_applicable`, exit codes, rutas, diagnósticos, archivos, comandos, tests ni resultados estructurados. No añadir agentes ni hooks. Las diez reglas son del coordinador al hablar con el usuario, nunca de la ejecución interna o de la entrega técnica.

## Diagnóstico rápido

En sesión nueva de Codex en la raíz del proyecto, pide una tarea con varios pasos **sin** `$i-have-adhd`: la respuesta del coordinador debería priorizar acción, pasos y estado. Para comprobar agentes, inspecciona `.codex/agents/<rol>.toml`; sus `developer_instructions` incluyen su perfil operativo, no la instrucción de cargar la skill como estilo. Esta es una política de instrucciones, no una garantía formal del modelo: validar comportamiento real manualmente.
