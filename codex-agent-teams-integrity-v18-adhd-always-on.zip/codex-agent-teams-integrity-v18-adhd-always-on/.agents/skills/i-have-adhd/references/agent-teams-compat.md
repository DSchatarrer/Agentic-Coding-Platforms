# Compatibilidad — I Have ADHD + Agent Teams Lean (Codex v18)

**Ámbito:** el coordinador mantiene el estilo siempre activo gracias a las instrucciones insertadas en [AGENTS.md](../../../../AGENTS.md), con detalle en [adhd-always-on.md](../../_shared/adhd-always-on.md). La skill upstream sigue invocable manualmente como referencia, pero **no es necesario invocarla para que se apliquen las diez reglas**. El nombre no implica ningún diagnóstico.

## Activación y alcance

- En **cada sesión nueva** abierta dentro de este proyecto, Codex debe leer `AGENTS.md` y aplicar por defecto las reglas de presentación del coordinador. No se instala hook, plugin, daemon ni interruptor global. La carga depende de que el cliente aplique correctamente las instrucciones del repositorio.
- La petición explícita del usuario de otro formato o `normal mode` puede ajustar el estilo en la sesión actual. En una nueva sesión del proyecto vuelve a regir el valor por defecto de `AGENTS.md`.
- Los diez especialistas tienen **perfiles operativos** específicos dentro de `.codex/agents/*.toml`. No cargan la skill de estilo como segunda skill. No transfieras limitaciones de número de elementos o longitud a mensajes entre agentes.

## Precedencia y garantías

1. Seguridad, instrucciones superiores, formato pedido y exhaustividad técnica prevalecen sobre simplificación visual.
2. Conservar **sin alteración** código, JSON, SQL, diffs, comandos, rutas, configuraciones, parámetros, resultados de herramientas y errores necesarios.
3. Preservar `status`, `quality_gate`, `success|partial|blocked`, `PASS|FAIL|BLOCKED|not_run|not_applicable`, comandos y exit codes verificables. No convertir `not_run` o `BLOCKED` en `PASS`.
4. No truncar logs, tests, bugs o hallazgos para ajustarse a cinco elementos. El resumen público puede enlazar resultados íntegros, no sustituirlos cuando se pidan.
5. Ponytail sigue siendo una guía independiente de menor cambio **completo**; no cambiar roles, modelos, MCP, estándares aprobados ni Quality Gate.

El handoff sigue [handoff.md](../../_shared/handoff.md). Las reglas originales pueden consultarse en [SKILL.md](../SKILL.md), pero el punto de activación **permanente** es el texto real de `AGENTS.md`.
