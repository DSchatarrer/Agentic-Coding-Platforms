"""Regresiones de integridad del paquete Codex y de su instalación."""
import importlib.util
from pathlib import Path
import tempfile
import tomllib
import unittest
import sys

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'scripts'))

def load(rel,name):
    spec=importlib.util.spec_from_file_location(name,ROOT/rel)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module

install=load('scripts/install.py','codex_v15_installer')
audit=load('scripts/audit_integrity.py','codex_v15_audit')
validate=load('scripts/validate.py','codex_v15_validator')

class IntegrityV15Tests(unittest.TestCase):
    def test_source_links_and_commands(self):
        issues,stats=audit.audit(ROOT,source=True)
        self.assertEqual(issues,[])
        self.assertEqual(stats['agent_roles'],10)
        self.assertGreater(stats['local_links'],100)

    def test_fresh_install_has_all_runtime_tools(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest)
            for s in audit.OPERATIVE:
                self.assertTrue((dest/'scripts'/s).is_file(),s)
            self.assertEqual(audit.audit(dest)[0],[])
            self.assertEqual(validate.validate(dest),[])

    def test_existing_extra_skill_updates_catalog_in_destination(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            custom=dest/'.agents/skills/custom-check/SKILL.md'
            custom.parent.mkdir(parents=True)
            custom.write_text('---\nname: custom-check\ndescription: Usa para verificar checks custom.\n---\n# Custom check\n',encoding='utf8')
            original=custom.read_bytes()
            logs=install.install(dest)
            self.assertEqual(original,custom.read_bytes())
            self.assertTrue(any('ACTUALIZADO catálogo' in line for line in logs), logs[-8:])
            catalog=(dest/'.agents/skills/_shared/skill-catalog.md').read_text(encoding='utf8')
            self.assertIn('custom-check', catalog)
            self.assertEqual(validate.validate(dest),[])

    def test_detects_deleted_documented_script(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest)
            (dest/'scripts/validate.py').unlink()
            issues,stats=audit.audit(dest)
            self.assertTrue(any('scripts/validate.py' in item for item in issues))
            self.assertTrue(any('validate.py' in item for item in validate.validate(dest)))

    def test_detects_broken_markdown_link(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest)
            x=dest/'.agents/skills/create/references/implementation.md'
            x.write_text(x.read_text(encoding='utf8')+'\n[Enlace roto](does-not-exist.md)\n',encoding='utf8')
            errors,_=audit.audit(dest)
            self.assertTrue(any('does-not-exist.md' in msg for msg in errors))

    def test_detects_invalid_toml_or_role_name(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest)
            file=dest/'.codex/agents/debug.toml'
            file.write_text('name = "wrong"\ndescription = "x"\n',encoding='utf8')
            errors,_=audit.audit(dest)
            self.assertTrue(any('Nombre de agente inconsistente' in msg for msg in errors))

    def test_config_uses_single_backup_and_no_backup_on_fresh_install(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest)
            self.assertEqual(list((dest/'.codex').glob('config.toml.bak.*')),[])
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            (dest/'.codex').mkdir()
            (dest/'.codex/config.toml').write_text('preferred_auth_method = "chatgpt"\n',encoding='utf8')
            install.install(dest)
            self.assertEqual(len(list((dest/'.codex').glob('config.toml.bak.*'))),1)
            data=tomllib.loads((dest/'.codex/config.toml').read_text())
            self.assertEqual(data['preferred_auth_method'],'chatgpt')
            self.assertIn('engram',data['mcp_servers'])

    def test_dry_run_is_read_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest,dry_run=True)
            self.assertFalse(list(dest.iterdir()))

    def test_foreign_catalog_is_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            catalog=dest/'.agents/skills/_shared/skill-catalog.md'
            catalog.parent.mkdir(parents=True)
            catalog.write_text('# PERSONAL INVENTORY\n',encoding='utf8')
            logs=install.install(dest)
            self.assertEqual(catalog.read_text(),'# PERSONAL INVENTORY\n')
            self.assertTrue(any('CONFLICTO catálogo ajeno' in line for line in logs))

if __name__=='__main__':unittest.main()

class OptionalGlobalConfigTests(unittest.TestCase):
    def test_explicit_global_mcp_opt_out(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest,include_engram=False,include_playwright=False)
            failures=validate.validate(dest)
            self.assertTrue(any('servidor MCP' in msg for msg in failures))
            self.assertEqual(validate.validate(dest,allow_inherited_mcp=True),[])

    def test_explicit_global_model_opt_out(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest,include_model_config=False)
            self.assertTrue(any('Modelo del coordinador incorrecto' in msg for msg in validate.validate(dest)))
            self.assertEqual(validate.validate(dest,allow_inherited_model=True),[])

    def test_invalid_local_mcp_not_accepted_as_inherited(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest=Path(tmp)
            install.install(dest)
            cfg=dest/'.codex/config.toml'
            cfg.write_text(cfg.read_text(encoding='utf8').replace('command = "engram"','command = ""'),encoding='utf8')
            self.assertTrue(any('servidor MCP engram' in x for x in validate.validate(dest,allow_inherited_mcp=True)))
