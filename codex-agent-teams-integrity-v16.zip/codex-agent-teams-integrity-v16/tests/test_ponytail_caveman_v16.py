"""Validación de integración opt-in v16 sin interferir con los diez roles."""
from pathlib import Path
import importlib.util
import re
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
SKILLS = ROOT / '.agents/skills'
REGISTRY = SKILLS / '_shared/project-skill-registry.md'


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


installer = load(ROOT / 'scripts/install.py', 'v16_installer_tests')
validator = load(ROOT / 'scripts/validate.py', 'v16_validator_tests')
registry = load(SKILLS / 'skill-creator/scripts/build_registry.py', 'v16_catalog_tests')


class PonytailCavemanV16Tests(unittest.TestCase):
    def test_five_approved_standards_not_six(self):
        text = REGISTRY.read_text(encoding='utf-8')
        approved = re.findall(r'^### ([a-z0-9]+(?:-[a-z0-9]+)*)$', text, re.M)
        self.assertEqual(len(approved), 5)
        self.assertEqual(approved.count('changed-code-tests'), 1)
        self.assertNotIn('### ponytail', text)
        self.assertNotIn('### caveman', text)
        self.assertIn('[minimal-complete-change.md](minimal-complete-change.md)', text)
        self.assertIn('menor cambio **completo**', text)
        self.assertIn('pruebas', text)

    def test_reference_loaded_only_for_design_decisions(self):
        guide = SKILLS / '_shared/minimal-complete-change.md'
        self.assertTrue(guide.is_file())
        body = guide.read_text(encoding='utf-8')
        self.assertIn('No la leas para un typo', body)
        self.assertIn('quality-gate', body)
        for role in ('create', 'debug', 'refactor', 'review'):
            content = (SKILLS / role / 'SKILL.md').read_text(encoding='utf-8')
            self.assertIn('(../_shared/minimal-complete-change.md)', content, role)
            self.assertIn('menor cambio', content.lower(), role)
        for role in ('plan', 'quality-gate', 'docs', 'research', 'test'):
            content = (SKILLS / role / 'SKILL.md').read_text(encoding='utf-8')
            self.assertNotIn('(../_shared/minimal-complete-change.md)', content, role)

    def test_review_keeps_read_only_boundary(self):
        content = (SKILLS / 'review/SKILL.md').read_text(encoding='utf-8')
        checklist = (SKILLS / 'review/references/reviewing.md').read_text(encoding='utf-8')
        self.assertIn('Solo lectura', content)
        self.assertIn('El rol no modifica archivos', checklist)
        self.assertIn('Seguridad y límites de confianza', checklist)
        self.assertIn('Complejidad evitable', checklist)
        self.assertIn('prueba no ejecutada', checklist)

    def test_concise_skill_explicit_only_and_no_new_agent(self):
        skill = SKILLS / 'concise-output/SKILL.md'
        metadata = skill.parent / 'agents/openai.yaml'
        self.assertTrue(skill.is_file())
        self.assertRegex(skill.read_text(encoding='utf-8'), r'(?m)^name: concise-output$')
        self.assertIn('allow_implicit_invocation: false', metadata.read_text(encoding='utf-8'))
        self.assertFalse((ROOT / '.codex/agents/concise-output.toml').exists())
        self.assertEqual(len(list((ROOT / '.codex/agents').glob('*.toml'))), 10)

    def test_original_evidence_takes_precedence(self):
        handoff = (SKILLS / '_shared/handoff.md').read_text(encoding='utf-8')
        output = (SKILLS / 'concise-output/SKILL.md').read_text(encoding='utf-8')
        for term in ('status', 'quality_gate', 'not_run', 'códigos de salida'):
            self.assertIn(term, handoff)
        for term in ('JSON', 'seguridad', 'truncamiento', 'fuente original', 'FAIL'):
            self.assertIn(term.lower(), output.lower())
        self.assertIn('no modifica código', output.lower())

    def test_no_routing_or_lifecycle_hooks_added(self):
        self.assertFalse((ROOT / 'hooks').exists())
        self.assertFalse((ROOT / '.codex/hooks').exists())
        self.assertFalse((ROOT / 'package.json').exists())
        self.assertFalse((ROOT / '.caveman.json').exists())
        self.assertFalse((ROOT / '.ponytail.json').exists())
        self.assertEqual(validator.validate(ROOT), [])

    def test_catalog_discovers_skill_without_approving_it(self):
        self.assertEqual(registry.run(ROOT, check=True)[0], 0)
        self.assertIn('`concise-output`', (SKILLS / '_shared/skill-catalog.md').read_text(encoding='utf-8'))
        self.assertNotIn('### concise-output', REGISTRY.read_text(encoding='utf-8'))

    def test_fresh_install_keeps_role_count_and_optin_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest)
            self.assertEqual(validator.validate(dest), [])
            self.assertEqual(len(list((dest / '.codex/agents').glob('*.toml'))), 10)
            self.assertTrue((dest / '.agents/skills/concise-output/agents/openai.yaml').is_file())
            self.assertTrue((dest / '.agents/skills/_shared/minimal-complete-change.md').is_file())
            self.assertEqual(registry.run(dest, check=True)[0], 0)

    def test_update_preserves_customization_without_force(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest)
            guide = dest / '.agents/skills/_shared/minimal-complete-change.md'
            guide.write_text('PERSONALIZADA\n', encoding='utf-8')
            logs = installer.install(dest)
            self.assertTrue(any('CONFLICTO' in item and 'minimal-complete-change.md' in item for item in logs))
            self.assertEqual(guide.read_text(encoding='utf-8'), 'PERSONALIZADA\n')
            installer.install(dest, force=True)
            self.assertEqual(guide.read_bytes(), (SKILLS / '_shared/minimal-complete-change.md').read_bytes())
            self.assertTrue(list(guide.parent.glob('minimal-complete-change.md.bak.*')))
            self.assertEqual(validator.validate(dest), [])

    def test_dry_run_does_not_create_optin_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest, dry_run=True)
            self.assertEqual(list(dest.iterdir()), [])


if __name__ == '__main__':
    unittest.main()
