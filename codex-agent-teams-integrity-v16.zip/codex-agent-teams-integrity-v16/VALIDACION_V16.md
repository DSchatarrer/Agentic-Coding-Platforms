# Validación ejecutada — Codex Agent Teams v16

Fecha: 30-10-2026. Baseline v15: SHA-256 `6eec7735352b4778b640cc7365aefcb6363a46753dc3df815659dbc835e2ea03` del ZIP original recibido.

## Verificación ejecutada en el paquete fuente

| Verificación | Resultado |
|---|---|
| `python -m unittest discover -s tests -q` | **108 tests, OK** (98 de v15 + 10 nuevos) |
| `python scripts/validate.py --project-root .` | **OK**: roles, registro, catálogos y enlaces |
| `python scripts/audit_integrity.py --project-root . --source` | **OK**: 64 Markdown, 187 enlaces locales, 23 comandos Python, 10 roles |
| `python .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check` | **OK**: 11 skills descubiertas, 4 convenciones |
| Directivas de `AGENTS.md` | **292 palabras**, presupuesto máximo 300 |

## Simulación de actualización v15 a v16

Se instaló la v15 original en un directorio temporal, se preservó texto personalizado fuera del bloque gestionado de `AGENTS.md` y después se aplicó el instalador de v16 con tres escenarios:

1. `--dry-run`: **no escribió** la skill nueva ni modificó el destino.
2. Actualización sin `--force`: notificó conflictos y **no sobrescribió** el registro personalizado. La nueva skill se copió como archivo nuevo.
3. Actualización con `--force`: generó respaldos de los archivos actualizados; se conservaron los comentarios personalizados fuera de los marcadores de `AGENTS.md`; auditoría y validación del destino pasaron.

Comparación de SHA-256 **antes/después** de todos los archivos `.codex/*.toml` y `.codex/agents/*.toml` de la instalación: **idénticos**. Se conservaron 10 roles; 11 skills (10 roles + una opt-in).

## Límites de esta evidencia

Son pruebas sobre scripts y archivos de configuración. **No se ha ejecutado una sesión real de Codex con los modelos del usuario**, los MCP reales ni benchmarks de ahorro de tokens. Tampoco se han instalado Caveman o Ponytail externos. Las versiones publicadas de terceros pueden cambiar y no están fijadas como dependencias del ZIP.
