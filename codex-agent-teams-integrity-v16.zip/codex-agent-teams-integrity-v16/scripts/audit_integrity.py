#!/usr/bin/env python3
"""Audita Markdown, comandos locales, roles y rutas del proyecto Codex.

Sin red; no cambia archivos. --source revisa también los documentos del paquete ZIP.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import re
import tomllib
from urllib.parse import unquote

MD_LINK = re.compile(r'(?<!!)\[[^\]\n]+\]\(([^)]+)\)')
PY_CMD = re.compile(r'(?<![\w/.-])(?:py\s+-3\s+|python(?:3(?:\.\d+)?)?\s+)([.\w/-]+\.py)(?=\s|$)')
CMD_DOCS = ('AGENTS.md', 'README.md', 'VALIDACION.md', 'COHERENCIA.md', 'EFICIENCIA_CONTEXTO.md', 'EVALUACIONES.md', 'MEMORIA_V14.md')
OPERATIVE = ('git_init.py', 'validate.py', 'context_profile.py', 'audit_integrity.py')

def audit(root: Path, *, source: bool = False) -> tuple[list[str],dict[str,int]]:
    root = root.expanduser().resolve()
    errors=[]
    stats={'markdown_files':0,'local_links':0,'python_commands':0,'agent_roles':0}
    for md in sorted(root.rglob('*.md')):
        if '.git' in md.parts or '.tox' in md.parts or '.venv' in md.parts or '.agent-teams-backups' in md.parts or '.bak.' in md.name:
            continue
        txt=md.read_text(encoding='utf-8')
        stats['markdown_files']+=1
        for match in MD_LINK.finditer(txt):
            raw=match.group(1).split(' ',1)[0].strip('<>')
            if raw.startswith(('http://','https://','mailto:','data:','#')):
                continue
            rel=unquote(raw.split('#',1)[0].split('?',1)[0])
            if not rel: continue
            stats['local_links']+=1
            target=(md.parent/rel).resolve()
            if not target.is_relative_to(root) or not target.is_file():
                errors.append(f'Enlace roto: {md.relative_to(root)} -> {raw}')
    for name in (CMD_DOCS if source else ('AGENTS.md',)):
        doc=root/name
        if not doc.is_file():
            if name=='AGENTS.md' or source: errors.append(f'Documento obligatorio ausente: {name}')
            continue
        for match in PY_CMD.finditer(doc.read_text(encoding='utf-8')):
            rel=match.group(1)
            if not rel.startswith(('scripts/', '.agents/')): continue
            stats['python_commands']+=1
            if not (root/rel).is_file():
                errors.append(f'Comando documentado inexistente: {name} -> {rel}')
    # Verify commands documented as installed are actually present.
    for name in OPERATIVE:
        if not (root/'scripts'/name).is_file():
            errors.append('Herramienta de mantenimiento ausente: scripts/'+name)
    agents=root/'.codex/agents'
    for role in sorted(agents.glob('*.toml')):
        stats['agent_roles']+=1
        try:
            obj=tomllib.loads(role.read_text(encoding='utf-8'))
        except (OSError,ValueError,tomllib.TOMLDecodeError) as exc:
            errors.append(f'TOML de agente inválido: {role.relative_to(root)}: {exc}')
            continue
        if role.stem != obj.get('name'):
            errors.append(f'Nombre de agente inconsistente: {role.relative_to(root)}')
        expected=root/'.agents/skills'/role.stem/'SKILL.md'
        if not expected.is_file():
            errors.append(f'El agente {role.stem} carece de SKILL.md')
        if str(expected.relative_to(root)).replace('\\','/') not in obj.get('developer_instructions',''):
            errors.append(f'El agente {role.stem} no carga su SKILL.md')
    cfg=root/'.codex/config.toml'
    if not cfg.is_file():
        errors.append('Falta .codex/config.toml')
    else:
        try:
            tomllib.loads(cfg.read_text(encoding='utf-8'))
        except (OSError,ValueError,tomllib.TOMLDecodeError) as exc:
            errors.append(f'Configuración Codex TOML inválida: {exc}')
    return errors,stats

def main() -> int:
    ap=argparse.ArgumentParser(description='Auditoría de rutas y cohesión de Agent Teams para Codex')
    ap.add_argument('--project-root',type=Path,default=Path.cwd())
    ap.add_argument('--source',action='store_true',help='Auditar la documentación del paquete fuente')
    args=ap.parse_args()
    errs,counts=audit(args.project_root,source=args.source)
    print('Auditoría:', ', '.join(f'{k}={v}' for k,v in counts.items()))
    if errs:
        for err in errs:print('ERROR:',err)
        return 1
    print('OK: enlaces Markdown, scripts operativos, comandos documentados y agentes')
    return 0
if __name__=='__main__':raise SystemExit(main())
