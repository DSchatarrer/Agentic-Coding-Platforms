# Eficiencia contextual: comparación estática v12 → v13

**Advertencia:** son **palabras de archivos** como proxy estático; no son tokens medidos, tiempos reales ni lecturas observadas de modelos. El consumo depende de qué documentos lea Codex efectivamente.

| Indicador | v12 | v13 | Variación |
|---|---:|---:|---:|
| `AGENTS.md` (contexto de coordinación) | 1338 | 227 | -83.0 % |
| Suma de los diez `SKILL.md` (solo si se activaran todos) | 2433 | 1532 | -37.0 % |
| Registro de estándares aprobado (palabras) | 1031 (incluye catálogo) | 638 (solo normas) | No directamente comparable |

## Interpretación

- La mayor reducción corresponde al texto permanente del coordinador; **no significa** que toda tarea ahorre ese mismo porcentaje de tokens.
- Las `SKILL.md` se activan por rol; no tiene sentido sumar las diez como coste permanente.
- En v12, `project-skill-registry.md` mezclaba reglas y catálogo; en v13 están separados para leer el inventario solo al mantener skills.
- El selector `plan` ya enlaza operaciones TODO directamente, sin lectura obligatoria de `todo-tracker.md`.
- El informe generado por `scripts/context_profile.py` calcula **escenarios hipotéticos**, no registra acceso efectivo a archivos. No hay garantía de que un modelo obedezca siempre la carga bajo demanda.

## Evaluación real pendiente

Comparar v14/v15 en el **mismo proyecto y solicitudes equivalentes**, observando calidad del resultado, pruebas aprobadas, tokens efectivos, número de lecturas, latencia y delegaciones. No se ha ejecutado esta evaluación contra modelos Astra/Sol ni MCP locales.


## v14 — Memoria curada

`engram.md` permanece como contrato pequeño. Las cuatro referencias `memory/*.md` se abren por condición, no en el arranque ni en la delegación normal. El tamaño total de referencias en disco no implica coste de tokens: medir lecturas reales en Codex. No atribuir ahorro de memoria persistente sin medir `mem_stats` antes/después en el Engram local.


## v15 — Medición estática de integridad

El `AGENTS.md` de esta versión contiene **266 palabras** (obtenido mediante `scripts/context_profile.py`). La mejora v15 se centra en coherencia entre ZIP e instalación, y no representa una reducción demostrada de tokens de ejecución frente a v14. Los datos de la tabla v12/v13 de arriba son un registro histórico y no la medida actual.
