# Integración v16 — Ponytail + Caveman sin plugins superpuestos

Fecha: 30-10-2026. Baseline: v15 (informe [INTEGRIDAD_CODEX_V15.md](INTEGRIDAD_CODEX_V15.md)).

## Decisión y alcance

Esta versión implementa **solo una adaptación original de ideas**, no incorpora archivos de terceros, paquetes npm, código de sus ejecutables ni hooks externos.

| Pieza | Estado | Enlace en este paquete |
|---|---|---|
| Reutilización y menor cambio completo (Ponytail) | Integrada en estándar existente y cuatro roles | [estándares](.agents/skills/_shared/project-skill-registry.md), [guía](.agents/skills/_shared/minimal-complete-change.md) |
| Revisión de sobreingeniería (Ponytail) | Checklist en rol review, no agente adicional | [revisión](.agents/skills/review/references/reviewing.md) |
| Salida concisa (Caveman) | Predeterminado: handoff normal. Extra breve: skill opt-in | [handoff](.agents/skills/_shared/handoff.md), [skill](.agents/skills/concise-output/SKILL.md) |
| Lectura selectiva de logs (Caveman) | Solo recomendación reversible: preservar originales | [skill opt-in](.agents/skills/concise-output/SKILL.md) |
| Caveman Auto, Blocks, proxy, browse, telemetría y Cavecrew | **No instalados** | Sin hooks, transporte ni cuentas nuevas |
| Hooks y plugins completos de Ponytail | **No instalados** | Sin `SessionStart` o `SubagentStart` adicionales |

## Precedencia y seguridad

1. Usuario, contratos, seguridad, compatibilidad, accesibilidad y aceptación verificable tienen prioridad sobre simplificación y formato.
2. `changed-code-tests` sigue siendo **una sola entrada** entre las cinco aprobadas. La guía se consulta bajo demanda, nunca en el contexto inicial del coordinador.
3. El `quality-gate` sigue independiente. No se modificaron su runner ni el perfil TOML. No declarar `PASS` sin política y pruebas configuradas.
4. `review` conserva su disciplina de solo lectura como contrato de rol (no es sandbox). Para aislamiento real se requieren permisos efectivos del proceso Codex.
5. La skill `concise-output` no se selecciona automáticamente: `.agents/skills/concise-output/agents/openai.yaml` define `policy.allow_implicit_invocation: false`. Solo la invocación expresa `$concise-output` la activa. No crea `.codex/agents/concise-output.toml`.
6. La concisión nunca cambia JSON, código, comandos, salidas de pruebas ni estados. Si se muestra un extracto de log, declarar que está truncado y conservar la fuente íntegra.

## Uso rápido en un proyecto destino

En PowerShell, desde la carpeta del paquete descomprimido:

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\proyecto" --dry-run
py -3 scripts/install.py --project-root "C:\ruta\a\proyecto" --force
```

El primer paso presenta conflictos sin escribir. **`--force` sobrescribe archivos administrados con respaldo**, así que revisa cambios y respáldalos en tu repositorio antes de actualizar un proyecto previamente personalizado. Sin `--force`, los conflictos se conservan sin actualizar. Los diez agentes y la asignación de modelos/MCP no se alteran deliberadamente con respecto a v15.

Uso de Codex:

```text
Implementa esta corrección de forma segura.
$concise-output Resume los resultados de la ejecución y los bloqueos.
```

No escribas `$concise-output` en las peticiones siguientes para regresar al modo compacto estándar.

## Verificación estática

```powershell
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 scripts/validate.py --project-root .
py -3 scripts/audit_integrity.py --project-root . --source
py -3 -m unittest discover -s tests -q
```

El resultado de los comandos ejecutados durante esta entrega se documenta fuera del paquete en el informe de ejecución asociado. Las pruebas de archivos y scripts **no miden tokens reales ni demuestran que los modelos sigan siempre estas instrucciones**. Es necesaria una evaluación A/B en Codex para estimar calidad, ahorro y adherencia.

## Procedencia y licencias

- [Ponytail — DietrichGebert](https://github.com/DietrichGebert/ponytail): MIT. Se adaptan criterios de reutilización y simplificación, sin copiar sus archivos.
- [Caveman — JuliusBrussee](https://github.com/JuliusBrussee/caveman): Apache-2.0. Se adapta el enfoque de salida concisa; **no** se distribuye el programa ni se adoptan sus métricas.
- [Codex — documentación de skills](https://learn.chatgpt.com/docs/build-skills): `$skill` para invocación, metadatos `agents/openai.yaml` para desactivar invocación implícita.

La documentación histórica de v15 se mantiene intacta para trazabilidad. No se infiere autorización para conectar servicios de terceros, instalar plugins, cambiar modelos ni enviar telemetría.
