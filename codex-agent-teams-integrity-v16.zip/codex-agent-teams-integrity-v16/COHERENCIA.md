# Contrato de cohesión y fuentes de verdad — Codex v16

| Tema | Fuente canónica | Uso |
|---|---|---|
| Coordinación | [AGENTS.md](AGENTS.md) | Al iniciar la sesión |
| Modelos y MCP | `.codex/config.toml` y `.codex/agents/*.toml` | Configuración, no precargar contexto |
| Instrucciones especialistas | `.agents/skills/<rol>/SKILL.md` | Al delegar el rol |
| Reglas aprobadas | [project-skill-registry.md](.agents/skills/_shared/project-skill-registry.md) | Antes de delegar código, máximo cinco entradas |
| Inventario dinámico | [skill-catalog.md](.agents/skills/_shared/skill-catalog.md) | Descubrimiento y actualización de skills, nunca reglas aprobadas |
| Resolución | [skill-resolver.md](.agents/skills/_shared/skill-resolver.md) | Solo si la selección requiere detalles |
| Memoria duradera | [engram.md](.agents/skills/_shared/engram.md) | Consultar o guardar conocimiento útil; no logs |
| Handoffs | [handoff.md](.agents/skills/_shared/handoff.md) | Resumen simple; extendido solo para casos complejos |
| Calidad | [quality-gate/SKILL.md](.agents/skills/quality-gate/SKILL.md) | Evidencia independiente con política |
| Menor cambio completo (Ponytail adaptado) | [minimal-complete-change.md](.agents/skills/_shared/minimal-complete-change.md) | Referencia bajo demanda desde el estándar ya aprobado `changed-code-tests` |
| Respuesta extra breve (Caveman adaptado) | [concise-output/SKILL.md](.agents/skills/concise-output/SKILL.md) | Opt-in con `$concise-output`; sin agente ni hooks |
| Instalación | `scripts/install.py` (solo en paquete fuente) | Conserva archivos ajenos y hace un único backup de config |
| Integridad | `scripts/validate.py`, `scripts/audit_integrity.py` | Ambos disponibles en proyecto instalado |

**No crear una segunda fuente de verdad en Engram.** La skill propia se lee al delegar y sus referencias se abren solo cuando su disparador aplica. No guardar duplicados de resultados ni dar por ejecutadas pruebas no realizadas.

## Diferencia fuente e instalación

El paquete ZIP también contiene los `tests/`, el instalador y la documentación completa. El instalador copia únicamente los agentes, skills, `AGENTS.md`, configuración y cuatro scripts de mantenimiento. No promete copiar su README, los ejemplos de CI ni la batería de tests. El catálogo generado se refresca según las skills reales del destino, salvo conflicto con catálogo ajeno.

La auditoría de rutas comprueba **Markdown y configuraciones locales**, pero la disponibilidad real de los MCP, la cuenta, la ejecución de agentes y el consumo de tokens requieren Codex funcionando en el equipo. Los flags de herencia del validador no certifican recursos globales.
