# Auditoría de coherencia, cohesión e integridad — Codex v15

## Alcance

Se auditó el ZIP de Codex v14 como entrada y se corrigió el paquete v15. El examen diferencia **fuente ZIP**, **instalación en repositorio nuevo**, **instalación con skills previas** y **ejecución real en Codex**. Las pruebas de ficheros no sustituyen una conexión real a Engram, Context7 o Playwright.

## Problemas detectados en v14 y corrección

| Hallazgo en v14 | Impacto | Corrección v15 |
|---|---|---|
| El instalador copiaba únicamente `git_init.py` | Los comandos `validate.py` y `context_profile.py` documentados fallaban en el proyecto instalado | Instala `validate.py`, `context_profile.py`, `git_init.py` y el auditor nuevo `audit_integrity.py` |
| El registro generado provenía del ZIP y no se refrescaba tras instalar | Un repositorio con skills propias quedaba con catálogo obsoleto | Regenera sobre las skills reales del destino; nunca modifica estándares aprobados |
| El instalador escribía `config.toml` varias veces (modelo y cada MCP) | Múltiples copias `.bak` innecesarias por una sola ejecución | Escribe una vez y crea como máximo un respaldo si el archivo existía |
| No había auditoría independiente de enlaces y comandos del destino | Las pruebas existentes no detectaban ciertos archivos ausentes | Nuevo `scripts/audit_integrity.py`, con `--source` para el paquete y modo de instalación |
| El validador interpretaba la omisión voluntaria de MCP/modelos globales como error | Falsos negativos al usar `--no-engram`, `--no-playwright` o `--no-model-config` | Parámetros optativos `--allow-inherited-mcp` y `--allow-inherited-model` que no validan la disponibilidad global |
| README y convenciones no distinguían todos los comandos exclusivos del ZIP de los instalados | Instrucciones no ejecutables tras instalar | Documentación de ambas ubicaciones y mapa de fuentes de verdad actualizado |

## Contrato que se conserva

- Orquestador y `plan`: `gpt-6-astra` / `medium`; otros nueve agentes: `gpt-6-sol` / `low`.
- Agente por skill; lectura de su `SKILL.md` y referencias directas bajo demanda.
- Estándares aprobados en `project-skill-registry.md`; catálogo generado **solo informativo**.
- Engram para decisiones curadas, Context7 HTTP y Playwright MCP bajo demanda, sin copiar memorias ni sesiones por defecto.
- `quality-gate` independiente, con evidencias reales y política explícita; Git inicializado solo cuando se pide.
- El instalador preserva configuraciones de MCP ajenas y archivos en conflicto sin `--force`.

## Verificación reproducible

En el ZIP fuente:

```powershell
py -3 scripts/audit_integrity.py --project-root . --source
py -3 scripts/validate.py --project-root .
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 -m unittest discover -s tests -q
```

En el proyecto instalado:

```powershell
py -3 scripts/audit_integrity.py --project-root .
py -3 scripts/validate.py --project-root .
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
```

Cuando se omitieron opciones locales porque se heredan desde el usuario, aplicar de forma **explícita** las opciones `--allow-inherited-mcp` o `--allow-inherited-model`, y verificar la integración global por separado.

## Límites

El auditor cubre enlaces Markdown con sintaxis estándar, rutas de comandos Python y coherencia básica de TOML/skills, además del verificador estructural. **No** interpreta todos los enlaces escritos como texto plano, no realiza análisis semántico completo de lenguaje natural y no certifica funcionamiento de un MCP remoto. El CLI `codex` no está disponible en este contenedor, por lo que la delegación real y el acceso a los modelos siguen pendientes de comprobación en el equipo del usuario.
