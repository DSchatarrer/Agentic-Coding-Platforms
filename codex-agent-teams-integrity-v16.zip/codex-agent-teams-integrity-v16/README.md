# Agent Teams Lean para Codex — v16 (integración selectiva Ponytail + Caveman)

Un coordinador (`gpt-6-astra`, `medium`), planificador del mismo modelo y nueve ejecutores (`gpt-6-sol`, `low`). Cada ejecutor tiene un `.codex/agents/<rol>.toml` y un `.agents/skills/<rol>/SKILL.md`. No se utiliza ninguna metodología de fases obligatorias.

## Entrada y carga de contexto

1. El coordinador lee **solo** [AGENTS.md](AGENTS.md), identifica trabajo y delega el mínimo de roles. No implementa código.
2. Ante una **delegación de código**, utiliza [estándares aprobados](.agents/skills/_shared/project-skill-registry.md): máximo cinco entradas coincidentes y solo sus reglas compactas. El [resolvedor](.agents/skills/_shared/skill-resolver.md) define el algoritmo si hay duda.
3. El especialista lee su `SKILL.md`. Las referencias están enlazadas **directamente desde cada skill** y se abren únicamente al aplicarse sus condiciones.
4. El [catálogo de skills](.agents/skills/_shared/skill-catalog.md) es **autogenerado** e informativo; nunca sustituye estándares aprobados ni se carga en cada delegación.
5. [Engram](.agents/skills/_shared/engram.md) conserva decisiones **curadas y sin duplicados** entre agentes; [Context7](.agents/skills/_shared/context7.md) comprueba documentación externa y [Playwright](.agents/skills/_shared/playwright-mcp.md) interactúa con interfaces web cuando se necesita. Todos bajo demanda.
6. Entrega compacta por defecto. [Handoff formal](.agents/skills/_shared/handoff.md) solo para tareas complejas y evidencia de aceptación independiente. Si faltan pruebas/política, `quality-gate` no puede declarar `PASS`.
7. Regla de [menor cambio completo](.agents/skills/_shared/minimal-complete-change.md) adaptada de Ponytail y acoplada a `changed-code-tests`, **sin un sexto estándar, agente ni hooks**. Uso profundo solo bajo demanda.
8. Modo extra breve opcional [concise-output](.agents/skills/concise-output/SKILL.md), inspirado en Caveman. Invócalo en Codex con `$concise-output`, sin reescribir datos estructurados ni suprimir evidencias.

## Qué cambia en v16 y cómo usarlo

- **Ponytail integrado de forma nativa:** se aplica al resolver el estándar `changed-code-tests` en tareas de código; los roles `create`, `debug`, `refactor` y `review` pueden profundizar en la guía enlazada solo cuando tengan decisiones de diseño reales.
- **Caveman solo como idea, no como plugin:** las entregas normales siguen compactas. Si quieres respuesta aún más breve, escribe en Codex `$concise-output <tu petición>`. Para volver al estilo normal, haz la siguiente petición **sin** `$concise-output`. La política `allow_implicit_invocation: false` impide que Codex seleccione esa skill por similitud semántica. Si no aparece, reinicia Codex o comprueba `/skills`.
- **Fuera de alcance intencional:** no se instala `caveman` ni `ponytail` externos, proxy, compresor de herramientas, Cavecrew, auto-routing, hooks de sesión, telemetría ni selección dinámica de modelos. No altera `.codex/config.toml` ni los diez perfiles de agente.
- **Evidencia inalterable:** logs/archivos fuente se preservan; se permite solo lectura selectiva de previsualizaciones. Una respuesta breve nunca oculta estado, `quality_gate`, error, código de salida ni ruta de evidencia.
- Los detalles técnicos y atribución se encuentran en [INTEGRACION_CAVEMAN_PONYTAIL_V16.md](INTEGRACION_CAVEMAN_PONYTAIL_V16.md) y las comprobaciones reales en [VALIDACION_V16.md](VALIDACION_V16.md). Las instrucciones locales están dentro del ZIP y el instalador las transporta al proyecto destino.

## Instalar o actualizar en Windows

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\proyecto" --dry-run
py -3 scripts/install.py --project-root "C:\ruta\a\proyecto" --force
```

El instalador **no** elimina archivos ajenos ni altera conexiones MCP ya existentes; copia archivos gestionados y crea **un único respaldo por actualización de `config.toml`**, no uno por MCP. Si el destino contiene skills propias, actualiza el catálogo generado de ese destino sin modificar estándares aprobados. Si existe un archivo ajeno con el nombre del catálogo, lo conserva y muestra el conflicto. Al migrar desde versiones anteriores, revisa las referencias antiguas que quedaron en tu proyecto: `engram-convention.md` y `persistence-contract.md`. No son necesarias para v14, pero el instalador no las borra automáticamente. Engram puede configurarse desde el equipo con `engram setup codex`; comprueba `codex mcp list`. Requiere Python 3.11+ y, para Playwright MCP, Node.js/npm/npx operativo. Los nombres de modelo deben estar disponibles en tu instalación de Codex.

## Git: inicialización opcional y segura

El proyecto puede inicializarse en Git **solo cuando todavía no pertenece a un repositorio**, con un comando explícito. **No se crean commits, remotos, tags ni `.gitignore` automáticamente.** Si el proyecto está dentro de un repositorio padre, no se crea un `.git` anidado.

Desde la carpeta extraída del paquete (el instalador también copia este comando al proyecto destino), indicando tu proyecto destino:

```powershell
py -3 scripts/git_init.py --project-root "C:\ruta\a\proyecto" --dry-run
py -3 scripts/git_init.py --project-root "C:\ruta\a\proyecto"
```

Alternativamente, al instalar:

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\proyecto" --init-git --dry-run
py -3 scripts/install.py --project-root "C:\ruta\a\proyecto" --init-git
```

Sin `--init-git` el instalador no modifica Git. Un error al comprobar el repositorio se reporta como bloqueado, nunca se fuerza `git init`. Los scripts `git_init.py`, `validate.py`, `audit_integrity.py` y `context_profile.py` se instalan de forma conservadora: no se sustituye un archivo homónimo existente sin `--force`. El comando de Git es independiente de los agentes; necesitarás tener `git` instalado en PATH.

## Higiene de memoria Engram

La política de escritura reside en [engram.md](.agents/skills/_shared/engram.md). Las referencias se leen **solo cuando se necesiten**: [escritura](.agents/skills/_shared/memory/write-policy.md), [claves estables](.agents/skills/_shared/memory/topic-keys.md), [recuperación](.agents/skills/_shared/memory/retrieval-policy.md) y [mantenimiento](.agents/skills/_shared/memory/maintenance.md). Ninguna introduce una base nueva, deduplicador LLM o limpieza automática. Las decisiones evolutivas usan la misma `topic_key` por proyecto y se comprueban frente al código y Git; no se guardan logs ni resultados triviales.

## Actualización y validación

```powershell
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root .
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 scripts/validate.py --project-root .
py -3 scripts/audit_integrity.py --project-root .
py -3 scripts/context_profile.py --project-root .
```

La actualización del catálogo solo reescribe `skill-catalog.md`; **no** toca `project-skill-registry.md`. La instalación realiza esta actualización en el destino automáticamente cuando el catálogo pertenece a este paquete. Si ya existe un catálogo ajeno, informa del conflicto sin sobrescribirlo. Antes de añadir una regla global, revisarla y aprobarla manualmente. Las skills nuevas se crean con `skill-creator`; no hace falta crear un agente TOML por defecto.

### Qué comandos hay disponibles después de instalar

En el **paquete ZIP extraído** se incluyen `scripts/install.py`, `tests/`, informes y documentación completa. Allí puedes ejecutar la batería de pruebas y la auditoría del paquete:

```powershell
py -3 scripts/audit_integrity.py --project-root . --source
py -3 -m unittest discover -s tests -q
```

En el **proyecto de destino**, el instalador copia cuatro scripts operativos (`git_init.py`, `validate.py`, `audit_integrity.py`, `context_profile.py`) y las carpetas de agentes y skills. **No instala** `tests/`, `scripts/install.py` ni el README del paquete: estas piezas pertenecen al ZIP fuente. Desde el proyecto instalado sí funcionan `scripts/validate.py`, `scripts/audit_integrity.py`, `scripts/context_profile.py` y `build_registry.py --check`. **Los tests y `--source` se ejecutan desde el paquete ZIP**, no desde el destino.

Si has optado por mantener Engram/Playwright o los modelos en la configuración **global** de Codex, puedes validar sin exigir esas entradas localmente:

```powershell
py -3 scripts/validate.py --project-root . --allow-inherited-mcp
py -3 scripts/validate.py --project-root . --allow-inherited-model
```

Combina ambos flags si procede. **No verifican las conexiones globales**: `codex mcp list` y una ejecución real son necesarios para comprobar disponibilidad. Una configuración local presente pero defectuosa sigue dando error.

Consulta [INTEGRACION_CAVEMAN_PONYTAIL_V16.md](INTEGRACION_CAVEMAN_PONYTAIL_V16.md) para los cambios de v16 y el informe histórico [INTEGRIDAD_CODEX_V15.md](INTEGRIDAD_CODEX_V15.md) para el baseline original.

## Guías técnicas, TODO y calidad

- [plan/SKILL.md](.agents/skills/plan/SKILL.md) elige directamente la operación de `TODO.md` (CREAR, AUDITAR, CONTINUAR, ACTUALIZAR, REPLANIFICAR), sin precargar índices. Conserva las referencias detalladas y evidencias.
- [Arquitectura](.agents/skills/_shared/architecture/decision-guide.md): escoger Clean, Hexagonal o Capas cuando el diseño requiera una decisión real, no por defecto.
- [Python SDK](.agents/skills/_shared/python-libraries.md): API/SDK público, protocolos y compatibilidad, solo si procede.
- [Quality Gate](.agents/skills/quality-gate/SKILL.md): `run_gates.py` exige una política `quality-gates.toml` aprobada y produce `PASS`, `FAIL` o `BLOCKED`.
- [Medición estática](EFICIENCIA_CONTEXTO.md): comparación del texto potencial precargado; no confundirla con tokens reales de una ejecución.

## Seguridad y límites

No se han ejecutado agentes, modelos ni MCP locales en tu equipo; los tests verifican **configuración y scripts**, no calidad de ejecución con Astra/Sol. No persistir secretos en Engram ni activar navegación sensible/destructiva sin autorización. Para medir ahorro real, ejecutar los escenarios de [EVALUACIONES.md](EVALUACIONES.md) con telemetría de Codex y comparar éxito, tokens, lecturas y delegaciones.
