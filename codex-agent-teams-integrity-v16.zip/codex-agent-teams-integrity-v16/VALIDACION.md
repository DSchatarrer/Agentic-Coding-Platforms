# Validación Codex v15 — integridad y cohesión

**Origen:** v14 Memory Hygiene. **Alcance:** paquete fuente, estructura instalada y casos negativos.

## Comandos ejecutados sobre la carpeta fuente

```powershell
py -3 scripts/audit_integrity.py --project-root . --source
py -3 scripts/validate.py --project-root .
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 -m unittest discover -s tests -q
```

Resultados en la preparación de v15: **98 tests correctos**; auditoría con **61 documentos Markdown, 166 enlaces locales, 23 comandos Python documentados y 10 definiciones de agente**, sin incidencias; validador estructural y catálogo correctos.

Se verificó una instalación nueva y otra con skill propia previa. El instalador instala los cuatro scripts de mantenimiento; el catálogo se genera en el destino sin contaminar estándares aprobados. Se añadieron pruebas negativas por archivo faltante, enlace roto, rol TOML incorrecto y catálogo ajeno. El merge de `.codex/config.toml` conserva otras opciones y crea un máximo de un respaldo si ya existía el archivo.

## Validación después de instalar

```powershell
py -3 scripts/audit_integrity.py --project-root .
py -3 scripts/validate.py --project-root .
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
```

La carpeta instalada no lleva `tests/` ni `scripts/install.py`: son contenido del paquete fuente. Para un Engram/Playwright o modelo global omitidos localmente, utiliza las opciones explícitas de herencia del validador y comprueba manualmente su disponibilidad.

## Límites

No hay ejecución real del CLI `codex` en este entorno. No se probó conexión remota a Context7, Engram ni Playwright, ni acceso real a modelos Astra/Sol, ni se midieron tokens efectivos. Las pruebas solo certifican lo que indican sus aserciones; el recuento estático de Markdown no es una revisión semántica completa.

Ver [INTEGRIDAD_CODEX_V15.md](INTEGRIDAD_CODEX_V15.md) para los errores detectados y [COHERENCIA.md](COHERENCIA.md) para las fuentes de verdad.
