---
name: concise-output
description: Modo extra breve y seguro de respuesta; usar solo cuando el usuario invoque explícitamente $concise-output en Codex. No modifica código ni decisiones técnicas.
---
# Salida extra breve (opt-in)

## Procedimiento mínimo
1. Aplicar **solo** cuando el usuario invoque `$concise-output`. Presenta el resultado primero, sin saludos ni recapitulaciones; una idea por frase cuando sea viable.
2. Mantén **íntegros** los fragmentos de código/JSON contractual, comandos, rutas, mensajes de error relevantes, valores, unidades, estados y advertencias; no alteres semántica ni sintaxis por estilo.
3. Si hay logs o datos grandes, lee solo las partes pertinentes **para explorar** cuando resulte seguro; conserva la fuente original sin transformarla. Ante fallo, evidencia insuficiente o auditoría, recupera la salida íntegra y marca claramente cualquier truncamiento.
4. Seguridad, permisos, accesibilidad, política de calidad, evidencia y petición de detalle del usuario prevalecen siempre sobre brevedad. Este modo no comprime archivos, intercepta herramientas, selecciona modelos ni instala hooks.

## Referencias bajo demanda
- [handoff](../_shared/handoff.md) — cuando existan estados formales, pruebas o evidencias que no se deben omitir.

## Entrega
Devuelve el mismo resultado verificable que sin este modo, con menos texto ceremonial. No inventes resultados, no ocultes `FAIL|BLOCKED|not_run`, y si el usuario pide explicación completa, proporciona el detalle completo.
