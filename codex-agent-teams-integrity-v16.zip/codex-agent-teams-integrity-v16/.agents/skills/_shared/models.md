# Modelos de los agentes

Perfil establecido por el usuario: coordinador y `plan` → `gpt-6-astra` / `medium`; los otros nueve roles → `gpt-6-sol` / `low`. No cambiar modelos durante tareas normales. El instalador establece estos valores **solo** si no se pasa `--no-model-config`, preservando las demás opciones TOML y los MCP previamente configurados. La disponibilidad efectiva se comprueba en Codex local.
