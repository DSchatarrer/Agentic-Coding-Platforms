# Estándares complementarios aprobados

## Cómo utilizarlo

1. Detectar **acción** (implementar, revisar, depurar, refactorizar o probar), rutas realmente implicadas y tecnología comprobada en el proyecto. No deducir tecnologías solo por la solicitud.
2. Elegir únicamente entradas cuya condición sea verdadera. Límite: **cinco entradas**, sin repetirlas. Si ninguna coincide, no inyectar la sección `## Project Standards (auto-resolved)`.
3. Pasar **solo las reglas compactas** de esas entradas en el prompt de delegación, junto a la ruta al `SKILL.md` del rol; el especialista sigue leyendo su propia skill y profundiza bajo demanda.
4. No presentar ninguna regla como un estándar específico del repositorio si no está comprobada. Los patrones aquí descritos son **condicionales**, no requisitos universales.
5. Si el usuario añade normas propias, editar **solo `## Entradas`** y contrastarlas con el código. Engram conserva decisiones históricas, **no versiones alternativas de este registro**.
6. El catálogo autogenerado de skills/convenciones es **informativo**. Sus reglas candidatas solo pueden inyectarse si se revisan y promocionan expresamente a `## Entradas`. No interpretar una skill nueva como estándar aprobado.

## Entradas

### python-library-api
- **Acción:** crear, revisar, refactorizar, probar o documentar APIs públicas Python.
- **Rutas/tecnología:** módulos `.py` de librería/SDK, empaquetado `pyproject.toml`, `Protocol` o `ABC` presentes o requeridos.
- **Referencia completa:** [python-libraries.md](python-libraries.md).
- **Reglas compactas:** Mantén una API pública explícita y contratos de compatibilidad. Usa `Protocol` para interfaces estructurales o `ABC` si necesitas comportamiento compartido/nominal; no impongas ninguno por defecto. Separa adaptadores del código consumidor si aporta valor; prueba los contratos y documenta efectos de versionado.

### architecture-boundaries
- **Acción:** diseño, implementación, refactor o revisión de límites entre módulos.
- **Rutas/tecnología:** cambios de dependencias, puertos/adaptadores o capas **comprobados**; no aplica a typos ni cambios aislados.
- **Referencia completa:** [architecture/decision-guide.md](architecture/decision-guide.md), y **solo** la guía elegida.
- **Reglas compactas:** Respeta los límites existentes antes de proponer otros. Justifica dependencias nuevas; dominio y reglas de negocio no deben acoplarse innecesariamente a infraestructura. Selecciona la estructura más simple que cubra los requisitos y protege los contratos con tests.

### changed-code-tests
- **Acción:** crear, depurar, refactorizar, revisar o probar código.
- **Rutas/tecnología:** archivos fuente modificados o sometidos a revisión; siempre que haya comportamiento comprobable.
- **Referencia completa:** [minimal-complete-change.md](minimal-complete-change.md) solo ante alternativas de implementación/sobreingeniería; [../quality-gate/references/acceptance.md](../quality-gate/references/acceptance.md) si corresponde aprobar un cambio.
- **Reglas compactas:** Antes de escribir, inspecciona implementación, llamadores y dependencias verificadas. Reutiliza soluciones existentes y elige el menor cambio **completo**, sin capas ni dependencias especulativas. Preserva contratos, seguridad, compatibilidad, accesibilidad y pruebas. Define aceptación observable; comunica comandos y resultados reales, diferenciando no ejecutado y fallo. Nunca sustituyas verificación ni política aprobada por simplicidad.

### browser-ui
- **Acción:** depurar, crear, probar o revisar una interfaz de usuario ejecutable.
- **Rutas/tecnología:** frontend web y servicio real accesible; **no** por el mero hecho de que existan `.tsx`/`.jsx`.
- **Referencia completa:** [playwright-mcp.md](playwright-mcp.md).
- **Reglas compactas:** Usa Playwright MCP solo si hace falta interacción real con navegador. El control exploratorio no sustituye Playwright Test reproducible. Registra entorno, pasos y observaciones; evita sesiones sensibles o acciones destructivas.

### external-api-compatibility
- **Acción:** implementar, depurar, revisar o investigar código ligado a APIs externas.
- **Rutas/tecnología:** dependencia o versión externa concreta, cuando la documentación instalada no resuelva una duda.
- **Referencia completa:** [context7.md](context7.md).
- **Reglas compactas:** Comprueba versiones en dependencias reales y consulta Context7 solo para dudas vigentes. No inventes firmas de métodos ni asumas acceso al MCP; no envíes secretos ni código privado a consultas externas.

## Mantenimiento

- Tras instalar, crear, actualizar o eliminar skills, ejecutar `python .agents/skills/skill-creator/scripts/build_registry.py --project-root .`. Esto refresca **solo el catálogo generado**.
- `python .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check` devuelve error si quedó obsoleto.
- `skill-creator` modifica **las entradas aprobadas** únicamente si la nueva skill aporta una norma transversal comprobable; nunca las sobrescribe automáticamente.
- Si se añade una referencia, comprobar que su ruta existe y que el disparador no contradice su skill.
- Valida después con `python scripts/validate.py --project-root .` y `python -m unittest discover -s tests`.
- Para estándares particulares de un **proyecto destino**, personaliza una copia instalada, sin modificar el paquete fuente global. El instalador conserva conflictos sin `--force`.
