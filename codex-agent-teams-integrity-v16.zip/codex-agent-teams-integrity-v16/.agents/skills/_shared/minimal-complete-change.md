# Política bajo demanda: menor cambio completo

**Procedencia conceptual:** adaptación original de las ideas de [Ponytail](https://github.com/DietrichGebert/ponytail). No se instala el plugin, no se copian sus prompts ni se activan hooks.

## Activar solo cuando importe una decisión de implementación

Usa esta referencia para cambios con varias soluciones plausibles, refactors estructurales, bugs de varios llamadores o revisiones en que haya riesgo de sobreingeniería. No la leas para un typo o una corrección inequívoca.

1. **Entender primero:** localiza implementación actual, contratos, consumidores, tests y convenciones verificadas. Si falta contexto, decláralo; no inventes dependencias.
2. **Comparar alternativas:** prioriza reutilizar, corregir en su ubicación o simplificar lo existente. Añade una abstracción, bandera, dependencia o mecanismo de compatibilidad solo con un requisito concreto.
3. **Escoger el menor cambio completo:** minimiza superficie y estados nuevos, **no** líneas a cualquier precio. Conserva requisitos funcionales/no funcionales, seguridad, autorización, validación, observabilidad, accesibilidad y compatibilidad.
4. **Proteger el comportamiento:** prueba casos positivos, negativos y regresiones proporcionalmente al riesgo. Un cambio más pequeño sin tests o que rompa API no es mejor.
5. **Explicar decisiones pertinentes:** si rechazas una capa nueva, cita la alternativa existente. No prometas mejoras de coste/rendimiento sin medirlas; reporta comandos, resultados y bloqueos reales.

**Precedencia:** solicitud y contrato verificable, seguridad, API existente, criterios de aceptación y política de quality-gate > simplificación > estilo de presentación. No usar esta guía para saltar comprobaciones ni para modificar roles. `quality-gate` solo acepta con evidencias; `review` no edita.
