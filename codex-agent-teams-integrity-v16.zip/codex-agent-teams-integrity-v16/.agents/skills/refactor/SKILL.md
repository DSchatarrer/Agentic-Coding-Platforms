---
name: refactor
description: Mejora diseño sin cambiar comportamiento; usa cuando un refactor está justificado.
---
# Refactorizar

## Procedimiento mínimo
1. Justifica el refactor con duplicación, acoplamiento o riesgo verificable. Prefiere eliminar complejidad real frente a añadir capas; protege comportamiento, tests y API pública. No refactorices solo por gusto o estilo.
2. No cargues referencias salvo activación específica. Ejecuta las herramientas que necesites, no leas sus scripts completos salvo depuración.

## Referencias bajo demanda
- [menor cambio completo](../_shared/minimal-complete-change.md) — alternativas estructurales o riesgo de sobreingeniería.
- [decisión arquitectónica](../_shared/architecture/decision-guide.md) — solo refactor estructural.
- [verificación arquitectónica](../_shared/architecture/verification.md) — dependencias afectadas.
- [librerías Python](../_shared/python-libraries.md) — si afecta API pública.
- [Engram](../_shared/engram.md) — recuperar/guardar decisiones duraderas relevantes.
- [Context7](../_shared/context7.md) — duda externa real de versión/API.
- [Handoff](../_shared/handoff.md) — traspaso complejo o formal.

## Ejemplos de activación
- Sí: una tarea correspondiente a refactor.
- No: acciones de otro rol o pasos redundantes.

## Entrega
Estado `success|partial|blocked`; `quality_gate` por separado (`PASS|FAIL|BLOCKED|not_run|not_applicable`). Comunica comandos/resultados reales. Handoff extendido solo si hace falta.
