# Guía: review

## Índice
- Cuándo consultar esta guía
- Comprobaciones

## Cuándo
Consulta el comportamiento real, minimiza supuestos y protege datos y secretos.

## Comprobaciones

1. **Corrección y regresiones:** compara el diff con el requisito y los contratos existentes; comprueba casos límite, fallos, compatibilidad y llamadas afectadas.
2. **Seguridad y límites de confianza:** revisa autorización, validación, secretos, inyecciones y efectos laterales en cambios relevantes. No rebajes controles por reducir líneas.
3. **Pruebas y evidencia:** examina cobertura significativa y comandos/resultados reales. Una prueba no ejecutada nunca cuenta como aprobada.
4. **Complejidad evitable:** identifica duplicaciones, estados/opciones, capas, adaptadores y dependencias nuevas sin consumidor o requisito demostrado. Propón una alternativa más simple **con evidencia**, no una eliminación especulativa.
5. **Rendimiento y recursos:** solo reporta impacto cuando haya ruta crítica, datos, límite o medida; evita atribuir ganancias sin métricas.
6. **Severidad y reversibilidad:** lista ubicación, riesgo, reproducción y corrección sugerida, ordenados por impacto. Separa hallazgos verificables de preferencias estilísticas.

Consulta [menor cambio completo](../../_shared/minimal-complete-change.md) solo si la revisión requiere evaluar varias alternativas. El rol no modifica archivos y no suplanta al `quality-gate`.
