#!/usr/bin/env python3
"""Simple no-clobber project skill scaffold; optional Codex agent."""
from pathlib import Path
import argparse
import re

NAME = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')


def create_skill(project, name, description, *, with_agent=False, dry_run=False):
    project = Path(project).resolve()
    if not NAME.fullmatch(name) or len(name) > 64:
        raise ValueError('Nombre no válido: usa a-z, 0-9, guiones')
    if not description.strip() or len(description) > 1024 or '\n' in description:
        raise ValueError('Descripción inválida')
    skill = project/'.agents'/'skills'/name/'SKILL.md'
    agent = project/'.codex'/'agents'/f'{name}.toml'
    paths = [skill] + ([agent] if with_agent else [])
    if any(p.exists() for p in paths):
        raise FileExistsError('Ya existe un archivo de skill o agente. Se prohíbe sobrescribir.')
    if dry_run:
        return paths
    skill.parent.mkdir(parents=True, exist_ok=True)
    skill.write_text(f'''---\nname: {name}\ndescription: {description.strip()}\n---\n# {name}\n\n## Procedimiento mínimo\n1. Define aceptación observable.\n2. Ejecuta trabajo y valida.\n\n## Entrega\nDescribe resultados y pruebas ejecutadas.\n''', encoding='utf8')
    if with_agent:
        agent.parent.mkdir(parents=True, exist_ok=True)
        agent.write_text(f'''name = "{name}"\ndescription = "Agente especializado para {name}"\nmodel = "gpt-6-sol"\nmodel_reasoning_effort = "low"\ndeveloper_instructions = """Lee .agents/skills/{name}/SKILL.md antes de actuar. No delegues. Registra comandos reales."""\n''', encoding='utf8')
    return paths


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('name');ap.add_argument('description');ap.add_argument('--project-root',default='.')
    ap.add_argument('--with-agent',action='store_true');ap.add_argument('--dry-run',action='store_true')
    a=ap.parse_args()
    for p in create_skill(a.project_root,a.name,a.description,with_agent=a.with_agent,dry_run=a.dry_run): print(p)
if __name__ == '__main__': main()
