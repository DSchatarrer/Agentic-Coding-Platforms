---
name: refactor
description: Mejora diseño sin cambiar comportamiento; usa cuando un refactor está justificado.
---
# Skill de refactor

## Procedimiento mínimo
1. Lee el objetivo y define el alcance acotado de refactor conservador.
2. Identifica criterios observables y ejecuta las acciones necesarias; evita herramientas externas si no aportan evidencia.
3. Registra comandos ejecutados, resultados reales y riesgos residuales.

## Referencias bajo demanda
- [../_shared/architecture/verification.md](../_shared/architecture/verification.md) — solo si hay migración, cambio de módulos o preservación de límites arquitectónicos.
- [../_shared/architecture/decision-guide.md](../_shared/architecture/decision-guide.md) — abrir solo cuando deba elegirse una arquitectura.
- [../_shared/context7.md](../_shared/context7.md) — Abrir solo para confirmar versiones/APIs externas con documentación actualizada.
- [../_shared/engram.md](../_shared/engram.md) — Abrir solo para recuperar decisiones históricas relevantes.
- [../_shared/handoff.md](../_shared/handoff.md) — Abrir solo para handoff complejo.
- Si afecta a librerías/API pública Python, consulta [../_shared/python-libraries.md](../_shared/python-libraries.md). Abrir solo en ese caso.


## Evidencia requerida
- Incluye tests representativos; ejecuta verificaciones rápidas pertinentes.
- Al cerrar cambios de código, entrega el estado al coordinador para verificación independiente con `quality-gate`.
- No modifiques los umbrales de `quality-gates.toml` ni desactives CI para pasar una tarea.

## Arquitecturas bajo demanda
Cuando corresponda, abre [selección](../_shared/architecture/decision-guide.md) y después **solo el diseño elegido**: [Clean](../_shared/architecture/clean.md), [Hexagonal](../_shared/architecture/hexagonal.md) o [Capas](../_shared/architecture/layered.md).

## Ejemplos de activación
- Sí: tarea de refactor conservador solicitada explícitamente o necesaria para una entrega verificable.
- No: no activar para trabajos ajenos al rol ni para repetir verificaciones ya acreditadas.

## Entrega
Estado (PASS/FAIL/BLOCKED/no-aplica), cambios/rutas, verificaciones con comando y código de salida, riesgos y `skill_resolution` si fue proporcionado.
