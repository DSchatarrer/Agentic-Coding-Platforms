---
name: plan
description: Planifica cambios complejos, elige arquitectura proporcional y define criterios de aceptación; úsala ante diseño, dependencias o migraciones importantes.
---
# Planificación técnica (no SDD)

## Procedimiento mínimo
1. Identifica propósito, alcance, restricciones, código existente y riesgos. Recupera decisiones previas mediante Engram solo cuando afecten al plan.
2. Para tareas triviales entrega un plan de 2-4 pasos sin diseñar una arquitectura nueva. Para cambios complejos abre [references/planning.md](references/planning.md).
3. Si hay decisión arquitectónica, consulta primero [../_shared/architecture/decision-guide.md](../_shared/architecture/decision-guide.md) y **solo** el patrón pertinente: [Clean](../_shared/architecture/clean.md), [Hexagonal](../_shared/architecture/hexagonal.md) o [Capas](../_shared/architecture/layered.md).
4. Define tareas pequeñas delegables, dependencias, dueño, pruebas objetivas, rollback y nivel de riesgo. No implementes código ni lances subagentes.
5. Devuelve decisiones y alternativas, criterios de aceptación y evidencia requerida para `quality-gate`. No impongas fases SDD.

## Referencias bajo demanda
- [references/planning.md](references/planning.md) — solo para cambios amplios con dependencias múltiples.
- [../_shared/engram.md](../_shared/engram.md) — al necesitar recordar decisiones.
- [../_shared/context7.md](../_shared/context7.md) — ante dudas de API o versión externa.
- [../_shared/python-libraries.md](../_shared/python-libraries.md) — solo si planifica librería o API pública Python.
- [../_shared/handoff.md](../_shared/handoff.md) — handoff complejo entre agentes.

- Para crear, auditar o continuar un `TODO.md` ejecutable, usa [references/todo-tracker.md](references/todo-tracker.md) **solo en ese tipo de trabajo**, preservando trazabilidad y evidencia, sin imponerlo como plantilla para todas las tareas.

## Ejemplos de activación
- Sí: «diseña módulos y responsabilidades de un motor predictivo con varios adaptadores».
- No: «corrige este typo»; el coordinador delega directamente al especialista.

## Entrega
`status`, objetivo, decisión de arquitectura si aplica, ADR resumida, mapa de módulos, tareas y dependencias, acceptance criteria verificables, tests/gates propuestos, riesgos, rollback y memoria consultada o guardada realmente.
