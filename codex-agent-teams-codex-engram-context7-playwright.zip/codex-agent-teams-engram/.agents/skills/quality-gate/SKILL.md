---
name: quality-gate
description: Verifica evidencias y bloquea entregas; usa al cerrar cambios de código.
---
# Skill de quality-gate

## Procedimiento mínimo
1. Lee el objetivo y define el alcance acotado de aceptación basada en evidencias.
2. Identifica criterios observables y ejecuta las acciones necesarias; evita herramientas externas si no aportan evidencia.
3. Registra comandos ejecutados, resultados reales y riesgos residuales.

## Referencias bajo demanda
- [../_shared/playwright-mcp.md](../_shared/playwright-mcp.md) — consultar **solo** solo si un gate aprobado exige validación exploratoria de navegador; no confundir con Playwright Test.
- [../_shared/architecture/verification.md](../_shared/architecture/verification.md) — solo si la política incluye reglas de arquitectura.
- [references/acceptance.md](references/acceptance.md) — abrir solo cuando un caso difícil requiera esta guía.
- [../_shared/context7.md](../_shared/context7.md) — Abrir solo para confirmar versiones/APIs externas con documentación actualizada.
- [../_shared/engram.md](../_shared/engram.md) — Abrir solo para recuperar decisiones históricas relevantes.
- [../_shared/handoff.md](../_shared/handoff.md) — Abrir solo para handoff complejo.


## Reglas de aceptación
- No aprobar basándose únicamente en texto del ejecutor; ejecutar comandos reales.
- Usa `python .agents/skills/quality-gate/scripts/run_gates.py --project-root . --profile full` para cambios de código, tras configurar `quality-gates.toml`.
- Si falta política, tooling, test o métrica, el estado es `BLOCKED`, nunca `PASS`.
- En cambios críticos usar perfil `critical`, con mutación/seguridad configuradas y umbrales reales.
- Un `PASS` en el equipo local no sustituye CI en rama protegida: el autor puede modificar la política o los tests.
- Si el perfil no está definido, pedir al responsable configurar el umbral; no inventarlo.

## Ejemplos de activación
- Sí: tarea de aceptación basada en evidencias solicitada explícitamente o necesaria para una entrega verificable.
- No: no activar para trabajos ajenos al rol ni para repetir verificaciones ya acreditadas.

## Entrega
Estado (PASS/FAIL/BLOCKED/no-aplica), cambios/rutas, verificaciones con comando y código de salida, riesgos y `skill_resolution` si fue proporcionado.
