# Context7 — documentación HTTP oficial, bajo demanda

Servidor remoto oficial para Codex (no Node local):
```toml
[mcp_servers.context7]
url = "https://mcp.context7.com/mcp"
```
La autenticación, si se exige, se realiza con `codex mcp login context7` cuando está soportado; alternativa API key mediante `bearer_token_env_var = "CONTEXT7_API_KEY"` y variable de entorno, sin secretos en Git.

## Cuando usar
Dudas sobre APIs, cambios de versión, compatibilidad, deprecaciones o ejemplos externos. Prioriza código y versiones ya instaladas; consulta Context7 para verificar diferencias, filtra versión y usa lo necesario. En host con herramienta disponible, `resolve-library-id` y `query-docs` o nombres reales expuestos. No afirmar que existe una función sin documento o runtime.

No envíes secretos ni código propietario como consulta. Si el MCP no está disponible, comunica incertidumbre y usa fuentes oficiales cuando las tengas.

Fuente: https://github.com/upstash/context7/blob/master/packages/mcp/README.md
