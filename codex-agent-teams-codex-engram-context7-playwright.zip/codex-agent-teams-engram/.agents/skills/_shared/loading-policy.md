# Política de carga bajo demanda

Un especialista abre su propia skill de rol siempre. El coordinador transmite solo contexto de tarea y reglas compactas auto-resueltas. Abrir referencias de arquitectura, Engram o Context7 únicamente al necesitar su contenido.
