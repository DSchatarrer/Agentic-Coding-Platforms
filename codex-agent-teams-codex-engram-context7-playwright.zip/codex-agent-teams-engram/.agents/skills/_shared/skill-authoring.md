# Skills breves y precisas

Preferir instrucciones cortas, descripciones con disparadores claros, referencias abiertas bajo demanda, scripts deterministas solo donde aporten valor y pruebas de activación/no activación.
