# Persistencia no-SDD — contrato de agentes

## Modalidad de memoria
`auto` (recomendado): si está disponible Engram MCP, consultar y guardar **solo** decisiones y handoffs duraderos; si falla, continuar donde sea seguro y señalar la limitación.
`off`: no consultar ni guardar memorias, solo si el usuario lo indica.

Estas modalidades se refieren **exclusivamente a memoria**: no determinan permisos de escritura en el proyecto. El código, tests, documentación y `TODO.md` se guardan directamente en el repositorio si el usuario y el rol lo permiten.

## Coordinador / subagentes
- El coordinador obtiene la identidad de proyecto, recupera solo contexto relevante, delega con ruta de skill + objetivos + refs reales de Engram.
- Cada ejecutor lee su `SKILL.md`; puede recuperar observaciones completas bajo demanda si el prompt trae refs. No delega.
- Cada agente documenta `engram_read`, `engram_written` o `unavailable`, sin fingir integraciones.
- Al cerrar, el coordinador no usa únicamente memorias como evidencia: solicita tests, rutas, comandos y verificación independiente.
- Para consultas de documentación externa, Context7; para navegador Playwright MCP; para decisiones previas, Engram. No mezclar herramientas.

## Recuperación tras compactación
Recuperar decisiones y handoffs mediante búsqueda y lectura completa por ID; recuperar hechos del repositorio mediante inspección actual. No aplicar el DAG SDD de Agent Teams Lite.

Ver [Engram](engram.md), [convención](engram-convention.md) y [handoff](handoff.md).
