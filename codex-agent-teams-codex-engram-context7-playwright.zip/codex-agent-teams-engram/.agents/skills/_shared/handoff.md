Referencia opcional de [persistencia](persistence-contract.md) para handoffs que crucen sesiones.

# Contrato común de handoff (agente → coordinador)

Respuesta compacta (JSON cuando el coordinador lo requiera):
```json
{
  "status": "PASS | FAIL | BLOCKED | no-aplica",
  "summary": "qué se hizo, qué NO se hizo",
  "artifacts": ["rutas relativas verificables"],
  "validation": [{"command": "...", "exit_code": 0, "result": "..."}],
  "architecture_decision": "ADR o null",
  "risks": ["..."],
  "next_recommended": ["..."],
  "skill_resolution": ["estándares realmente aplicados"],
  "engram_read": ["ids reales o unavailable"],
  "engram_written": ["ids reales o unavailable"],
  "quality_report": "ruta real o null"
}
```
No declarar PASS general si falta un Quality Gate obligatorio. No afirmar ejecución de tests, servidor MCP ni cambios que no se hayan realizado. Para Quality Gate adjuntar `report_path` y `policy_sha256` de JSON verificable.
