# Playwright MCP oficial — uso selectivo en Codex

Playwright MCP (Microsoft) permite inspección e interacción **real** con páginas web mediante las herramientas de navegador expuestas por MCP. No es Playwright Agent CLI ni Playwright Test.

## Cuándo activar
- `test`: pruebas funcionales de una UI en ejecución, flujos de usuario, regresiones visuales con pruebas reales.
- `debug`: reproducir bugs del navegador y capturar consola, accesibilidad, capturas y navegación si las herramientas disponibles lo permiten.
- `create`: comprobar la interfaz entregada **después** de implementarla si hay un servidor de desarrollo disponible.
- `review`: investigar un riesgo UX/seguridad observable en el producto ejecutado, sin realizar cambios.
- `quality-gate`: solo verificación exploratoria complementaria **si** la política de aceptación la exige; para E2E repetible usa un comando Playwright Test definido en quality-gates.toml.

## Cuándo NO activar
- No emplear navegador para editar lógica de backend, ejecutar unit tests, planificar, leer código o consultar docs de dependencias (para eso Context7).
- No abrir páginas externas arbitrarias ni entrar en cuentas privadas o producción sin autorización y alcance expresos.
- No introducir secretos en prompts, capturas, logs ni artefactos; aislar perfil, no persistir cookies de sesión.
- No afirmar cobertura E2E por haber navegado exploratoriamente. Reportar pasos exactos, URL/entorno, comportamiento esperado vs observado y limitaciones.

## Requisitos y conexión
- Node.js >= 20 y `npx` accesible desde Codex; el navegador se instala cuando haga falta.
- Configuración: `[mcp_servers.playwright]` con `npx -y @playwright/mcp@latest --headless --isolated`.
- El MCP se registra al arrancar Codex, pero **solo se invocan sus herramientas si el trabajo necesita navegador**. El MCP no equivale a una suite de tests automática.
- Si se requiere UI visible, retirar `--headless` conscientemente; si se necesitan sesiones autenticadas, analizar permisos/aislamiento antes de retirar `--isolated`.
- Si MCP no está accesible, declarar `BLOCKED` para los checks obligatorios; para checks opcionales documentar limitación sin inventar resultados.

## Evidencia del navegador
Registrar aplicación y URL (sin tokens), pasos realizados, resultados, errores reales, capturas si existen y ruta del test reproducible (si se añadió). El estado de `quality-gate` sigue dependiendo de la política y de comandos efectivamente ejecutados.

Fuentes oficiales: https://playwright.dev/mcp/installation , https://playwright.dev/mcp/configuration/options , https://playwright.dev/mcp/configuration/user-profile , https://playwright.dev/mcp/introduction
