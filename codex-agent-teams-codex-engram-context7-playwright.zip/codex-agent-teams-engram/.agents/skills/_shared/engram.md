# Engram — protocolo compartido para roles no-SDD

**No es un segundo repositorio de código**: Engram guarda decisiones, convenciones, causas raíz y handoffs duraderos. La fuente de verdad del estado actual es Git + código + tests.

## Conexión real a Codex
- El usuario tiene Engram local. Para activar integración **real** (MCP, protocolo y hooks) en Codex, usar `engram setup codex` una sola vez si hace falta, realizado por el usuario, fuera del instalador; luego reiniciar Codex.
- Codex hereda los MCP de la sesión principal para subagentes. Verificar con `codex mcp list` y comprobar las herramientas efectivamente expuestas. No inventar tool names, `session_id`, resultado de llamadas ni acceso a Engram.
- No sustituir el prompt base de Codex con `model_instructions_file` para forzar memoria.
- No iniciar una segunda instancia ni modificar la SQLite, la URL del core o claves locales.

Ver [convención de artefactos](engram-convention.md) y [contrato de persistencia](persistence-contract.md) si hay que recuperar/compartir memoria entre agentes. No cargarlos para consultas triviales.

## Recuperación selectiva
1. Al iniciar un trabajo donde importan decisiones previas, `mem_current_project` y confirmar proyecto identificado.
2. Usar `mem_search` con palabras clave/ID del proyecto y **leer completo** con `mem_get_observation` cuando el resultado sea preview.
3. Descartar entradas obsoletas frente a código/config actual. Los agentes pueden modificar código aunque Engram esté temporalmente indisponible; deben señalar la limitación.

## Persistencia cuando hay evidencia
- Tras cambios significativos: `mem_save` de decisión, porqué, alternativas, resultado de tests y rutas, sin pegar código grande.
- Clave conceptual `agent-teams/{project}/{kind}/{slug}` cuando la herramienta admita identificar un tema; ajustarse al esquema de API disponible, **no** inventar campos.
- No guardar secretos, datos sensibles, tokens, cadenas de conexión o logs con credenciales.
- Cada rol devuelve `engram_read` y `engram_written` con refs reales si existen; `unavailable` cuando corresponda.

## Handoff entre agentes
El agente A guarda decisiones verificadas en Engram y devuelve rutas/ref IDs **reales** al coordinador. El coordinador pasa al agente B refs, objetivo y criterios, sin pegar memoria completa. B la recupera del mismo MCP, comprueba vigencia en repositorio, trabaja, devuelve evidencia y guarda nueva decisión si es duradera.

Fuente: https://github.com/Gentleman-Programming/engram/blob/main/docs/AGENT-SETUP.md
