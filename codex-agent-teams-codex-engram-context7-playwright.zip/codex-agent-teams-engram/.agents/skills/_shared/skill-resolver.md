# Resolver de estándares del proyecto

Usar únicamente antes de delegar código. Buscar `skill-registry` en Engram, `.atl/skill-registry.md` o `.agents/skills/_shared/project-skill-registry.md` si existen; resolver hasta **cinco** reglas compactas por ruta/tecnología/acción. Si se usa `mem_search`, recuperar la observación real mediante `mem_get_observation` y verificar pertinencia. No inventar registros. Inyectar `## Project Standards (auto-resolved)` sin sustituir el SKILL.md de rol.
