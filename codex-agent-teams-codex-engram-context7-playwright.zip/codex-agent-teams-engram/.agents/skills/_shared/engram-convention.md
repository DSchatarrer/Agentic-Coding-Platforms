# Convención de artefactos en Engram — sin SDD

Usa una única memoria Engram local compartida entre agentes. Almacena conocimientos **duraderos**, no todo el chat ni copias indiscriminadas del repositorio. Los datos del código y Git son la fuente de verdad para el estado del proyecto.

## Nombres estables
Cuando la versión de `mem_save` exponga `project` y `topic_key`, emplea:
- `project`: proyecto detectado realmente.
- `title` y `topic_key`: `agent-teams/{project}/{kind}/{slug}`.
- `kind`: `decision`, `bugfix`, `discovery`, `pattern`, `handoff`, `validation` (solo si el tipo real de Engram permite este valor; **no inventar** esquema de campos ni tipos).
- `content`: qué se decidió, por qué, alternativas, rutas afectadas y evidencia.

Si el MCP disponible no expone `topic_key`, guarda con parámetros que sí soporte y devuelve el ID real. No afirmes upsert/deduplicación sin verificar.

## Recuperar por referencia (no usar previews como fuente)
1. Obtener contexto del proyecto con la herramienta disponible (`mem_current_project` si está expuesta).
2. `mem_search` de contexto relevante + proyecto y guardar el ID **real**.
3. `mem_get_observation(id)` para leer el contenido completo. El preview puede ser truncado.
4. Contrastar los hallazgos con el código actual; descartar memorias obsoletas.

## Persistencia y traspaso
- El especialista responsable escribe un resumen durable cuando termina con hallazgos no triviales; devuelve IDs y rutas al orquestador.
- El coordinador delega refs/objetivo/criterios al siguiente agente; éste recupera los datos completos, sin exigir que el coordinador pegue el contexto íntegro.
- Prohibido almacenar claves API, información sensible y logs privados.
- Engram inaccesible: informar `unavailable`. Esto **no** debe bloquear por defecto la escritura de código.

Adaptado de la convención compartida de Agent Teams Lite aportada por el usuario (sin `sdd/` ni artefactos OpenSpec).
