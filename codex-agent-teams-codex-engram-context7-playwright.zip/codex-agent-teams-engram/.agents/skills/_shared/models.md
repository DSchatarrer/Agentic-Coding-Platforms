# Modelos

Mantener modelos existentes; `plan` usa gpt-6-astra/medium, los demás gpt-6-sol/low. Cualquier escalado lo decide el usuario; no cambiar configuraciones silenciosamente.
