---
name: review
description: Audita código sin editar; usa para riesgos, seguridad y regresiones.
---
# Skill de review

## Procedimiento mínimo
1. Lee el objetivo y define el alcance acotado de revisión independiente.
2. Identifica criterios observables y ejecuta las acciones necesarias; evita herramientas externas si no aportan evidencia.
3. Registra comandos ejecutados, resultados reales y riesgos residuales.

## Referencias bajo demanda
- [../_shared/playwright-mcp.md](../_shared/playwright-mcp.md) — consultar **solo** al auditar un flujo web ejecutado con evidencia observable; no confundir con Playwright Test.
- [../_shared/architecture/verification.md](../_shared/architecture/verification.md) — solo al revisar dependencias, puertos, capas o infracciones arquitectónicas.
- [references/reviewing.md](references/reviewing.md) — abrir solo cuando un caso difícil requiera esta guía.
- [../_shared/context7.md](../_shared/context7.md) — Abrir solo para confirmar versiones/APIs externas con documentación actualizada.
- [../_shared/engram.md](../_shared/engram.md) — Abrir solo para recuperar decisiones históricas relevantes.
- [../_shared/handoff.md](../_shared/handoff.md) — Abrir solo para handoff complejo.
- Si afecta a librerías/API pública Python, consulta [../_shared/python-libraries.md](../_shared/python-libraries.md). Abrir solo en ese caso.


## Quality Gate
Diferencia revisión semántica de resultado del runner. Señala tests adulterados, desviaciones de calidad y cambios de política.

## Ejemplos de activación
- Sí: tarea de revisión independiente solicitada explícitamente o necesaria para una entrega verificable.
- No: no activar para trabajos ajenos al rol ni para repetir verificaciones ya acreditadas.

## Entrega
Estado (PASS/FAIL/BLOCKED/no-aplica), cambios/rutas, verificaciones con comando y código de salida, riesgos y `skill_resolution` si fue proporcionado.
