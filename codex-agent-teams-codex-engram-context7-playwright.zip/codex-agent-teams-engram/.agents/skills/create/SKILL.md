---
name: create
description: Implementa cambios concretos; usa cuando haya que crear código o módulos.
---
# Skill de create

## Procedimiento mínimo
1. Lee el objetivo y define el alcance acotado de implementación incremental.
2. Identifica criterios observables y ejecuta las acciones necesarias; evita herramientas externas si no aportan evidencia.
3. Registra comandos ejecutados, resultados reales y riesgos residuales.

## Referencias bajo demanda
- [../_shared/playwright-mcp.md](../_shared/playwright-mcp.md) — consultar **solo** al implementar frontend que precise inspección funcional real; no confundir con Playwright Test.
- [../_shared/architecture/README.md](../_shared/architecture/README.md) — solo si la tarea requiere decidir fronteras o respetar arquitectura del proyecto.
- [references/implementation.md](references/implementation.md) — abrir solo cuando un caso difícil requiera esta guía.
- [../_shared/context7.md](../_shared/context7.md) — Abrir solo para confirmar versiones/APIs externas con documentación actualizada.
- [../_shared/engram.md](../_shared/engram.md) — Abrir solo para recuperar decisiones históricas relevantes.
- [../_shared/handoff.md](../_shared/handoff.md) — Abrir solo para handoff complejo.
- Si afecta a librerías/API pública Python, consulta [../_shared/python-libraries.md](../_shared/python-libraries.md). Abrir solo en ese caso.


## Evidencia requerida
- Incluye tests representativos; ejecuta verificaciones rápidas pertinentes.
- Al cerrar cambios de código, entrega el estado al coordinador para verificación independiente con `quality-gate`.
- No modifiques los umbrales de `quality-gates.toml` ni desactives CI para pasar una tarea.

## Ejemplos de activación
- Sí: tarea de implementación incremental solicitada explícitamente o necesaria para una entrega verificable.
- No: no activar para trabajos ajenos al rol ni para repetir verificaciones ya acreditadas.

## Entrega
Estado (PASS/FAIL/BLOCKED/no-aplica), cambios/rutas, verificaciones con comando y código de salida, riesgos y `skill_resolution` si fue proporcionado.
