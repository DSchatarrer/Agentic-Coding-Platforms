---
name: research
description: Investiga código y documentación sin editar; usa cuando se necesite evidencia técnica.
---
# Skill de research

## Procedimiento mínimo
1. Lee el objetivo y define el alcance acotado de investigación verificable.
2. Identifica criterios observables y ejecuta las acciones necesarias; evita herramientas externas si no aportan evidencia.
3. Registra comandos ejecutados, resultados reales y riesgos residuales.

## Referencias bajo demanda
- [references/investigation.md](references/investigation.md) — abrir solo cuando un caso difícil requiera esta guía.
- [../_shared/context7.md](../_shared/context7.md) — Abrir solo para confirmar versiones/APIs externas con documentación actualizada.
- [../_shared/engram.md](../_shared/engram.md) — Abrir solo para recuperar decisiones históricas relevantes.
- [../_shared/handoff.md](../_shared/handoff.md) — Abrir solo para handoff complejo.


## Ejemplos de activación
- Sí: tarea de investigación verificable solicitada explícitamente o necesaria para una entrega verificable.
- No: no activar para trabajos ajenos al rol ni para repetir verificaciones ya acreditadas.

## Entrega
Estado (PASS/FAIL/BLOCKED/no-aplica), cambios/rutas, verificaciones con comando y código de salida, riesgos y `skill_resolution` si fue proporcionado.
