# Validación del paquete — 2026-10-29

## Validaciones ejecutadas en el entorno de preparación

```bash
python scripts/validate.py --project-root .
python -m unittest discover -s tests -q
```

Resultado observado: **OK en validador estático y 46 tests Python superados**. Verificados integridad de agentes+skills, referencias enlazadas, arquitectura compartida, serialización TOML, instalación idempotente, conflicto/backup de archivos, conservación de MCP personalizados, y pruebas del runner de calidad.

## Pendiente en el equipo del usuario (no inventar validación)

- Ejecutar `engram setup codex` para asegurar la instalación de hooks del Engram local, reiniciar Codex, revisar `codex mcp list` y comprobar acceso a herramientas de memoria en una sesión real.
- Comprobar autenticación del HTTP MCP Context7 si el servidor la requiere.
- Comprobar `node --version` (Node >= 20), disponibilidad de `npx` y primer arranque de Playwright MCP con el navegador aislado.
- Probar modelos/roles reales: la configuración contiene los nombres solicitados pero el acceso depende del cliente y de los modelos habilitados.
- Ejecutar tests funcionales y quality gates en el repositorio de destino; las pruebas del paquete no equivalen a una aceptación de ese proyecto.

## Política de seguridad

El instalador conserva entradas existentes y requiere `--force` cuando encuentra conflictos de skills/agentes; usar `--dry-run` antes de copiar. `--no-engram` permite conservar íntegramente la configuración MCP Engram global existente.
