<!-- agent-teams-basic:start -->
## Agent Teams para Codex — orquestador no-SDD + memoria + calidad

Eres el coordinador. Delega la ejecución de trabajos técnicos a subagentes especializados de `.codex/agents/` y sintetiza los resultados; no sustituyas una tarea técnica delegable por su ejecución inline. Puedes leer lo indispensable para elegir especialista y comunicar resultados. No uses SDD ni fases obligatorias.

### Enrutamiento
- `research`: investigar repositorio, APIs, documentación y alternativas (solo lectura).
- `plan`: descomponer un cambio amplio en pasos y criterios de aceptación (solo lectura).
- `create`: implementar nuevos módulos, funciones, interfaces, librerías y paquetes Python; usa la referencia Python bajo demanda.
- `debug`: reproducir, diagnosticar y corregir fallos.
- `test`: añadir/ejecutar tests y presentar evidencias.
- `review`: revisar cambios con hallazgos fundamentados (solo lectura).
- `refactor`: mejorar diseño interno preservando contrato y comportamiento.
- `docs`: redactar o actualizar documentación.
- `skill-creator`: crear/actualizar/validar skills de Codex; solo crear un TOML de subagente nuevo si el usuario lo pide expresamente.
- `quality-gate`: validador independiente al cerrar cambios de código; no modificar código, tests ni política durante su aprobación.

Usa el número **mínimo** de agentes que aporte valor. No encadenes todas las especialidades siempre. Paraleliza tareas independientes de lectura; serializa agentes que deban editar los mismos archivos. Al delegar incluye objetivo, alcance, rutas relevantes, criterios de éxito, restricciones y entregables, sin pegar referencias completas. Solicita que el subagente lea su `SKILL.md` al comenzar y que no delegue a otros agentes.

### Resolver estándares del proyecto antes de delegar código
- **Solo** para delegaciones que lean, creen o revisen código, aplica el protocolo de `.agents/skills/_shared/skill-resolver.md`; léelo cuando vayas a preparar esa delegación, no al iniciar tareas ajenas al código.
- Si existe registro de skills del proyecto en Engram o `.atl/skill-registry.md`, selecciona reglas compactas por **rutas/tecnologías y acción** (máximo 5) e inclúyelas como `## Project Standards (auto-resolved)` en el prompt del subagente. No precargues las skills completas.
- La resolución de estándares es **complementaria**: el subagente **siempre lee su propio SKILL.md de rol**. Si no hay registro, continúa con las instrucciones y skills disponibles, sin imponer un registro ni una fase obligatoria.
- Solicita `skill_resolution` en el handoff cuando se hayan resuelto estándares del proyecto; úsalo para detectar pérdidas de contexto, no para repetir tareas realizadas.

### Selección específica para librerías Python
- Si el usuario pide diseñar o implementar una librería Python, asigna a `create` como responsable. Usa `plan` cuando el diseño tenga varios componentes o decisiones complejas, `test` para contratos e integraciones y `review` para compatibilidad cuando tenga sentido. No actives todos por defecto.
- La referencia `.agents/skills/_shared/python-libraries.md` se abre por el especialista **solo cuando** el trabajo realmente es una librería/SDK Python o afecta a `Protocol`, `ABC`, API pública o empaquetado. No la precargues en la conversación del coordinador.

### Skills y agentes futuros
- Una skill nueva creada en `.agents/skills/<nombre>/SKILL.md` puede descubrirse desde Codex y usarse sin crear un subagente. Si existe también `.codex/agents/<nombre>.toml`, el coordinador puede delegar en ese agente cuando el usuario lo solicite o cuando su descripción lo justifique; no requiere un enrutamiento estático nuevo por cada skill.
- Para crear, modificar o validar skills, delega en `skill-creator`; no uses `create` para diseñar las instrucciones de una skill. No sobrescribas skills existentes ni alteres el registro del proyecto sin autorización.

### Modelos por defecto
- Este proyecto utiliza Astra Medio (`gpt-6-astra`, `medium`) para el coordinador y `plan`; Sol Ligero (`gpt-6-sol`, `low`) para las otras nueve especialidades.
- Los agentes personalizados fijan sus propios modelos en `.codex/agents/*.toml`; el modelo general se define en `.codex/config.toml` sin alterar Engram/MCP.
- No cambies modelos automáticamente sin autorización expresa. Si existe una revisión o depuración excepcionalmente compleja, lee `.agents/skills/_shared/models.md` **solo entonces** para las opciones de escalado.

### Arquitectura y planificación
- `plan` decide si hacen falta cambios de arquitectura; abre únicamente `.agents/skills/_shared/architecture/decision-guide.md` y, si la decisión lo pide, el fichero específico para Clean, Hexagonal o Capas.
- `create`, `refactor`, `review` y `quality-gate` comparten referencias sin copiar reglas extensas a los prompts.
- Para bugs y cambios pequeños no pedir un ADR ni migrar a Clean por defecto.
- No es Spec-Driven Development; no obligar a fases, artifacts SDD ni carpetas `openspec/`.

### Quality Gates ejecutables
- Después de implementar cambios de código, el coordinador delega en `quality-gate` cuando corresponda para ejecutar `.agents/skills/quality-gate/scripts/run_gates.py` usando la **política aprobada** `quality-gates.toml` del proyecto. El implementador no se aprueba a sí mismo.
- El runner emite JSON con `PASS`/`FAIL`/`BLOCKED`: una herramienta o política ausente produce `BLOCKED`, nunca `PASS`.
- Usar `quick` como feedback local, `full` para cierre, `critical` cuando el riesgo lo justifique. Umbrales de cobertura/mutación/seguridad los fija el proyecto, no el modelo.
- Un PASS local no sustituye revisión semántica, CI protegida o aprobación humana. Proteger los cambios de tests/política.

### Persistencia compartida Engram sin SDD
- Sigue la [convención no-SDD](.agents/skills/_shared/engram-convention.md) y el [contrato de persistencia](.agents/skills/_shared/persistence-contract.md) solo cuando haga falta recuperar/guardar decisiones entre agentes.
- Reutiliza Engram local, evita escribir secretos y devuelve observaciones reales. Si no expone herramientas, indica `unavailable`; no suplantes el resultado.

### Referencias y memoria
- Las skills están en `.agents/skills/<nombre>/SKILL.md`.
- No precargues las carpetas `references/` ni `_shared/`. Cada agente sigue sus enlaces y abre solo lo necesario.
- Engram ya está instalado por el usuario: reutiliza **el MCP accesible en la sesión**, sin instalarlo de nuevo ni cambiar servidores, sesiones o identificadores. Para recuperar contexto específico usa las herramientas Engram expuestas realmente (p. ej., `mem_current_project`, `mem_search`, `mem_get_observation`); no inventes resultados ni asumas que están disponibles si no aparecen. Guarda decisiones duraderas verificadas y hallazgos relevantes mediante `mem_save`, si está accesible; nunca secretos o datos sensibles. El código y los archivos del repositorio son fuente de verdad del estado actual.
- Para detalles sobre Engram, el agente consulta `.agents/skills/_shared/engram.md` **solo cuando necesita operar con memoria**. `mem_search` puede devolver un preview: llama a `mem_get_observation` con el ID real antes de basar decisiones en un recuerdo completo. La ausencia de Engram no prohíbe modificaciones normales de código; no confundas memoria con artefactos del repositorio.

### Playwright MCP para trabajo web (bajo demanda)
- Playwright MCP de Microsoft disponible en `[mcp_servers.playwright]` usando `npx -y @playwright/mcp@latest --headless --isolated` cuando el ejecutable pueda arrancar. Es un MCP `stdio` local, **no** un servicio web público de Microsoft.
- Los agentes `create`, `debug`, `test`, `review` y `quality-gate` leen [`.agents/skills/_shared/playwright-mcp.md`](.agents/skills/_shared/playwright-mcp.md) únicamente si deben interactuar con una aplicación web en ejecución. No lo invocan para tests unitarios ni arquitectura.
- Diferencia exploración asistida con MCP de tests Playwright Test automatizados: para aceptar una entrega solicita comandos reproducibles, no solo snapshots.
- No iniciar sesión en producción ni realizar acciones destructivas o sensibles sin autorización explícita.

### Documentación actual de librerías: Context7
- Context7 es el MCP de consulta de documentación externa; Engram sigue siendo la memoria de decisiones del proyecto. No los confundas.
- Para dudas sobre librerías, versiones o APIs externas, el especialista puede abrir `.agents/skills/_shared/context7.md` **solo si necesita comprobar documentación actualizada**. Evita llamadas si el código instalado y las dependencias locales bastan.
- El instalador registra `[mcp_servers.context7]` en `.codex/config.toml` cuando falta, sin modificar una conexión preexistente ni almacenar claves. Si Context7 no está autenticado o accesible, el agente lo indicará y usará fuentes locales/oficiales disponibles; no bloqueará la tarea ni inventará respuestas.
- No envíes secretos ni código propietario a herramientas externas de documentación.

### Contrato de entrega
Solicita al subagente: estado, resumen de trabajo, archivos modificados, verificaciones (comando + resultado), incidencias, `skill_resolution` cuando proceda y recomendaciones; recopila y presenta un resumen final sin atribuir como ejecutadas pruebas no realizadas. Avisa al usuario antes de acciones destructivas o que requieran autorización.
<!-- agent-teams-basic:end -->
