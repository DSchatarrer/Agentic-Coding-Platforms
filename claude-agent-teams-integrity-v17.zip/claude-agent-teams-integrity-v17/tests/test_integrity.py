"""Regresiones de enlaces, rutas documentadas y registro tras instalación."""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]

def load(path):
    spec=importlib.util.spec_from_file_location('test_'+path.stem,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    return module

installer=load(ROOT/'scripts/install.py')
auditor=load(ROOT/'scripts/audit_integrity.py')

class IntegrityTests(unittest.TestCase):
    def test_package_markdown_and_doc_commands(self):
        errors,stats=auditor.audit(ROOT,source=True)
        self.assertEqual([],errors)
        self.assertGreater(stats['local_links'],100)
        self.assertGreater(stats['python_commands'],0)

    def test_broken_markdown_link_is_detected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            installer.install(root)
            p=root/'.claude/skills/create/references/implementation.md'
            p.write_text(p.read_text(encoding='utf-8')+'\n[bad](./file-does-not-exist.md)\n',encoding='utf-8')
            errors,_=auditor.audit(root)
            self.assertTrue(any('Enlace roto:' in e and 'file-does-not-exist.md' in e for e in errors),errors)

    def test_installed_project_is_self_verifiable(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            installer.install(root)
            for name in ['validate.py','audit_integrity.py','context_profile.py','git_init.py']:
                self.assertTrue((root/'scripts'/name).is_file(),name)
            for command in [
                ['scripts/validate.py','--project-root','.'],
                ['scripts/audit_integrity.py','--project-root','.'],
                ['.claude/skills/skill-creator/scripts/build_registry.py','--project-root','.','--check']
            ]:
                result=subprocess.run([sys.executable,*command],cwd=root,capture_output=True,text=True)
                self.assertEqual(0,result.returncode,command+ [result.stdout,result.stderr])
            self.assertFalse((root/'tests').exists(), 'No instalar tests externos en proyectos ajenos')

    def test_catalog_discovers_preexisting_project_skill(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            own=root/'.claude/skills/custom-skill/SKILL.md'
            own.parent.mkdir(parents=True)
            own.write_text('---\nname: custom-skill\ndescription: Skill creada previamente por el usuario\n---\n# Custom\n',encoding='utf-8')
            events=installer.install(root)
            catalog=(root/'.claude/skills/_shared/skill-catalog.md').read_text(encoding='utf-8')
            self.assertIn('custom-skill',catalog)
            self.assertTrue(any('CATÁLOGO: actualizado desde las skills reales' in x for x in events), events[-5:])
            standards=(root/'.claude/skills/_shared/project-skill-registry.md').read_text(encoding='utf-8')
            self.assertIn('## Entradas',standards)
            result=subprocess.run([sys.executable,'.claude/skills/skill-creator/scripts/build_registry.py',
                                   '--project-root','.','--check'],cwd=root,capture_output=True,text=True)
            self.assertEqual(0,result.returncode,result.stdout+result.stderr)

    def test_dry_run_does_not_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            installer.install(root,dry_run=True)
            self.assertFalse((root/'.claude').exists())
            self.assertFalse((root/'scripts').exists())

if __name__=='__main__': unittest.main()
