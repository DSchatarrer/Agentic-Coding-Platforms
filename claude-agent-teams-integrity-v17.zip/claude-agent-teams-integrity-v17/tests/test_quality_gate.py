"""Tests deterministic quality gate, no remote APIs or MCP required."""
from pathlib import Path
import importlib.util
import json
import sys
import tempfile

import unittest

ROOT = Path(__file__).resolve().parent.parent
RUNNER = ROOT/'.claude/skills/quality-gate/scripts/run_gates.py'

spec=importlib.util.spec_from_file_location('quality_runner', RUNNER)
runner=importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class QualityGateTests(unittest.TestCase):
    def _setup(self, source, gate='test', extra=''):
        tmp=tempfile.TemporaryDirectory()
        root=Path(tmp.name)
        py=sys.executable.replace('\\','\\\\')
        policy=root/'quality-gates.toml'
        policy.write_text(f'''[profiles.quick]
required = ["{gate}"]
[gates.{gate}]
command = ["{py}", "-c", {json.dumps(source)}]
{extra}
''',encoding='utf8')
        return tmp,root,policy

    def _run(self, root, policy, profile='quick'):
        return runner.run(root,policy,profile,Path('.quality/reports/latest.json'))

    def test_gate_pass_and_json_evidence(self):
        tmp,root,policy=self._setup('print("ok")')
        with tmp:
            report=self._run(root,policy)
            self.assertEqual(report['status'],'PASS')
            self.assertEqual(report['gates'][0]['status'],'PASS')
            saved=json.loads((root/'.quality/reports/latest.json').read_text())
            self.assertEqual(saved['status'],'PASS')
            self.assertEqual(len(saved['policy_sha256']),64)

    def test_gate_missing_python_module_blocked(self):
        tmp,root,policy=self._setup('print("ok")')
        with tmp:
            policy.write_text('''[profiles.quick]
required = ["test"]
[gates.test]
command = ["/opt/pyvenv/bin/python", "-m", "nonexistent_tool_99998888"]
''')
            report=self._run(root,policy)
            self.assertEqual(report['status'],'BLOCKED')

    def test_gate_fail_exit_code(self):
        tmp,root,policy=self._setup('raise RuntimeError("no")')
        with tmp:
            report=self._run(root,policy)
            self.assertEqual(report['status'],'FAIL')
            self.assertNotEqual(report['gates'][0]['returncode'],0)

    def test_gate_block_missing_executable(self):
        tmp,root,policy=self._setup('print("ok")')
        with tmp:
            policy.write_text('''[profiles.quick]
required=["test"]
[gates.test]
command=["no_such_bin_12345678", "--version"]
''')
            report=self._run(root,policy)
            self.assertEqual(report['status'],'BLOCKED')
            self.assertIn('Ejecutable ausente',report['gates'][0]['reason'])

    def test_gate_block_unmeasurable_threshold(self):
        tmp,root,policy=self._setup('print("ALL GOOD")',extra='''metric_pattern='SCORE: (?P<value>\\d+)'
min_value=80
''')
        with tmp:
            report=self._run(root,policy)
            self.assertEqual(report['status'],'BLOCKED')
            self.assertIn('medir',report['gates'][0]['reason'])

    def test_gate_enforces_threshold(self):
        tmp,root,policy=self._setup('print("SCORE: 70")',extra='''metric_pattern='SCORE: (?P<value>\\d+)'
min_value=80
''')
        with tmp:
            report=self._run(root,policy)
            self.assertEqual(report['status'],'FAIL')
            self.assertEqual(report['gates'][0]['metric']['value'],70)

    def test_missing_policy_blocked_not_passed(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            report=self._run(root,root/'quality-gates.toml')
            self.assertEqual(report['status'],'BLOCKED')
            self.assertEqual(report['gates'][0]['name'],'policy')

    def test_no_empty_profiles(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t)
            (root/'quality-gates.toml').write_text('''[profiles.full]
required=[]
[gates.test]
command=["true"]
''')
            self.assertEqual(self._run(root,root/'quality-gates.toml',profile='full')['status'],'BLOCKED')

    def test_ten_agent_skill_pairs_present(self):
        expected=['research','plan','create','debug','test','review','refactor','docs','quality-gate','skill-creator']
        for role in expected:
            self.assertTrue((ROOT/'.claude/skills'/role/'SKILL.md').is_file(),role)
            agent=(ROOT/'.claude/agents'/f'{role}.md').read_text()
            self.assertIn(f'name: {role}',agent)
            self.assertIn(f'  - {role}',agent)
        self.assertEqual({p.stem for p in (ROOT/'.claude/agents').glob('*.md')}, set(expected)|{'orchestrator'})
        self.assertIn('quality-gate', (ROOT/'CLAUDE.md').read_text().lower())

if __name__=='__main__': unittest.main()
