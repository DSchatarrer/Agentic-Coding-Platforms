"""Regresiones de la adaptación Ponytail/Caveman en el paquete Claude."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]

def load(path):
    spec=importlib.util.spec_from_file_location('int_'+path.stem,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

install=load(ROOT/'scripts/install.py')
validate=load(ROOT/'scripts/validate.py')

class Integration(unittest.TestCase):
    def test_manual_only_skill_frontmatter(self):
        meta,_=validate.frontmatter((ROOT/'.claude/skills/concise-output/SKILL.md').read_text())
        self.assertEqual('concise-output',meta['name'])
        self.assertEqual('true',meta['disable-model-invocation'])
        self.assertEqual('true',meta['user-invocable'])
    def test_no_new_agents(self):
        self.assertEqual(11,len(list((ROOT/'.claude/agents').glob('*.md'))))
        self.assertFalse((ROOT/'.claude/agents/concise-output.md').exists())
    def test_no_new_hooks_or_proxy(self):
        settings=json.loads((ROOT/'.claude/settings.json').read_text())
        self.assertNotIn('hooks',settings)
        self.assertNotIn('caveman',json.loads((ROOT/'.mcp.json').read_text())['mcpServers'])
        self.assertEqual('claude-opus-5-5',settings['model'])
        self.assertEqual('medium',settings['effortLevel'])
        self.assertEqual(False,settings['autoMemoryEnabled'])
    def test_no_standard_sixth(self):
        text=(ROOT/'.claude/skills/_shared/project-skill-registry.md').read_text()
        self.assertEqual(5,text.count('### '))
        self.assertEqual(1,text.count('### changed-code-tests'))
        self.assertIn('minimal-complete-change.md',text)
    def test_affected_roles_have_conditional_reference(self):
        for role in ('create','debug','refactor','review'):
            text=(ROOT/f'.claude/skills/{role}/SKILL.md').read_text()
            self.assertIn('../_shared/minimal-complete-change.md',text,role)
    def test_handoff_preserves_quality(self):
        text=(ROOT/'.claude/skills/_shared/handoff.md').read_text()
        self.assertIn('solo la respuesta destinada al usuario',text)
        self.assertIn('quality_gate',text)
        self.assertIn('pruebas ejecutadas/fallidas/no ejecutadas',text)
    def test_registry_valid(self):
        self.assertEqual([],validate.validate(ROOT))
    def test_installer_preserves_external_hooks_and_mcp_and_models(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);(p/'.claude').mkdir()
            settings={'agent':'custom','model':'my-model','hooks':{'SessionStart':[{'hooks':[{'type':'command','command':'echo ok'}]}]}}
            (p/'.claude/settings.json').write_text(json.dumps(settings))
            (p/'.mcp.json').write_text(json.dumps({'mcpServers':{'custom':{'type':'http','url':'https://example.invalid'}}}))
            install.install(p)
            new=json.loads((p/'.claude/settings.json').read_text())
            self.assertEqual('custom',new['agent'])
            self.assertEqual('my-model',new['model'])
            self.assertEqual(settings['hooks'],new['hooks'])
            self.assertIn('custom',json.loads((p/'.mcp.json').read_text())['mcpServers'])
            self.assertTrue((p/'.claude/skills/concise-output/SKILL.md').exists())
    def test_installer_dry_run_aux_absent(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);install.install(p,dry_run=True)
            self.assertFalse((p/'.claude/skills/concise-output/SKILL.md').exists())
    def test_installed_cat_generated_includes_aux(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);install.install(p)
            self.assertIn('`concise-output`',(p/'.claude/skills/_shared/skill-catalog.md').read_text())
    def test_validator_detects_reenabled_auto_invocation(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);install.install(p)
            s=p/'.claude/skills/concise-output/SKILL.md'
            s.write_text(s.read_text().replace('disable-model-invocation: true','disable-model-invocation: false'))
            self.assertTrue(any('opt-in' in e for e in validate.validate(p)))

if __name__=='__main__': unittest.main()
