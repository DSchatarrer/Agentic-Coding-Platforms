# Migración Claude Agent Teams v16 → v17: Ponytail + Caveman (adaptaciones)

## Cambios deliberadamente limitados

- **Ponytail (criterio de ingeniería):** misma entrada aprobada `changed-code-tests`; se amplía su regla compacta y se agrega `minimal-complete-change.md` como referencia progresiva. Roles afectados: `create`, `debug`, `refactor`, `review`; referencia de revisión ampliada. **No** se incorpora un sexto estándar ni se altera la allowlist del coordinador.
- **Caveman (Say Less):** nueva skill `concise-output` invocable con **`/concise-output`**, con `disable-model-invocation: true`. No se precarga en subagentes. La salida comprimida es solo una **presentación**, no una compresión de logs o resultados en tránsito.
- `handoff.md` refuerza las evidencias y evita pérdida de errores o pruebas. Las políticas de aceptación del `quality-gate` no cambian.
- No se activan proxy externo, Browse, Auto, Read Less, warm cache, scripts, hooks SessionStart/SubagentStart ni los agentes de ninguno de los dos proyectos. No se añaden servicios, tokens, dependencias ni accesos externos.
- Se mantienen modelos `claude-opus-5-5` / `claude-haiku-5-5`, niveles, Engram, Context7, Playwright y settings.

## Instalar o actualizar (PowerShell)

```powershell
py -3 scripts/install.py --project-root "C:\ruta\proyecto" --dry-run
py -3 scripts/install.py --project-root "C:\ruta\proyecto"
# Con v16 anterior, revisa los CONFLICTO; solo entonces:
py -3 scripts/install.py --project-root "C:\ruta\proyecto" --force
```

El instalador es conservador sin `--force`; con `--force` crea respaldos de archivos existentes y actualiza el bloque gestionado de `CLAUDE.md`. Preserva otras instrucciones fuera del bloque, MCP preexistentes y claves de settings ajenas. El catálogo es informativo y se reconstruye según las skills presentes en destino.

## Uso

```text
claude --agent orchestrator
```

- Normal: `Corrige este error; reutiliza el diseño existente, prueba la regresión y solicita revisión.` → Ponytail adaptado aplica mediante los roles/estándar relevante.
- Breve: `/concise-output Revisa el cambio y dime qué se modificó, pruebas reales y bloqueos.` → Caveman adaptado, activación manual.
- Consulta las skills mediante `/skills` en Claude Code actualizado. No uses `$concise-output` (convención de Codex).

## Riesgos y prueba de aceptación

- El usuario puede tener plugins Ponytail/Caveman instalados **globalmente**. Pueden introducir sus hooks igualmente; este paquete no los elimina. Examina `/hooks` y `/plugin` en Claude Code para evitar doble activación.
- Aunque se indique que `/concise-output` aplica a la petición actual, las instrucciones de una skill cargada pueden permanecer en el contexto de conversación. Para aislamiento fuerte de estilo abre una nueva sesión después de usarla.
- Las pruebas locales son **estáticas y de instalador**; no prueban ejecución de una sesión Claude ni ahorro de tokens. A/B real: mismas tareas, modelos/effort, tests y tokens, con y sin `/concise-output` y antes/después de la política mínima.
- Si el proyecto destino tiene reglas personalizadas, revisa el diff antes de `--force`.

## Fuentes oficiales y proyectos

- https://code.claude.com/docs/en/skills
- https://code.claude.com/docs/en/sub-agents
- https://code.claude.com/docs/en/hooks
- https://github.com/DietrichGebert/ponytail
- https://github.com/JuliusBrussee/caveman
