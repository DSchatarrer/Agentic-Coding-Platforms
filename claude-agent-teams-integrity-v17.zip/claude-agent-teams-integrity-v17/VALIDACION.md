# Evidencia de validación del artefacto

La migración conserva el runner determinista y los scripts de Git. El paquete se valida mediante `scripts/validate.py` y `scripts/audit_integrity.py`, comprobación reproducible del catálogo y tests unitarios en `tests/`.

Se comprueban, entre otros: 11 agentes Markdown, 10 skills con `skills:` en frontmatter, Opus/medium y Haiku/low, no subdelegación, referencias reales, MCP Context7 HTTP, Playwright scoped, Engram no duplicado en `.mcp.json`, conservación de ajustes ajenos, backups, política de memoria, Git init opcional, tests del Quality Gate y ausencia de rastros de configuración Codex en los puntos de entrada de Claude.

**Límite:** estas son comprobaciones estáticas y tests del instalador/runner en un entorno de pruebas. No confirman la existencia de modelos en la cuenta, las herramientas MCP conectadas en la máquina del usuario ni la delegación real en una sesión de Claude Code. Consultar README y MIGRACION_CLAUDE_V16 para probar esos aspectos.
