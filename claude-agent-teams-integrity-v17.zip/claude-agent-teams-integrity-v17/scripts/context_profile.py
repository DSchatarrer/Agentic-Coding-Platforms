#!/usr/bin/env python3
"""Static context budget proxy: word counts, never actual model token consumption."""
import argparse
import json
from pathlib import Path

CASES = {
    'typo': ('create', []),
    'bug-ui': ('debug', ['.claude/skills/_shared/playwright-mcp.md']),
    'api-design': ('plan', ['.claude/skills/plan/references/planning.md', '.claude/skills/_shared/architecture/decision-guide.md']),
    'todo-audit': ('plan', ['.claude/skills/plan/references/todo-audit.md', '.claude/skills/plan/references/todo-evidence.md']),
    'external-api': ('research', ['.claude/skills/_shared/context7.md']),
}

def measure(root):
    root = Path(root)
    words = lambda rel: len((root / rel).read_text(encoding='utf-8').split())
    base = words('CLAUDE.md')
    result = {'measure': 'word-count proxy; NOT actual tokens or runtime reads', 'orchestrator_words': base, 'cases': {}}
    for case, (role, references) in CASES.items():
        parts = ['CLAUDE.md', '.claude/agents/orchestrator.md', f'.claude/agents/{role}.md', f'.claude/skills/{role}/SKILL.md'] + references
        result['cases'][case] = {'selected_role': role, 'reference_files': references, 'hypothetical_words_if_selected': sum(words(x) for x in parts)}
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project-root', type=Path, default=Path(__file__).resolve().parent.parent)
    parser.add_argument('--json', action='store_true')
    args = parser.parse_args()
    report = measure(args.project_root)
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        print('Proxy estática (palabras; NO mide tokens ni llamadas reales):')
        print('CLAUDE.md:', report['orchestrator_words'])
        for name, data in report['cases'].items():
            print(f"{name}: {data['hypothetical_words_if_selected']} palabras, {len(data['reference_files'])} referencias condicionales")
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
