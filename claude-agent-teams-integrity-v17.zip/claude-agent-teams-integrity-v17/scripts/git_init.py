#!/usr/bin/env python3
"""Inicializa Git solo si la ruta no pertenece ya a un repositorio.

No crea commits, remotos, tags, ramas adicionales ni modifica .gitignore.
Requiere Python >=3.11 y git en PATH.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import subprocess


class GitInitError(RuntimeError):
    """No se puede asegurar una inicialización segura de Git."""


def _git_env() -> dict[str, str]:
    # Ignore inherited repository overrides, otherwise Git could point to another repo.
    return {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}


def ensure_git(project_root: Path, *, dry_run: bool = False) -> tuple[str, bool]:
    """Return (message, created); never initialize under an existing repo.

    - When dry_run=True, no repository is modified; created is always False.
    - A valid root or ancestor repository is considered already configured.
    - If Git diagnostics are ambiguous, raise instead of nesting a new repo.
    """
    root = Path(project_root).expanduser().resolve()
    if not root.is_dir():
        raise GitInitError(f'El directorio del proyecto no existe: {root}')
    git_bin = shutil.which('git')
    if not git_bin:
        raise GitInitError('Git no está instalado o no aparece en PATH; no se ha modificado el proyecto')
    env = _git_env()
    check = subprocess.run(
        [git_bin, '-C', str(root), 'rev-parse', '--show-toplevel'],
        capture_output=True, text=True, encoding='utf-8', errors='replace', env=env,
        check=False,
    )
    if check.returncode == 0:
        found = Path(check.stdout.strip()).resolve()
        if found == root:
            return f'IGUAL: Git ya está inicializado en {root}', False
        return f'IGUAL: el proyecto pertenece al repositorio padre {found}; no crear Git anidado', False

    # Existing .git can be a linked worktree file or damaged metadata. Never overwrite it.
    if (root / '.git').exists() or (root / '.git').is_symlink():
        raise GitInitError('Existe .git pero Git no reconoce el repositorio; revisar manualmente')
    error_text = (check.stderr + '\n' + check.stdout).lower()
    # Git returns nonzero for unsafe ownership, corrupt metadata, or an unsupported configuration.
    if 'not a git repository' not in error_text and 'no es un repositorio git' not in error_text:
        raise GitInitError('No se puede comprobar el estado de Git con seguridad: ' + check.stderr.strip())
    if dry_run:
        return f'DRY-RUN: ejecutaría git -C "{root}" init', False
    result = subprocess.run(
        [git_bin, '-C', str(root), 'init'], capture_output=True, text=True,
        encoding='utf-8', errors='replace', env=env, check=False,
    )
    if result.returncode != 0:
        raise GitInitError('git init ha fallado: ' + (result.stderr.strip() or result.stdout.strip()))
    verify = subprocess.run(
        [git_bin, '-C', str(root), 'rev-parse', '--show-toplevel'],
        capture_output=True, text=True, encoding='utf-8', errors='replace', env=env, check=False,
    )
    if verify.returncode or Path(verify.stdout.strip()).resolve() != root:
        raise GitInitError('Git devolvió éxito, pero no se pudo verificar el repositorio nuevo')
    return f'CREADO: repositorio Git inicializado en {root} (sin commits ni remoto)', True


def main() -> int:
    parser = argparse.ArgumentParser(description='git init seguro: solo en proyectos que aún no pertenecen a Git')
    parser.add_argument('--project-root', required=True, type=Path)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    try:
        message, _ = ensure_git(args.project_root, dry_run=args.dry_run)
    except GitInitError as exc:
        parser.exit(2, f'BLOQUEADO: {exc}\n')
    print(message)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
