# Auditoría de coherencia e integridad — Claude Code v16

Fecha: 2026-10-29. Base: ZIP Claude Code v15.

## Diagnóstico inicial

- **Enlaces Markdown:** 65 documentos, 126 enlaces locales, 0 enlaces rotos en el paquete v15.
- **Instalación incompleta:** `CLAUDE.md` y el README mencionaban `scripts/validate.py`; el README también incluía `scripts/context_profile.py`. El instalador v15 solo copiaba `scripts/git_init.py`, de modo que esos comandos fallaban tras instalar en un repositorio nuevo.
- **Catálogo incoherente tras instalar en un proyecto existente:** el inventario generado partía de las skills del ZIP. Un proyecto con skills propias necesitaba una regeneración manual que el instalador no realizaba.
- **Diferencia entre fuente y destino:** las pruebas `tests/` pertenecen al proyecto del paquete y no se copian a un repositorio ajeno; la documentación anterior no diferenciaba suficientemente ambos contextos.

## Cambios introducidos

1. El instalador ahora copia cuatro herramientas: `git_init.py`, `validate.py`, `context_profile.py` y `audit_integrity.py`.
2. Al acabar una instalación real, se comprueba y, cuando procede, se actualiza `.claude/skills/_shared/skill-catalog.md` desde las skills **del proyecto de destino**. Si cambia, se crea respaldo. `project-skill-registry.md` no se regenera ni sobrescribe automáticamente durante este paso.
3. Se incorpora `scripts/audit_integrity.py`: recorre todos los `.md` instalados, comprueba enlaces locales, rutas de comandos Python del proyecto y existencia del agente principal configurado.
4. README y guía de migración distinguen la validación del proyecto instalado de los tests del paquete fuente. Se unifica el nombre `MIGRACION_CLAUDE_V16.md`.
5. Se agregan cinco regresiones: integridad del ZIP, detección de enlaces rotos, instalación autoverificable, descubrimiento de skills preexistentes y modo `--dry-run` no destructivo.

## Validación ejecutada

Desde el directorio v16:

```powershell
py -3 scripts/audit_integrity.py --project-root . --source
py -3 scripts/validate.py --project-root .
py -3 .claude/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 -m unittest discover -s tests -q
```

Resultados: **66 documentos Markdown, 126 enlaces locales, 14 rutas de comandos Python documentados y 0 enlaces o comandos rotos**. **60 tests pasan** en el paquete fuente. Las nuevas pruebas incluyen instalación en un directorio temporal seguida de ejecución del validador y auditor, además de un escenario con una skill previa.

## Límites

- Es una auditoría estática y pruebas automatizadas locales: no se ha lanzado Claude Code, Engram ni Playwright MCP en el equipo del usuario.
- No se validan enlaces HTTP externos ni endpoints MCP en tiempo real desde el instalador. Las referencias a servicios externos requieren conectividad y versiones compatibles.
- Los scripts de validación comprueban la configuración prevista del paquete. Ajustes deliberadamente personalizados de modelos o servidores pueden necesitar criterios de validación adaptados.
- Las rutas de documentación en `tests/`, `examples/` y este informe se distribuyen en el ZIP fuente, no se copian al repositorio de destino, para evitar sobrescribir archivos de usuario.
