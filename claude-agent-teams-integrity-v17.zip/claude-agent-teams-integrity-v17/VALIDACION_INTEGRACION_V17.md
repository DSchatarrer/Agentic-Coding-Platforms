# Validación Claude Agent Teams v17 — Ponytail + Caveman

Fecha: 2026-10-30. Origen: `claude-agent-teams-integrity-v16.zip` adjuntado por el usuario.

## Resultado

- **60 pruebas originales** correctas antes de intervenir.
- **71 pruebas** correctas después de la integración (11 regresiones específicas añadidas).
- Validación de estructura: **OK**; 11 definiciones de agentes (orquestador + 10 especialistas), 10 skills de rol + 1 skill manual.
- Auditoría estática fuente: **OK**; 70 Markdown, **132 enlaces locales**, 14 comandos Python documentados, sin rutas rotas.
- Generador de catálogo `--check`: **OK**, 11 skills reconocidas, cinco entradas de estándares aprobados conservadas.
- Archivo de configuración `.claude/settings.json` **sin cambios**; `.mcp.json` **sin cambios**.
- Los 10 archivos de agentes especialistas **idénticos (SHA-256)** a los originales. El orquestador cambia una instrucción breve de presentación, sin alterar su frontmatter (modelo, esfuerzo, allowlist de herramientas).
- `quality-gate` (agente, skill, runner, aceptación) no se modifica.
- **Ningún hook, proxy, plugin o servidor MCP nuevo**.

## Prueba de migración v16 → v17

Instalación de v16 en directorio temporal; después actualización mediante el instalador v17:

| Comprobación | Resultado |
|---|---|
| `--dry-run --force` no escribe | OK |
| Instalación sin `--force` conserva los 11 conflictos | OK |
| La skill manual nueva se instala sin reemplazar las anteriores | OK |
| `--force` crea respaldos (10 en escenario probado) | OK |
| Los 10 agentes especialistas conservan el mismo hash | OK |
| Frontmatter del orquestador conserva modelo/herramientas | OK |
| `.claude/settings.json` con hooks personalizados y `.mcp.json` se conservan | OK |
| Texto externo al bloque gestionado `CLAUDE.md` se conserva | OK |
| Catálogo con 11 skills y script `--check` | OK |
| `validate.py` y `audit_integrity.py` sobre el destino | OK |

Los totales de conflictos y respaldos dependen de los archivos personalizados que tenga cada proyecto; no son una garantía fija.

## Alcance y límites

- Se **adaptan principios**, no se instalan los proyectos de terceros. No se ejecutan hooks no auditados ni se entregan credenciales a proxies.
- Ponytail: criterio `minimal-complete-change.md` + entrada vigente `changed-code-tests` + consulta por roles bajo demanda.
- Caveman: `/concise-output` usando control nativo `disable-model-invocation: true`, solo presentación; mantiene resultados originales y riesgos del `quality-gate`.
- No hay benchmark real de tokens, tiempo, calidad o uso de modelo: requieren sesiones Claude Code con un plan autenticado y proyectos representativos.
- No se ha ejecutado Claude Code ni los servidores MCP remotos; se ha validado el **paquete y su migración local**.
- Una skill invocada puede seguir en el contexto de la conversación; usar nueva sesión para restablecimiento estricto del estilo.
- Si ya existe un plugin Ponytail/Caveman instalado globalmente, puede seguir activo independientemente de este paquete. Inspeccionar `/hooks` y `/plugin`.

## Comandos de validación

```powershell
py -3 scripts/validate.py --project-root .
py -3 scripts/audit_integrity.py --project-root . --source
py -3 .claude/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 -m unittest discover -s tests -q
```

## Referencias consultadas

- https://code.claude.com/docs/en/skills
- https://code.claude.com/docs/en/hooks
- https://code.claude.com/docs/en/sub-agents
- https://github.com/DietrichGebert/ponytail
- https://github.com/JuliusBrussee/caveman
