---
name: test
description: Diseña y ejecuta tests; usa cuando hay nuevos contratos o cobertura insuficiente.
---
# Probar

## Procedimiento mínimo
1. Selecciona tests según riesgo; diferencia unitarios, integración real, mocks y E2E. Registra resultados.
2. No cargues referencias salvo activación específica. Ejecuta las herramientas que necesites, no leas sus scripts completos salvo depuración.

## Referencias bajo demanda
- [testing](references/testing.md) — diseño de casos complejos.
- [Playwright MCP](../_shared/playwright-mcp.md) — interacción UI real; no sustituye Playwright Test.
- [librerías Python](../_shared/python-libraries.md) — contratos de API pública.
- [Engram](../_shared/engram.md) — recuperar/guardar decisiones duraderas relevantes.
- [Context7](../_shared/context7.md) — duda externa real de versión/API.
- [Handoff](../_shared/handoff.md) — traspaso complejo o formal.

## Ejemplos de activación
- Sí: una tarea correspondiente a test.
- No: acciones de otro rol o pasos redundantes.

## Entrega
Estado `success|partial|blocked`; `quality_gate` por separado (`PASS|FAIL|BLOCKED|not_run|not_applicable`). Comunica comandos/resultados reales. Handoff extendido solo si hace falta.
