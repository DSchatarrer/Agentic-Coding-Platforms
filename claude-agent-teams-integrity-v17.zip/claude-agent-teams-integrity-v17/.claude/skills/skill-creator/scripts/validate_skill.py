#!/usr/bin/env python3
"""Minimal local skill verifier for scaffolded skills."""
from pathlib import Path
import re


REF = re.compile(r'\[[^\]]+\]\(([^)]+\.md)\)')

def validate(project, name):
    project=Path(project).resolve()
    path=project/'.claude'/'skills'/name/'SKILL.md'
    errors=[]
    if not path.is_file():return [f'Skill no encontrada: {path}']
    data=path.read_text(encoding='utf8')
    if not data.startswith('---\n') or f'\nname: {name}\n' not in data or '\ndescription: ' not in data:
        errors.append('Frontmatter inválido')
    if '## Procedimiento mínimo' not in data or '## Entrega' not in data:
        errors.append('Falta procedimiento o entrega')
    refs = REF.findall(data)
    if not refs: errors.append('Skill sin referencias bajo demanda')
    for ref in refs:
        if not (path.parent/ref).resolve().is_file():errors.append(f'Referencia no encontrada: {ref}')
    agent=project/'.claude'/'agents'/f'{name}.md'
    if agent.exists():
        try:
            agent_text=agent.read_text(encoding='utf8')
            if f'name: {name}' not in agent_text or f'  - {name}' not in agent_text:
                errors.append('Agente no coincide con skill precargada')
        except Exception as exc:errors.append(f'Agente inválido: {exc}')
    return errors
