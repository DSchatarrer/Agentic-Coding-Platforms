# Mantenimiento y consolidación segura de Engram

**Bajo demanda:** usar cuando el usuario solicite revisión, haya conflicto documentado o aparezca crecimiento sospechoso. No programar limpieza automática ni ejecutar borrados como parte de cada tarea.

1. Comprobar versión y herramientas disponibles (`mem_stats`, `mem_review`, `mem_compare`, `mem_consolidate`, `mem_delete` pueden depender del perfil MCP).
2. Verificar identidad del proyecto y posibles alias; no asumir que dos nombres representan el mismo repositorio. Git puede ayudar a estabilizar la identidad, pero el `remote` no se crea automáticamente.
3. Presentar un inventario resumido: duplicados candidatos, decisiones en conflicto, observaciones obsoletas y fuentes Git de contraste.
4. Antes de consolidar: revisar **el contenido completo** y usar vista previa si el MCP la permite. Solicitar confirmación explícita para fusiones o borrados irreversibles; no interpretar sugerencias automáticas como decisiones.
5. Si una decisión está desactualizada, preferir corregirla o marcar su sucesora de manera trazable; no aplicar expiración automática por antigüedad.
6. Medir evolución (memorias útiles, redundantes, sin proyecto claro) sin convertir las estadísticas en nuevas memorias.
7. Las operaciones de modificación deben usar validaciones de pertenencia como `expected_project` si la versión local lo exige. No inventar el contrato.

**No se incluye un limpiador autónomo**: sería arriesgado sin acceso al almacén local, su perfil MCP y una revisión previa del usuario.
