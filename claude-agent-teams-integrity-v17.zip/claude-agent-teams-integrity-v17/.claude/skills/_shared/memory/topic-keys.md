# Claves estables y actualización de memoria

**Consultar solo si vas a crear o modificar una observación evolutiva.**

- Engram identifica los upserts por `project + scope + topic_key`; no basta con que el título coincida. Confirmar `project` con `mem_current_project` o la interfaz realmente disponible.
- Formato sugerido: `architecture/auth-model`, `decision/database-choice`, `pattern/error-handling`, `config/ci`. Usar `family/slug` minúsculo y estable, no fechas, UUID aleatorios ni el nombre del agente.
- Buscar primero por proyecto y concepto; si hay coincidencia, **leer observación completa**. Si la decisión evoluciona, preferir `mem_save` con la misma `topic_key` cuando se confirme el esquema y propiedad del proyecto. Alternativamente `mem_update` sobre el ID conocido y con `expected_project` si la herramienta lo exige.
- Si no está claro si es la misma decisión, no forzar un upsert que sobrescriba información distinta. Señalar la ambigüedad para revisión.
- Mantener la decisión vigente, el porqué del cambio, las rutas y las referencias a evidencia. No borrar silenciosamente antecedentes necesarios; la trazabilidad detallada pertenece a Git o ADR versionados.
- No crear un prefijo fijo con el nombre del proyecto dentro del `topic_key` si Engram ya lo separa por `project`; evita claves dobles y fragmentación.
- No usar `topic_key` para eventos únicos que no evolucionan. `mem_suggest_topic_key` puede servir de ayuda solo si está disponible.

**Importante:** la detección de duplicados es semántica y exige juicio: los upserts evitan proliferación de versiones de *un tema*, no fusionan cualquier memoria parecida.
