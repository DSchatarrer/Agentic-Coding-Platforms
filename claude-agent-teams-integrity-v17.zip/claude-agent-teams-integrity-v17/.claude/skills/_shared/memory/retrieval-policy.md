# Recuperación selectiva desde Engram

**Consultar si una tarea requiere antecedentes, no para precargar historia en cada sesión.**

1. Delimitar una pregunta concreta: proyecto + módulo + decisión o bug.
2. Buscar con `mem_search` y revisar *pocos candidatos pertinentes*; los previews son pistas, nunca evidencia completa.
3. Abrir con `mem_get_observation(id)` solo las observaciones relevantes. `mem_context`/`mem_timeline` se usan únicamente si necesitas contexto de sesión o secuencia histórica.
4. Contrastar fecha y afirmaciones con código, Git, tests y documentos actuales. Si hay contradicción, prevalecen las fuentes verificables; proponer revisión de memoria.
5. Al delegar, pasar una síntesis corta con ID y criterio, no pegar observaciones completas salvo necesidad del especialista.
6. Si la búsqueda es ambigua o no devuelve resultados, no expandir indefinidamente. Continuar el trabajo sin inventar memoria.

No convertir Engram en un segundo registro de skills, un sistema de logging ni una copia automática del `TODO.md`.
