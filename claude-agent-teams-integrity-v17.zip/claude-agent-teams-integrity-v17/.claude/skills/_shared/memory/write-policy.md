# Política de escritura: filtrar antes de persistir

**Abrir solo cuando un agente encuentre conocimiento potencialmente duradero.** No leer al iniciar todas las tareas.

## Decisión de guardar

1. **Duración:** ¿será útil más allá de la sesión? Si no, no guardar.
2. **Fuente:** ¿ya está en el código, `TODO.md`, tests, documentación o Git y se puede hallar fácilmente? Si sí, enlazar la fuente en la respuesta; guardar en Engram solo el *porqué* difícil de reconstruir.
3. **Confianza:** ¿es una decisión aceptada, una causa raíz demostrada, una restricción estable o un patrón validado? Si es hipótesis, no elevarla a hecho; registrar incertidumbre solo si es indispensable y etiquetada.
4. **Duplicado:** buscar con `mem_search` por proyecto, concepto y ruta. Si parece el mismo tema, leer con `mem_get_observation`; **actualizar** la observación evolutiva en lugar de crear otra.
5. **Privacidad:** nunca persistir credenciales, tokens, datos personales innecesarios ni volcado de herramientas. No guardar prompts de usuarios por iniciativa propia; no prometer controlar hooks o captura automática que dependen de Engram.

## Guardar una sola vez

- El especialista que verificó el hallazgo realiza el guardado y devuelve el ID real; el coordinador **no vuelve a guardar** ese contenido.
- Usar `type` adecuado según la API expuesta (`decision`, `architecture`, `bugfix`, `pattern`, `config`, `discovery`, etc.) y `scope=project` por defecto si está soportado.
- Texto breve: **What** (decisión/hecho), **Why** (motivo), **Where** (rutas relevantes), **Learned** (riesgo/gotcha) y enlace a evidencia si existe. No duplicar código ni informes largos.
- Un bug rutinario cuya causa es obvia en el commit y sin lección reutilizable no necesita memoria adicional. Una causa raíz sorprendente que afectará otros cambios sí la merece.
- Si la herramienta devuelve error, truncamiento o estado incierto, informar el resultado; no reintentar ciegamente `mem_save` porque puede duplicar datos.

## Ejemplos

- Guardar: «La implementación de auth debe usar el adaptador de tokens porque el proveedor rota claves; confirmado con test X».
- Actualizar: «Se reemplazó el mecanismo de auth anterior», usando la misma clave evolutiva y justificando el cambio.
- No guardar: «Se corrigió un typo», «han pasado 35 tests», logs completos, snapshots, catálogo de skills, `.env`.
