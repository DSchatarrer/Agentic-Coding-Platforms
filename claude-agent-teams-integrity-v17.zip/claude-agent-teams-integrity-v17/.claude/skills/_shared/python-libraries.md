# Librerías Python — contratos bajo demanda

`Protocol` para contratos estructurales y `ABC` cuando hay comportamiento compartido o validación de subclases. Evitar capas superfluas. Para librería reutilizable, organizar `src/`, exportar API explícita y añadir tests de contrato.

```python
# src/acme_data/ports.py
from typing import Protocol
class Store(Protocol):
    def put(self, key: str, value: bytes) -> None: ...
    def get(self, key: str) -> bytes: ...

# src/acme_data/adapters.py
class MemoryStore:
    def __init__(self): self.items: dict[str, bytes] = {}
    def put(self, key: str, value: bytes) -> None: self.items[key] = value
    def get(self, key: str) -> bytes: return self.items[key]

# src/acme_data/service.py
from .ports import Store
class DocumentService:
    def __init__(self, store: Store): self.store = store
    def save(self, key: str, value: bytes) -> None: self.store.put(key, value)
    def load(self, key: str) -> bytes: return self.store.get(key)
```

```python
from abc import ABC, abstractmethod
class Encoder(ABC):
    @abstractmethod
    def encode(self, data: bytes) -> bytes: ...
    def encode_checked(self, data: bytes) -> bytes:
        if not isinstance(data, bytes): raise TypeError('bytes required')
        return self.encode(data)
class IdentityEncoder(Encoder):
    def encode(self, data: bytes) -> bytes: return data
```

```python
assert isinstance(b'data', bytes)
```

```toml
[build-system]
requires = ["setuptools>=68"]
build-backend = "setuptools.build_meta"
```
