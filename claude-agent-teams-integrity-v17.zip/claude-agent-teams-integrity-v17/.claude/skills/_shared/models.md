# Modelos Claude Code (versiones fijas)

- Orquestador y `plan`: `claude-opus-5-5`, esfuerzo `medium`.
- Otros nueve agentes: `claude-haiku-5-5`, esfuerzo `low`.
- Para implementaciones complejas, puede elegirse `claude-sonnet-5-5` con `low` tras evaluación y decisión explícita; no sustituir modelos en silencio.
- Los identificadores completos fijan versión; las alias `opus`/`haiku` pueden variar entre proveedores.
- La configuración de modelos requiere acceso a esos modelos en tu plan o proveedor.
