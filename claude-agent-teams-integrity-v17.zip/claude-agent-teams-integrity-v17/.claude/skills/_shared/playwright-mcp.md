# Playwright MCP — Claude Code, uso selectivo

El MCP oficial de Microsoft se configura **inline en los agentes** `create`, `debug`, `test`, `review` y `quality-gate`, y no se añade al contexto del orquestador:

```yaml
mcpServers:
  - playwright:
      type: stdio
      command: npx
      args: ["-y", "@playwright/mcp@latest", "--headless", "--isolated"]
```

Node.js y npx disponibles. Claude Code requiere confianza en el directorio de los agentes locales. Solo activar ante interacción con una UI en ejecución, reproducción de bugs de navegador, verificación exploratoria o aceptación explícita que lo exija. No equivale a pruebas E2E reproducibles: para estas utilizar Playwright Test mediante la política real de calidad. No acceder a cuentas privadas ni producción sin permiso, ni persistir cookies. Documentar pasos, URL sin credenciales, resultados, limitaciones y pruebas reales. Si la política exige navegador y no existe, `BLOCKED`.

Fuentes: https://github.com/microsoft/playwright-mcp y https://code.claude.com/docs/en/sub-agents
