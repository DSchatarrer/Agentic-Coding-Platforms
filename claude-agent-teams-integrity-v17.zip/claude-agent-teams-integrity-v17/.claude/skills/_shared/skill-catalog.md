# Catálogo descubierto automáticamente

> Inventario informativo del proyecto, **no son estándares aprobados**. Actualiza con `python .claude/skills/skill-creator/scripts/build_registry.py --project-root .`. Las reglas aprobadas están en `project-skill-registry.md`.

| Skill | Cuándo usarla (metadatos) | SKILL.md |
|---|---|---|
| `concise-output` | Responder de forma breve y verificable a una petición concreta; versión opt-in de la filosofía Say Less de Caveman. | `.claude/skills/concise-output/SKILL.md` |
| `create` | Implementa cambios concretos; usa cuando haya que crear código o módulos. | `.claude/skills/create/SKILL.md` |
| `debug` | Reproduce y corrige fallos; usa cuando hay un error que investigar. | `.claude/skills/debug/SKILL.md` |
| `docs` | Actualiza documentación; usa cuando la funcionalidad cambia o se pide documentar. | `.claude/skills/docs/SKILL.md` |
| `plan` | Planifica cambios complejos, arquitectura y dependencias; usa también para crear, auditar, continuar, actualizar o replanificar TODO.md con evidencias, sin implementar código. | `.claude/skills/plan/SKILL.md` |
| `quality-gate` | Verifica evidencias y bloquea entregas; usa al cerrar cambios de código. | `.claude/skills/quality-gate/SKILL.md` |
| `refactor` | Mejora diseño sin cambiar comportamiento; usa cuando un refactor está justificado. | `.claude/skills/refactor/SKILL.md` |
| `research` | Investiga código y documentación sin editar; usa cuando se necesite evidencia técnica. | `.claude/skills/research/SKILL.md` |
| `review` | Audita código sin editar; usa para riesgos, seguridad y regresiones. | `.claude/skills/review/SKILL.md` |
| `skill-creator` | Crea y valida skills; usa cuando se soliciten nuevas skills o agentes. | `.claude/skills/skill-creator/SKILL.md` |
| `test` | Diseña y ejecuta tests; usa cuando hay nuevos contratos o cobertura insuficiente. | `.claude/skills/test/SKILL.md` |

### Propuestas de reglas (revisión manual obligatoria)

Ninguna skill contiene una sección explícita `## Compact Rules` / `## Reglas compactas` de la que puedan extraerse reglas literalmente. No se han inventado resúmenes.

### Convenciones detectadas

| Archivo | Motivo |
|---|---|
| `CLAUDE.md` | Convención del proyecto |
