# Crear agentes y skills para Claude Code

- Un agente es `.claude/agents/<nombre>.md` (YAML frontmatter); una skill es `.claude/skills/<nombre>/SKILL.md`.
- Para cada especialista definir `skills: [<nombre>]`, `model`, `effort` y `disallowedTools: Agent`. El `SKILL.md` se **precarga**, no se vuelve a abrir.
- Describir cuándo invocar en `description`; dejar referencias en `references/` con condiciones de lectura, directamente enlazadas.
- Para ahorrar contexto, no poner `mcpServers` en el orquestador cuando solo lo necesitan especialistas; usar Playwright inline en agentes con navegador.
- Crear con `python .claude/skills/skill-creator/scripts/scaffold_skill.py <nombre> <descripcion> --project-root . --with-agent`.
- Actualizar catálogo: `python .claude/skills/skill-creator/scripts/build_registry.py --project-root .`; comprobar con `--check`. No alterar reglas humanas aprobadas.
- Validar `python scripts/validate.py --project-root .` y `python -m unittest discover -s tests -q`.

Referencia: https://code.claude.com/docs/en/sub-agents y https://code.claude.com/docs/en/skills
