# Carga progresiva en Claude Code

1. El agente principal `orchestrator` corre con `claude --agent orchestrator` o `.claude/settings.json`. Su prompt y `CLAUDE.md` contienen solo coordinación.
2. Cada especialista se define en `.claude/agents/<nombre>.md` y declara **exactamente una** skill en `skills: [<nombre>]`. Claude Code inyecta el cuerpo de ese SKILL.md al lanzar el subagente: **NO volver a leerlo**.
3. Abrir solo referencias enlazadas y relacionadas con la tarea; no precargar bibliotecas completas. Para `plan` cargar directamente la operación TODO elegida, sin índices.
4. Antes de delegar código, el coordinador selecciona hasta cinco estándares aprobados en `project-skill-registry.md`; no inyectar el catálogo autogenerado.
5. Engram es memoria persistente compartida y curada. Context7 cuando existan dudas externas; Playwright MCP solo en los agentes que tengan navegador. No fingir evidencia ni herramientas.
6. El especialista no subdelega; devuelve resultados compactos, bloqueos y evidencia.
