# Resolver de estándares para delegación de código

**Fuente de verdad:** [estándares aprobados](project-skill-registry.md), sección `## Entradas`. El [catálogo generado](skill-catalog.md) es solo inventario, nunca instrucciones aprobadas. No buscar registros alternativos en Engram.

1. Úsalo solo si delegas lectura, escritura, depuración, pruebas o revisión de código; no en coordinación o tareas documentales corrientes.
2. Cruza **acción, rutas y tecnología realmente observadas** con `**Acción:**` y `**Rutas/tecnología:**`; selecciona como máximo **cinco** entradas aprobadas. Si no hay coincidencias, no inyectes nada.
3. Copia solo `**Reglas compactas:**` seleccionadas a `## Project Standards (auto-resolved)` con IDs reales. No pegues el catálogo ni las referencias completas.
4. Cada especialista **recibe precargado** su `SKILL.md` de rol mediante `skills:`; lee referencias directas **solo** bajo su condición de activación. No reabrir la skill. Las reglas compactas no reemplazan su skill.
5. Si faltan normas, reporta `registry-missing`, no las inventes; si falta el catálogo, puedes refrescarlo con `build_registry.py`. La ausencia del inventario no bloquea una delegación ya conocida.

Engram guarda decisiones, no esta configuración. El estado de calidad se basa en pruebas, no en el registro.
