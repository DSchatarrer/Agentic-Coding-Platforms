# Context7 — documentación bajo demanda

Context7 oficial mediante HTTP Streamable en `.mcp.json` del proyecto:

```json
{"mcpServers":{"context7":{"type":"http","url":"https://mcp.context7.com/mcp"}}}
```

Consultar solo para incertidumbres sobre APIs/versiones externas; primero comprobar la versión instalada. Resolver IDs y consultar documentación mediante las herramientas MCP realmente disponibles. No enviar secretos. Si necesita autenticación, configúrala fuera del repositorio con el método que admita Context7/Claude Code. No interpretar un MCP desconectado como prueba de compatibilidad.

Fuente: https://github.com/upstash/context7
