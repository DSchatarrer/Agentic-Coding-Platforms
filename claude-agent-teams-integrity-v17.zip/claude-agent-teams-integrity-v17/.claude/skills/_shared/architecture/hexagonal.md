# Arquitectura hexagonal (Ports & Adapters)

## Cuándo abrir
Necesitas ejecutar lógica de negocio sin UI, BD o API externa reales; existen o se prevén diferentes modos de invocación y proveedores. A menudo se combina con Clean.

## Mapa
- **Núcleo:** comportamientos de dominio y aplicación, ajeno a detalles técnicos.
- **Puertos de entrada:** operaciones del negocio (`CreateInvoice`, `SearchOrders`) que invocan web/CLI/jobs/tests.
- **Adaptadores de entrada:** HTTP, CLI, consumer Kafka → traducen a puertos de entrada.
- **Puertos de salida:** contratos que la aplicación necesita (almacén, reloj, pasarela de pago).
- **Adaptadores de salida:** PostgreSQL, SQLite, S3, APIs externas, reloj real.
- Composición en el borde: inyecta implementaciones; no invertir imports del núcleo.

## Ejemplo Python
```python
from typing import Protocol
class NotificationPort(Protocol):
    def send(self, target: str, text: str) -> None: ...

class RegisterAccount:
    def __init__(self, notifications: NotificationPort):
        self.notifications = notifications
    def execute(self, email: str) -> None:
        if "@" not in email: raise ValueError("invalid email")
        self.notifications.send(email, "Welcome")

class FakeNotifier:
    def __init__(self): self.outbox = []
    def send(self, target, text): self.outbox.append((target, text))

fake = FakeNotifier()
RegisterAccount(fake).execute("dev@example.com")
assert fake.outbox == [("dev@example.com", "Welcome")]
```

## Comprobaciones
- Test de contrato para cada implementación real de un mismo puerto (mismo conjunto de casos).
- Tests funcionales del núcleo con fake, sin DB/red.
- Prueba que fallos/reintentos/timeouts de adaptadores se mapean a errores del dominio correctamente.
- No crear múltiples adaptadores ficticios «por si acaso».

## Antipatrones
- Adaptadores que contienen reglas de dominio y cambian resultados según proveedor.
- Una interfaz por clase sin necesidad de frontera.
- Infraestructura instanciada directamente desde núcleo.

## Fuente original
- https://alistair.cockburn.us/hexagonal-architecture/
