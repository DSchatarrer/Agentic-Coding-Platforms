# Índice de arquitecturas (recurso auxiliar, no skill)

**Carga progresiva:** selecciona primero [`decision-guide.md`](decision-guide.md) si necesitas decidir; abre solo la guía de la arquitectura elegida. No leas los tres patrones por defecto.

| Necesidad | Consulta | Criterio principal |
|---|---|---|
| CRUD o cambios modestos, equipo pequeño | [`layered.md`](layered.md) | capas lógicas simples, coste bajo |
| Dominio complejo, independencia de framework | [`clean.md`](clean.md) | dependencias hacia dominio y casos de uso |
| Múltiples entradas/salidas, pruebas sin BD/UI | [`hexagonal.md`](hexagonal.md) | puertos y adaptadores alrededor de lógica |
| Evaluar o migrar arquitectura | [`decision-guide.md`](decision-guide.md) | tradeoffs, ADR, migración gradual |
| Comprobar normas | [`verification.md`](verification.md) | tests de dependencia, contratos y efectos |

**No crear capas o puertos por reflejo:** decide basándote en cambios probables, complejidad y tests. `clean` y `hexagonal` tienen principios solapados; no son diseños incompatibles.
