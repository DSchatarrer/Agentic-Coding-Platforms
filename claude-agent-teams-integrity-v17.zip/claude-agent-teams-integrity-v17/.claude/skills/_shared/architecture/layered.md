# Arquitectura en capas (layered / n-layer)

## Cuándo abrir
Aplicaciones de complejidad baja/media que necesitan orden de responsabilidades sin coste de puertos abstractos. Adecuada para una gran proporción de APIs CRUD y servicios empresariales.

## Capas lógicas ≠ tiers físicos
- Presentación: input, HTTP/CLI/UI, validación sintáctica, transforma DTO a comandos.
- Servicio/aplicación: coordina casos de uso, transacciones y reglas de aplicación.
- Dominio (cuando exista): invariantes y reglas de negocio.
- Acceso a datos/integración: SQL, ORM, servicios externos.
- Capas son **responsabilidades lógicas**, no necesariamente procesos separados.
- Puede ser **strict** (solo capa inmediata) o **relaxed** (saltar capas permitidas inferiores), con tradeoffs de acoplamiento.

## Ejemplo de flujo
```text
http/orders.py → services/orders.py → repositories/orders.py → database
                             └→ domain/order.py
```

## Comprobaciones
- Controlador delgado: no SQL ni negocio complejo en rutas.
- Repositorio no decide reglas de negocio.
- Evitar circularidad (un repositorio no importa servicio HTTP).
- Tests de servicio con DB simulada; tests de integración de repositorios reales.
- Al crecer el dominio, valorar inversión de dependencias y puertos; evitar refactor preventivo.

## Antipatrones
- `utils/` gigante, capa servicio «pasarela» sin responsabilidades reales.
- Modelos ORM como tipos de dominio en toda la aplicación sin intención clara.
- Confundir escalado físico con separación lógica de archivos.

## Fuentes
- https://learn.microsoft.com/azure/architecture/guide/architecture-styles/n-tier
- https://learn.microsoft.com/dotnet/architecture/modern-web-apps-azure/common-web-application-architectures
