# Clean Architecture: regla de dependencias

## Cuándo abrir
Dominio complejo o necesidad de hacer independiente la lógica de negocio de frameworks, almacenamiento o API. No añadir esta arquitectura a todo CRUD por defecto.

## Fronteras
- `domain`: entidades, reglas de negocio e invariantes; no importa ORM/HTTP/SDK.
- `application`: casos de uso, orquestación de dominio, **interfaces de salida**; no depende de infraestructura.
- `adapters` / `infrastructure`: HTTP, ORM, mensajería, clientes, implementan puertos del interior.
- `composition root`: único lugar que conoce y ensambla implementaciones concretas.
- Dependencias de código fuente **apuntan hacia dentro**; el control en tiempo de ejecución puede ir al exterior mediante inversión.

## Ejemplo Python simplificado
```python
# domain/order.py
from dataclasses import dataclass
@dataclass(frozen=True)
class Order:
    id: str
    amount: int
    def __post_init__(self):
        if self.amount <= 0: raise ValueError("amount must be positive")

# application/ports.py
from typing import Protocol
class OrderWriter(Protocol):
    def save(self, order: Order) -> None: ...

# application/use_cases.py
class PlaceOrder:
    def __init__(self, writer: OrderWriter): self.writer = writer
    def __call__(self, order_id: str, amount: int) -> Order:
        order = Order(order_id, amount)
        self.writer.save(order)
        return order

# infrastructure/sql_writer.py -> implementa save; no se importa desde domain/application
```

## Comprobaciones
- Test unitario del caso de uso con fake del puerto, sin arrancar BD/HTTP.
- Test integración para adaptador real.
- Test estático: `domain` no importa `infrastructure`, `application` no importa `api` ni `database`.
- Distinguir reglas de negocio de validaciones del borde. DTO de transporte no se filtra al dominio.
- No forzar interfaces 1:1 para utilidades estables si no hay beneficio.

## Antipatrones
- `domain` importando SQLAlchemy/Entity Framework/FastAPI.
- Dependencia circular `application ↔ infrastructure`.
- Entidades anémicas con toda lógica en controladores y servicios HTTP.
- Extraer subproyectos en exceso sin requerimientos concretos.

## Fuentes
- https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html
- https://learn.microsoft.com/dotnet/architecture/modern-web-apps-azure/common-web-application-architectures
