# Seleccionar arquitectura sin sobreingeniería

## Preguntas antes de elegir
1. ¿Dónde está el coste de cambio: interfaz, persistencia, dominio o integraciones?
2. ¿Qué aislamiento exigen los tests y qué dependencias son realmente inestables?
3. ¿Cuántos adaptadores reales existen? ¿Se espera sustituir proveedores?
4. ¿Qué estilo predomina en el repositorio? Evita un rediseño sin justificación.
5. ¿Qué restricciones importan: equipo, plazos, rendimiento, integridad, observabilidad?

## Matriz cualitativa (guía, no umbrales inventados)
| Situación | Opción preferente | No elegir automáticamente cuando… |
|---|---|---|
| Servicio pequeño, CRUD, pocas reglas | Capas o modular simple | Introducir 6 proyectos añade ceremonia |
| Casos de uso complejos, dominio duradero | Clean | El dominio es un passthrough de datos |
| Entradas/salidas distintas, varias BD/APIs, test sin IO | Hexagonal | No existen fronteras relevantes que desacoplar |
| Sistema legado estable | Patrón actual + mejoras incrementales | Una migración masiva elevaría riesgo |

## Contrato de salida del planificador
- Contexto de dominio, límites, drivers de calidad y restricciones.
- Arquitectura elegida **y** alternativas descartadas, 2-4 razones concretas.
- Mapa de módulos y dependencias permitidas (DAG, sin ciclos).
- Puertos solo si existe variabilidad o necesidad de aislamiento real.
- APIs/DTO/schemas, invariantes, excepciones, transacciones y política de errores.
- Plan incremental de cambios, pruebas de contrato y de arquitectura, rollback.
- ADR corto: `Contexto → decisión → consecuencias → condiciones de revisión`.
- Acceptance criteria por tarea: pasos/inputs/outputs observables, no «código limpio» genérico.

## Ejemplo de razonamiento
Una API interna de tareas con una BD única y reglas mínimas → capas simples.
Si más adelante surgen muchos procesos de negocio y adaptadores externos, extraer `domain` y `application` preservando comportamiento, cubrir con tests y registrar ADR; no reescribir todo.

## Fuentes
- Robert C. Martin, Clean Architecture: https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html
- Alistair Cockburn, Hexagonal Architecture: https://alistair.cockburn.us/hexagonal-architecture/
- Microsoft, common web architectures: https://learn.microsoft.com/dotnet/architecture/modern-web-apps-azure/common-web-application-architectures
