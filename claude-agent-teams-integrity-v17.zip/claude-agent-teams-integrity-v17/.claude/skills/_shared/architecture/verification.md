# Verificación arquitectónica y migración incremental

## Verificaciones objetivas
1. Lista de imports/dependencias prohibidas por módulo y grafo sin ciclos (si la política lo exige).
2. Tests de invariantes de dominio sin dependencias externas.
3. Tests de contratos de puertos: los adaptadores reales satisfacen el mismo conjunto de casos.
4. Tests de integración E/S, serialización, persistencia y transacciones.
5. Tests de regresión sobre API pública, excepciones, rendimiento y efectos observables.
6. Decisiones documentadas (ADR); infracciones excepcionales aprobadas por responsables.

**Evidencia** = comando, exit status, artefacto y, para métricas, valor y umbral aprobado.

## Migración segura
- Capturar comportamiento actual con tests de caracterización.
- Elegir un borde y construir abstracción solo donde haya ganancia.
- Migrar una ruta vertical de extremo a extremo (strangler/branch by abstraction cuando corresponda).
- Mantener adapter legacy temporal, validar equivalencia y rollback.
- Quitar deuda transitoria solo después de demostrar compatibilidad.
- No modificar suites/umbrales en el mismo paso para que un Quality Gate «pase» sin autorización.

## Independencia
El agente que implementa **no** aprueba el cambio. `review` evalúa riesgos y arquitectura; `quality-gate` ejecuta comandos según política aprobada. Un PASS local no sustituye CI protegido.

## Referencias
- https://martinfowler.com/bliki/BranchByAbstraction.html
- https://learn.microsoft.com/dotnet/architecture/modern-web-apps-azure/common-web-application-architectures
