# Cambio mínimo completo — principios adaptados de Ponytail

**Uso:** consultar solo ante implementación, depuración, refactorización o revisión no trivial; no precargar este documento en cada rol. La regla compacta aprobada está en `changed-code-tests`.

## Escalera de decisión (tras comprender el flujo real)
1. **No escribir código:** ¿ya existe una opción segura, una configuración o un comportamiento reutilizable que cubre la necesidad?
2. **Ajustar lo existente:** preferir un cambio localizado en un componente/librería presente si conserva contratos y responsabilidades.
3. **Añadir lo necesario:** introducir nueva lógica o abstracción solo si se justifica por un requisito demostrable, una frontera real o duplicación existente.
4. **Refactorizar con alcance:** solo con evidencia de deuda/riesgo y pruebas que preserven comportamiento; separar cambios de comportamiento de reorganizaciones amplias.

**Nunca sacrificar:** controles de autorización, validación en límites de confianza, manejo de pérdida de datos, accesibilidad exigida, compatibilidad pública, observabilidad crítica, seguridad, pruebas y criterios del `quality-gate`. Un cambio corto **no es** automáticamente un cambio correcto.

**Ejecución:** inspecciona llamadas y pruebas antes de editar, elige la solución completa más pequeña, ejecuta verificaciones proporcionales y comunica qué cambió, qué no se ejecutó y los riesgos. No prometas métricas de ahorro de tokens sin medirlas. Para dudas externas concretas, Context7 bajo demanda; para decisiones duraderas, Engram según política.

**Origen metodológico (adaptación, no instalación):** https://github.com/DietrichGebert/ponytail. No se importan hooks, modelos ni agentes de Ponytail.
