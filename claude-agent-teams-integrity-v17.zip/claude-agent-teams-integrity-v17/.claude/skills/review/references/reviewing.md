# Guía: review

## Índice
- Cuándo consultar esta guía
- Comprobaciones

## Cuándo
Consulta el comportamiento real, minimiza supuestos y protege datos y secretos.

## Comprobaciones
Verifica la aceptación observable, tests y reversibilidad. Comprueba si el cambio añade capas, dependencias, duplicación o generalidad sin una necesidad comprobada; solo informa de sobreingeniería cuando identifiques impacto y ruta/línea concretos. Prioriza errores funcionales, seguridad, compatibilidad, rendimiento y accesibilidad. Deja constancia de pruebas no ejecutadas y evita falsos positivos por estilo.
