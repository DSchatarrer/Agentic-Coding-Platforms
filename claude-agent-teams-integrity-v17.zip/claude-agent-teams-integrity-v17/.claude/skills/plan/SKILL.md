---
name: plan
description: Planifica cambios complejos, arquitectura y dependencias; usa también para crear, auditar, continuar, actualizar o replanificar TODO.md con evidencias, sin implementar código.
---
# Planificación y TODO verificable

## Procedimiento mínimo
1. Inspecciona requisitos, estado real y dependencias. Si el cambio es trivial, no propongas una arquitectura compleja.
2. Para diseño con múltiples componentes, consulta [planning](references/planning.md). Para decisiones de arquitectura, consulta [decision-guide](../_shared/architecture/decision-guide.md) y solo la guía elegida: [Clean](../_shared/architecture/clean.md), [Hexagonal](../_shared/architecture/hexagonal.md) o [Capas](../_shared/architecture/layered.md).
3. Para `TODO.md` **elige directamente la operación**; no abras un índice antes de ella. Lee [reglas comunes](references/todo-core.md) solo si aplican y [evidencias](references/todo-evidence.md) cuando haya cierres o auditoría. `plan` mantiene el documento; **no implementa código** ni ejecuta especialistas.

## Operaciones TODO.md — solo si se solicitan
- [CREAR](references/todo-create.md) + [estructura](references/todo-structure.md) para crear o reconstruir.
- [AUDITAR](references/todo-audit.md) + [evidencias](references/todo-evidence.md) para comprobar cierres; solo lectura.
- [CONTINUAR](references/todo-continue.md) para elegir tarea y devolver handoff al coordinador; implementación de otros especialistas.
- [ACTUALIZAR](references/todo-update.md) para integrar requisitos/estados.
- [REPLANIFICAR](references/todo-replan.md) para reajustar hitos/dependencias.
- [Índice opcional](references/todo-tracker.md) — solo cuando la operación solicitada sea ambigua.

## Referencias opcionales
- [Engram](../_shared/engram.md) — decisiones previas pertinentes.
- [Context7](../_shared/context7.md) — dudas de documentación externa.
- [librerías Python](../_shared/python-libraries.md) — SDK/API pública.
- [handoff](../_shared/handoff.md) — traspaso formal.

## Ejemplos de activación
- Sí: planificar API compleja o auditar `TODO.md`.
- No: corregir typo; delegar directamente en `create`/`debug`.

## Entrega
Estado `success|partial|blocked`; `quality_gate` por separado (`PASS|FAIL|BLOCKED|not_run|not_applicable`). Comunica comandos/resultados reales. Handoff extendido solo si hace falta.
