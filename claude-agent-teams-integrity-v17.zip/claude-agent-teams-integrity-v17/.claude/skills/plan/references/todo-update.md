# TODO.md — ACTUALIZAR

**Se activa:** añadir nuevos requisitos, decisiones, avances, bloqueos o resultados sin rediseñar por completo el plan.

**Leer:** [todo-core.md](todo-core.md). Leer [todo-evidence.md](todo-evidence.md) únicamente si se registra una evidencia, cambio histórico o cierre.

## Procedimiento

1. Leer el `TODO.md` actual y comprender identificadores, prioridades, dependencias, estado y decisiones vigentes.
2. Separar lo nuevo de lo confirmado previamente; comprobar que no esté ya registrado.
3. Incorporar nuevos requisitos como tareas/hitos apropiados sin renombrar IDs históricos ni duplicar tareas.
4. Ajustar dependencias y criterios de aceptación afectados, preservando no objetivos y contratos vigentes salvo instrucción expresa.
5. Para avances: registrar qué se hizo realmente, comandos y resultados, entorno y limitaciones; `[x]` solo para cierres verificados.
6. Para bloqueos: dejar `[ ]`, añadir causa y siguiente acción viable. No bloquear tareas independientes.
7. Anotar qué decisión fue sustituida, motivo y alcance; conservar trazabilidad e historial anterior.
8. Recalcular `## Próxima tarea concreta`, comparar con repositorio y comunicar diferencias.

## Salida

`TODO.md` actualizado + qué cambió, qué no cambió, qué está verificado y siguiente tarea. Sin implementar código desde `plan`.
