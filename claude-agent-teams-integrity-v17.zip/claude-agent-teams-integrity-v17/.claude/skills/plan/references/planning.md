# Planificación bajo demanda: decisiones ejecutables

## Inputs
- Requisitos, rutas del repo, versiones de dependencias, métricas objetivo y restricciones.
- Evidencia real del estado actual: tests, errores, módulos afectados y contratos.
- Engram: decisiones anteriores solo si se necesitan; no tratar memorias obsoletas como código actual.

## Salida (plantilla)
```markdown
Objetivo:
No objetivos:
Restricciones y supuestos:
Decisión técnica y alternativas consideradas:
Arquitectura (si aplica) y contratos:
Tareas: [id, dependencias, rutas, responsable sugerido]
Pruebas y criterios de aceptación por tarea:
Riesgos, seguridad, compatibilidad y rollback:
Quality Gate propuesto (no alterar política sin autorización):
Memoria Engram consultada / decisiones que deben persistirse:
```

## Reglas de diseño
- Diseña únicamente las fronteras que justifican requisitos actuales o cambios probables observables.
- Un plan no se aprueba solo por «tiene arquitectura limpia». Exige pruebas verificables.
- El criterio de aceptación debe decir qué comportamiento observable cambia, no cómo debería lucir el código.
- Si hace falta documentación API externa, Context7 puede resolver versiones; no inventar compatibilidad.
- Cuando se necesita elegir entre capas/Clean/Hexagonal, consulta `_shared/architecture/decision-guide.md`, y carga el patrón elegido únicamente después.
