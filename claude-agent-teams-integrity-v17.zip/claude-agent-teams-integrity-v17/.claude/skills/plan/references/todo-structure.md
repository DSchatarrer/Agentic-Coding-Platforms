# TODO.md — estructura del documento (solo creación o reconstrucción)

Leer en CREAR y cuando se vaya a reconstruir completamente el archivo. En AUDITAR, CONTINUAR o ACTUALIZAR normales, **no** es necesario cargar esta referencia; se preservan las secciones existentes.

La estructura se adapta al tamaño del proyecto. Los identificadores estables y la evidencia verificada prevalecen sobre el aspecto del Markdown.

### A. Cabecera y protocolo de uso

Incluye:

- Nombre del proyecto.
- Fecha de actualización.
- Propósito del documento.
- Convención de estados.
- Instrucciones de consulta y actualización.

Utiliza:

- `[ ]` = tarea pendiente, en progreso o bloqueada.
- `[x]` = tarea terminada y verificada.

Una tarea parcialmente implementada conservará `[ ]` y tendrá una explicación de su progreso.

El agente deberá leer este documento antes de iniciar cada bloque de trabajo y actualizarlo después de cada avance verificable.

### B. Objetivo y decisiones vigentes

Describe:

- Objetivo general.
- Resultado final esperado.
- Arquitectura prevista, si está definida.
- Tecnologías confirmadas.
- Restricciones obligatorias.
- Decisiones técnicas vigentes.
- Exclusiones explícitas.
- Cambios de alcance relevantes.

Diferencia claramente las decisiones actuales de las históricas.

Una decisión nueva puede sustituir a una anterior, pero no debe borrar la evidencia del cambio.

### C. Estado actual del proyecto

Resume:

- Qué existe realmente.
- Qué funciona y ha sido verificado.
- Qué está implementado parcialmente.
- Qué está pendiente.
- Qué bloqueos afectan al desarrollo.
- Cuál es la siguiente prioridad.

Distingue entre estado declarado y estado comprobado.

Evita repetir extensamente información que ya figure en las evidencias.

### D. Roadmap de hitos

Construye una tabla con el formato:

| Hito | Tareas | Entrega verificable |
|---|---|---|
| H1 — Nombre | T01–T04 | Resultado esperado |
| H2 — Nombre | T05–T09 | Resultado esperado |
| H3 — Nombre | T10–T15 | Resultado esperado |

Los hitos deben representar entregables funcionales, verificables y coherentes.

Prioriza recorridos verticales utilizables frente a componentes aislados cuando sea razonable.

Define las dependencias entre hitos.

### E. Tareas organizadas por prioridad

Organiza las tareas utilizando prioridades como:

- P0 — Fundamentos y requisitos críticos.
- P1 — Implementación principal.
- P2 — Funcionalidades complementarias.
- P3 — Integraciones y extensiones.
- P4 — Calidad, seguridad y operación.
- P5 — Distribución y mantenimiento.

Estas prioridades son orientativas. Adáptalas al proyecto.

Utiliza identificadores estables:

- T01, T02, T03...
- T03a, T03b, T03c para subtareas.
- Un tercer nivel solo cuando sea realmente necesario.

Cada tarea debe indicar, directamente o mediante subtareas:

1. Identificador y nombre.
2. Objetivo.
3. Alcance técnico.
4. Dependencias.
5. Entregable esperado.
6. Criterios de aceptación verificables.
7. Pruebas necesarias.
8. Evidencia de cierre.
9. Bloqueos o limitaciones, si existen.

No es obligatorio crear una ficha extensa para cada tarea. Utiliza descripciones compactas cuando sean suficientes.

Descompón las tareas grandes antes de comenzar su implementación, sin perder su identificador principal.

No utilices identificadores nuevos para renombrar tareas históricas.

### F. Próxima tarea concreta

Incluye una sección:

`## Próxima tarea concreta`

Debe identificar:

- La tarea prioritaria.
- Por qué corresponde ejecutarla ahora.
- Sus dependencias ya satisfechas.
- Qué archivos o componentes podrían verse afectados.
- Los resultados que permitirían cerrarla.
- Los bloqueos que deben respetarse.

Selecciona una tarea ejecutable en el entorno actual siempre que sea posible.

No bloquees injustificadamente todo el proyecto porque exista una validación externa pendiente y haya tareas independientes que puedan avanzar.
