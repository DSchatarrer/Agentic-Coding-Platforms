# TODO.md — evidencias, bloqueos e historial (cierre / auditoría)

Leer solo si vas a verificar o cerrar tareas, auditar declaraciones de progreso, registrar bloqueos o modificar decisiones históricas. Implementación, simulación e integración real son niveles distintos. Nunca inventes cifras, comandos ejecutados ni resultados.

### G. Evidencias de implementación y verificación

Incluye una sección de evidencias, organizada por tarea o intervención.

Para cada trabajo completado registra:

- Fecha.
- Identificador de tarea.
- Archivos o componentes modificados.
- Funcionalidad entregada.
- Pruebas ejecutadas.
- Comandos relevantes, cuando proceda.
- Resultado real.
- Entorno de ejecución.
- Recursos reales o simulados.
- Limitaciones conocidas.
- Pendientes derivados.

Ejemplo:

**Evidencia T07 — Persistencia local**

- Implementado adaptador de persistencia.
- Añadidas pruebas de escritura, lectura y recuperación.
- Ejecutadas 18 pruebas unitarias: 18 correctas.
- Integración sobre base local real.
- Proveedor externo simulado.
- No se han probado fallos de infraestructura.
- Integración externa pendiente en T12.

Solo registra los números y resultados que hayas observado efectivamente.

No afirmes haber ejecutado una prueba que únicamente has diseñado.

### H. Bloqueos y dependencias externas

Registra explícitamente:

- Credenciales no disponibles.
- Servicios externos inaccesibles.
- Dependencias no implementadas.
- Decisiones pendientes del usuario.
- Limitaciones de infraestructura.
- Validaciones que requieren otro entorno.

Distingue los bloqueos técnicos de las tareas que puede completar el usuario posteriormente.

No cierres tareas bloqueadas ni simules su resolución.

### I. Historial de decisiones y cambios

Conserva las decisiones importantes que modifican el proyecto.

Registra:

- Fecha.
- Decisión original.
- Nueva decisión.
- Motivo, si está disponible.
- Impacto sobre el alcance.
- Tareas afectadas.

Si el documento crece demasiado, mueve evidencias históricas cerradas a `docs/history/` o una ubicación equivalente y enlázalas desde `TODO.md`.

No elimines el historial ni las pruebas que justificaron decisiones anteriores.

El documento principal debe seguir siendo manejable y representar el estado vigente.

---

## Puerta de cierre

- Una tarea solo cambia de `[ ]` a `[x]` cuando todos sus criterios de aceptación obligatorios tienen pruebas pertinentes con resultados observados.
- Ejecutar `quality-gate` según política vigente cuando el cambio de código lo exija; `PASS`/`FAIL`/`BLOCKED` se basan en informes reales, no en la opinión del agente implementador.
- Si falta infraestructura, credenciales o validación requerida, dejar abierto y registrar bloqueo; un mock no demuestra producción.
- No usar la evidencia histórica de una versión anterior como demostración automática de la versión actual.
