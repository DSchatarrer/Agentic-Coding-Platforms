# TODO.md — REPLANIFICAR

**Se activa:** cambiar roadmap, hitos, prioridades o dependencias a raíz de requisitos o descubrimientos nuevos.

**Leer:** [todo-core.md](todo-core.md). Leer [todo-structure.md](todo-structure.md) solo si hay que reconstruir el esquema completo del documento. Abrir [todo-evidence.md](todo-evidence.md) si hay que modificar el historial o el estado documentado.

## Procedimiento

1. Recuperar `TODO.md`, decisiones actuales, bloqueos y estado verificado del repositorio. Identificar qué cambió y por qué.
2. Mantener **IDs estables** de tareas existentes, preservar hitos cerrados, decisiones históricas y evidencias. No reiniciar el proyecto ni inventar progresos.
3. Reorganizar grupos e hitos por entregables funcionales, riesgo y dependencias; evita trabajo superfluo o fases impuestas.
4. Si una tarea cambia de alcance, explicitarlo y crear subtareas o nuevas tareas sin reutilizar identificadores antiguos para significados distintos.
5. Expresar tareas descartadas como canceladas/sustituidas con motivo; no borrar rastros ni convertir pendientes en completados.
6. Reevaluar criterios de aceptación, riesgos, rollback, dependencias externas y ruta crítica; no cerrar tareas que perdieron pruebas válidas.
7. Registrar decisión anterior, decisión nueva, fecha, motivo, impacto y tareas afectadas.
8. Actualizar la próxima tarea viable y comunicar el plan anterior frente al nuevo sin prometer ejecución.

## Salida

Roadmap revisado, mapa de dependencias, cambios justificables y `TODO.md` actualizado si se pidió editarlo.
