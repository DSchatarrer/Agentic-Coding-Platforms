# TODO.md — CREAR

**Se activa:** el usuario pide crear el tracker de un proyecto, no existe un `TODO.md` utilizable, o solicita expresamente reconstruirlo desde cero.

**Leer:** [todo-core.md](todo-core.md) y [todo-structure.md](todo-structure.md). [todo-evidence.md](todo-evidence.md) solo si ya hay trabajo completado que el usuario quiera registrar como verificado.

## Procedimiento

1. Leer solicitud, README, pruebas, dependencias, estructura del repositorio y decisiones relevantes de Engram (si el MCP está disponible); no afirmar haber leído lo inaccesible.
2. Distinguir requisitos confirmados, hipótesis, límites y riesgos. Anotar cuando se trabaja solo con información provisional.
3. Construir objetivo, estado real, hitos con entregables verificables y dependencias. Prefiere recorridos verticales funcionales a módulos aislados cuando sea apropiado.
4. Crear tareas pequeñas identificadas T01, T02… o subtareas T03a, T03b; no inventar fases ni número fijo de hitos. Cada tarea debe expresar criterios de aceptación, pruebas y cierre.
5. Elegir la siguiente tarea ejecutable y documentar por qué corresponde realizarla ahora.
6. Escribir `TODO.md` en la raíz si hay permiso; si no, devolver Markdown completo. Nunca marcar `[x]` sin evidencias observadas.
7. Informar qué se creó, qué se verificó realmente y qué queda por validar.

## Salida

`TODO.md` utilizable + resumen de objetivos, riesgos, hitos y próxima tarea; sin código implementado por `plan`.
