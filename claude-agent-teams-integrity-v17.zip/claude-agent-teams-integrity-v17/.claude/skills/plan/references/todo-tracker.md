# TODO.md — índice de carga selectiva

Este archivo es **solo el enrutador**. Se usa únicamente cuando el usuario solicita gestionar un `TODO.md` como registro ejecutable del proyecto. No se impone a todas las tareas de planificación.

## Selección de operación

| Petición | Referencia específica | Referencias adicionales |
|---|---|---|
| Crear TODO.md desde cero (no existe) | [todo-create.md](todo-create.md) | [todo-core.md](todo-core.md) + [todo-structure.md](todo-structure.md) |
| Auditar, revisar coherencia o validar TODO.md existente | [todo-audit.md](todo-audit.md) | [todo-core.md](todo-core.md) + [todo-evidence.md](todo-evidence.md) |
| Continuar o implementar próximas tareas de un TODO.md | [todo-continue.md](todo-continue.md) | [todo-core.md](todo-core.md); [todo-evidence.md](todo-evidence.md) **solo al cerrar/validar** |
| Actualizar con nuevos requisitos o avances | [todo-update.md](todo-update.md) | [todo-core.md](todo-core.md); [todo-evidence.md](todo-evidence.md) **si se registran cierres** |
| Replanificar hitos, prioridades y dependencias | [todo-replan.md](todo-replan.md) | [todo-core.md](todo-core.md); [todo-structure.md](todo-structure.md) **si rehaces su estructura** |

Lee la fila elegida, **no todas las filas**. Los enlaces están a un nivel de `SKILL.md`; esta tabla sirve de recordatorio del propósito. Para un cambio que abarque varias operaciones, abre solo las referencias de esas operaciones. Todas las referencias están enlazadas también directamente desde `SKILL.md`.

## Cómo resolver ambigüedad

- Sin `TODO.md` y petición de comenzar a planificar el proyecto: **CREAR**.
- Existe `TODO.md` y el usuario quiere avanzar con trabajo: **CONTINUAR**.
- Comprobar veracidad o coherencia sin pedir cambios: **AUDITAR** (por defecto sin modificación).
- Añadir requisitos/resultados sin alterar el orden general: **ACTUALIZAR**.
- Cambiar estrategia, prioridades o dependencias: **REPLANIFICAR**.
- Solo pide planificación ordinaria sin `TODO.md`: usa [planning.md](planning.md), no este protocolo.

## Límites entre agentes

`plan` puede crear/editar `TODO.md` cuando se solicite, pero **no implementa código**. Si la operación es CONTINUAR, devuelve un handoff al coordinador: delegar código en `create`/`debug`, verificaciones en `test`/`quality-gate`, y solo entonces actualizar cierres del TODO con evidencias reales.

La memoria Engram conserva decisiones, pero no sustituye `TODO.md`, el código ni las pruebas. Mantén el seguimiento según el trabajo solicitado.
