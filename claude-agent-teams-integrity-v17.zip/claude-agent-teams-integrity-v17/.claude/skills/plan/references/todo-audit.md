# TODO.md — AUDITAR

**Se activa:** el usuario solicita comprobar que el `TODO.md` es correcto y se corresponde con el repositorio. Por defecto es **solo lectura**, no una orden de modificar implementación o replanificar.

**Leer:** [todo-core.md](todo-core.md) y [todo-evidence.md](todo-evidence.md). [todo-structure.md](todo-structure.md) solo si pide auditar explícitamente también el esquema del documento.

## Procedimiento

1. Leer `TODO.md`, código, tests, historial y contratos relevantes. Si hay memoria Engram accesible, usarla para contexto, no como prueba del estado actual.
2. Cruzar cada estado declarado con código, pruebas y resultados reproducibles. Verificar dependencias, criterios de cierre, bloqueos y estabilidad de IDs.
3. Detectar tareas `[x]` sin evidencia suficiente, pendientes falsamente cerrados, pruebas solo simuladas, duplicados, tareas padre cerradas prematuramente y contradicciones entre versiones.
4. Distinguir **hallazgo confirmado**, **riesgo** y **no verificable**. No inventar ejecuciones, cifras ni mecanismos de validación.
5. Emitir hallazgos con ID, prioridad, archivo/sección, evidencia disponible, impacto y corrección propuesta. No convertir una propuesta en cambio real sin autorización.
6. Si se requiere corrección documental, delegar o actualizar `TODO.md` preservando historia, IDs y decisiones; nunca cambiar código desde `plan`.

## Resultado

Informe de incoherencias, nivel de confianza, tareas afectadas y acciones recomendadas. Una revisión documental no certifica una integración real.
