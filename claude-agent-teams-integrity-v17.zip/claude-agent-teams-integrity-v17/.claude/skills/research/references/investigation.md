# Guía: research

## Índice
- Cuándo consultar esta guía
- Comprobaciones

## Cuándo
Consulta el comportamiento real, minimiza supuestos y protege datos y secretos.

## Comprobaciones
Verifica la aceptación observable, tests y reversibilidad. Deja constancia de cualquier prueba no ejecutada.
