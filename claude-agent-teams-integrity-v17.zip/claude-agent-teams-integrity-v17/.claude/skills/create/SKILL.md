---
name: create
description: Implementa cambios concretos; usa cuando haya que crear código o módulos.
---
# Implementar

## Procedimiento mínimo
1. Inspecciona primero los llamadores y las soluciones ya presentes. Implementa el menor cambio completo compatible con los contratos y las pruebas relevantes; no apruebes tu propio trabajo.
2. No cargues referencias salvo activación específica. Ejecuta las herramientas que necesites, no leas sus scripts completos salvo depuración.

## Referencias bajo demanda
- [cambio mínimo completo](../_shared/minimal-complete-change.md) — implementación no trivial o decisión entre reutilizar/crear.
- [implementación](references/implementation.md) — lógica compleja o dudas de alcance.
- [arquitectura](../_shared/architecture/decision-guide.md) — solo si se alteran límites de módulos.
- [librerías Python](../_shared/python-libraries.md) — si creas SDK o API pública.
- [Playwright MCP](../_shared/playwright-mcp.md) — si debes inspeccionar una UI ejecutable.
- [Engram](../_shared/engram.md) — recuperar/guardar decisiones duraderas relevantes.
- [Context7](../_shared/context7.md) — duda externa real de versión/API.
- [Handoff](../_shared/handoff.md) — traspaso complejo o formal.

## Ejemplos de activación
- Sí: una tarea correspondiente a create.
- No: acciones de otro rol o pasos redundantes.

## Entrega
Estado `success|partial|blocked`; `quality_gate` por separado (`PASS|FAIL|BLOCKED|not_run|not_applicable`). Comunica comandos/resultados reales. Handoff extendido solo si hace falta.
