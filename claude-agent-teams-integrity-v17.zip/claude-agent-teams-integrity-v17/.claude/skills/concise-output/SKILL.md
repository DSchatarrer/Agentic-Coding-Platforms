---
name: concise-output
description: Responder de forma breve y verificable a una petición concreta; versión opt-in de la filosofía Say Less de Caveman.
disable-model-invocation: true
user-invocable: true
---
# Salida concisa bajo demanda (adaptación de Caveman)

**Activación:** solo cuando el usuario escriba `/concise-output`. Aplica a la **respuesta solicitada en esta invocación**, no a las instrucciones de trabajo de los agentes ni a futuros turnos automáticamente.

1. Responde primero con el resultado; utiliza frases claras y breves, sin muletillas ni recapitulaciones redundantes.
2. Resume cambios y evidencia verificable: rutas afectadas, pruebas con comando y resultado, errores, bloqueos y riesgos. Mantén `quality_gate` diferenciado de `status`; no inventes `PASS`.
3. Conserva exactamente los fragmentos de código, comandos, rutas, cifras, unidades, citas y mensajes de error cuando se incluyan. No omitas negaciones o condiciones.
4. Cuando haya seguridad, consecuencias irreversibles, resultados ambiguos o petición de explicación profunda, prioriza claridad y detalle suficiente frente a brevedad.
5. No comprimas los argumentos de herramientas, la salida original de los tests, las pruebas de aceptación ni los handoffs internos. La concisión solo se aplica a la presentación final dirigida al usuario.

Si la tarea requiere especialistas, conserva su flujo normal y el `quality-gate`. La salida es breve **después** de verificar, nunca en lugar de verificar.

Origen metodológico: https://github.com/JuliusBrussee/caveman. No se instala su proxy, selección automática de modelos, hooks o compresores.
