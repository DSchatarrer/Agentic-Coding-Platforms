#!/usr/bin/env python3
"""Deterministic policy-driven quality gates (Python >=3.11; no dependencies).

Policies are project-owned. A gate never infers thresholds or treats missing tools as success.
Exit codes 0 PASS, 1 FAIL, 2 BLOCKED. Writes JSON report locally.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import tomllib

STATUSES = {'PASS', 'FAIL', 'BLOCKED'}


def gate_result(name, status, reason, *, command=None, returncode=None,
                duration_seconds=0, stdout_tail='', stderr_tail='', metric=None):
    return {
        'name': name, 'status': status, 'reason': reason,
        'command': command, 'returncode': returncode,
        'duration_seconds': round(duration_seconds, 3),
        'stdout_tail': stdout_tail[-3000:], 'stderr_tail': stderr_tail[-3000:],
        'metric': metric,
    }


def _valid_command(command):
    return (isinstance(command, list) and bool(command) and
            all(isinstance(arg, str) and arg and '\0' not in arg for arg in command))


def execute_gate(name, gate, project_root):
    if not isinstance(gate, dict):
        return gate_result(name, 'BLOCKED', 'No hay configuración de gate')
    command = gate.get('command')
    if not _valid_command(command):
        return gate_result(name, 'BLOCKED', 'command debe ser una lista TOML de argumentos no vacíos')
    try:
        timeout = int(gate.get('timeout_seconds', 300))
    except (TypeError, ValueError):
        return gate_result(name, 'BLOCKED', 'timeout_seconds inválido', command=command)
    if timeout <= 0 or timeout > 3600:
        return gate_result(name, 'BLOCKED', 'timeout_seconds fuera de 1..3600', command=command)

    exe = command[0]
    found = (project_root / exe).is_file() if '/' in exe or '\\' in exe else shutil.which(exe)
    if not found:
        return gate_result(name, 'BLOCKED', f'Ejecutable ausente: {exe}', command=command)

    before = time.monotonic()
    try:
        result = subprocess.run(
            command, cwd=project_root, capture_output=True, text=True,
            timeout=timeout, check=False, errors='replace',
            # Never shell=True: no implicit shell interpolation.
        )
    except subprocess.TimeoutExpired as exc:
        return gate_result(name, 'FAIL', f'Timeout de {timeout}s', command=command,
                           duration_seconds=time.monotonic()-before)
    except OSError as exc:
        return gate_result(name, 'BLOCKED', f'No se pudo lanzar comando: {exc}',
                           command=command, duration_seconds=time.monotonic()-before)

    stdout = result.stdout[-12000:]
    stderr = result.stderr[-12000:]
    kwargs = dict(command=command, returncode=result.returncode,
                  duration_seconds=time.monotonic()-before,
                  stdout_tail=stdout, stderr_tail=stderr)
    if result.returncode != 0:
        # Un módulo de verificación ausente impide ejecutar el gate; no es un test fallido.
        if re.search(r'No module named [\'"]?[^\s\'"]+', stdout + '\n' + stderr):
            return gate_result(name, 'BLOCKED', 'Dependencia/herramienta Python no disponible', **kwargs)
        return gate_result(name, 'FAIL', 'Comando de validación devolvió código distinto de 0', **kwargs)

    if 'min_value' not in gate and 'metric_pattern' not in gate:
        return gate_result(name, 'PASS', 'Comando ejecutado con código 0', **kwargs)
    if 'min_value' not in gate or 'metric_pattern' not in gate:
        return gate_result(name, 'BLOCKED', 'Métrica incompleta: min_value y metric_pattern obligatorios', **kwargs)

    try:
        minimum = float(gate['min_value'])
        if not 0 <= minimum <= 100:
            raise ValueError('rango permitido 0..100')
        pattern = gate['metric_pattern']
        if not isinstance(pattern, str) or len(pattern) > 500:
            raise ValueError('metric_pattern inválido')
        m = re.search(pattern, stdout + '\n' + stderr)
        if m is None:
            return gate_result(name, 'BLOCKED', 'No se ha podido medir la métrica requerida', **kwargs)
        score = float(m.group('value'))
        if not 0 <= score <= 100:
            raise ValueError('La métrica no está en 0..100')
    except (TypeError, ValueError, re.error, KeyError, IndexError) as exc:
        return gate_result(name, 'BLOCKED', f'Métrica/umbral inválido: {exc}', **kwargs)

    kwargs['metric'] = {'value': score, 'min_value': minimum, 'unit': 'percent'}
    if score < minimum:
        return gate_result(name, 'FAIL', f'Métrica insuficiente ({score:.2f} < {minimum:.2f})', **kwargs)
    return gate_result(name, 'PASS', 'Comando y métrica cumplen política', **kwargs)


def run(project_root: Path, policy_path: Path, profile: str, report_path: Path):
    project_root = project_root.resolve()
    policy_path = (policy_path if policy_path.is_absolute() else project_root / policy_path).resolve()
    report_path = (report_path if report_path.is_absolute() else project_root / report_path).resolve()
    report = {
        'schema_version': 1, 'created_at': datetime.now(timezone.utc).isoformat(),
        'project_root': str(project_root), 'profile': profile,
        'policy_path': str(policy_path), 'policy_sha256': None,
        'status': 'BLOCKED', 'gates': [],
    }
    try:
        raw = policy_path.read_bytes()
        report['policy_sha256'] = hashlib.sha256(raw).hexdigest()
        data = tomllib.loads(raw.decode('utf-8'))
        profiles, gates = data.get('profiles'), data.get('gates')
        if not isinstance(profiles, dict) or not isinstance(gates, dict):
            raise ValueError('Faltan tablas [profiles] y [gates]')
        section = profiles.get(profile)
        if not isinstance(section, dict) or not isinstance(section.get('required'), list):
            raise ValueError(f'Perfil inexistente o incompleto: {profile}')
        required = section['required']
        if not required or not all(isinstance(x, str) and x for x in required):
            raise ValueError('required debe ser lista no vacía de nombres de gates')
        if len(required) != len(set(required)):
            raise ValueError('required no admite gates duplicados')
        for name in required:
            report['gates'].append(execute_gate(name, gates.get(name), project_root))
        statuses = [g['status'] for g in report['gates']]
        report['status'] = 'FAIL' if 'FAIL' in statuses else 'BLOCKED' if 'BLOCKED' in statuses else 'PASS'
    except (OSError, UnicodeError, tomllib.TOMLDecodeError, ValueError) as exc:
        report['gates'].append(gate_result('policy', 'BLOCKED', f'Política no verificable: {exc}'))
    try:
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        report['report_path'] = str(report_path)
    except OSError as exc:
        report['gates'].append(gate_result('report', 'BLOCKED', f'No se pudo escribir el reporte: {exc}'))
        report['status'] = 'BLOCKED'
    return report


def main(argv=None):
    ap = argparse.ArgumentParser(description='Evaluación de calidad independiente por política TOML')
    ap.add_argument('--project-root', type=Path, default=Path('.'))
    ap.add_argument('--policy', type=Path, default=Path('quality-gates.toml'))
    ap.add_argument('--profile', choices=('quick', 'full', 'critical'), default='full')
    ap.add_argument('--report', type=Path, default=Path('.quality/reports/latest.json'))
    args = ap.parse_args(argv)
    report = run(args.project_root, args.policy, args.profile, args.report)
    print(json.dumps({'status':report['status'], 'report_path':report.get('report_path'),
                      'profile':args.profile, 'gates':[{'name':g['name'],'status':g['status'],
                      'reason':g['reason']} for g in report['gates']]}, ensure_ascii=False))
    return {'PASS': 0, 'FAIL': 1, 'BLOCKED': 2}[report['status']]

if __name__ == '__main__':
    sys.exit(main())
