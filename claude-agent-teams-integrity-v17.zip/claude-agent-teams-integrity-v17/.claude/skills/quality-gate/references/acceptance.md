# Política de aceptación independiente

Un runner no demuestra que los tests sean buenos: emparejar evidencia automática con revisión semántica de `review`. Se necesitan aceptación de requisitos, tests representativos y políticas aprobadas por responsables.

- `quick`: para feedback local, por ejemplo syntax + unit tests.
- `full`: cierre de cambios: además de quick, integración, lint/tipado, cobertura si está configurada, seguridad.
- `critical`: además incluye mutación, contract tests, performance o compliance cuando el proyecto los haya establecido.
- No fijar 80%, 90% o 95% de cobertura/mutación sin conocer el riesgo. Elegir los valores por repositorio en `quality-gates.toml` y proteger ese archivo con revisión.
- `PASS`: comandos requeridos se ejecutaron y cumplieron umbrales; `FAIL`: comando/umbral incumplido; `BLOCKED`: no se puede evaluar (política, herramienta o métrica ausente). Un cambio con BLOCKED no está aprobado.
- JSON de evidencia: `policy_sha256`, comandos, códigos de salida, duraciones, scores y ruta del informe.
- No aceptar omitir tests, bajar thresholds o reemplazar asserts para generar PASS.

## Ejecutar
```bash
python .claude/skills/quality-gate/scripts/run_gates.py --project-root . --profile quick
python .claude/skills/quality-gate/scripts/run_gates.py --project-root . --profile full
```
Configura primero un archivo `quality-gates.toml` válido desde `examples/quality-gates.python.toml` o `examples/quality-gates.package.toml`, adaptando comandos a tus herramientas instaladas. El paquete no crea automáticamente una política aplicada al código del usuario.
