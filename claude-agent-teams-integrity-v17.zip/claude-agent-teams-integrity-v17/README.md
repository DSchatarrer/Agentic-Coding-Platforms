# Agent Teams Lean — Claude Code v17 (Ponytail + Caveman adaptados)

Migración **completa y nativa** desde Agent Teams Lean v14 para Codex. Conserva diez especialistas con su skill propia, referencias progresivas, Engram local, Context7 HTTP, Playwright MCP, Quality Gates, catálogo de skills, `TODO.md` modular y Git init seguro.

## Integración selectiva de Ponytail y Caveman

**Ponytail:** regla compacta en `changed-code-tests` y referencia `_shared/minimal-complete-change.md`, consumida progresivamente por `create`, `debug`, `refactor` y `review`. Se mantiene el máximo de cinco entradas aprobadas sin añadir un agente nuevo.

**Caveman:** skill nativa manual `/concise-output` (`disable-model-invocation: true`). Resume la **respuesta al usuario**, nunca las herramientas, las pruebas o el handoff. No instala plugins de terceros, no activa hooks, Auto, proxy o compresión de logs. La skill no garantiza menor coste total: medir antes/después.

**Ejemplos en Claude Code:**

```text
Corrige el bug de autenticación; reutiliza lo existente, demuestra la regresión y solicita review.
/concise-output Revisa los cambios y resume los archivos, las pruebas y los riesgos.
```

Para actualizar una instalación previa, consultar [migración v16 → v17](MIGRACION_CLAUDE_V17.md). Si ya tienes los plugins externos instalados a nivel global, revisa `/hooks` y `/plugin` para evitar reglas duplicadas.

## Elección de modelos

| Rol | Claude Code (ID fijo) | Esfuerzo | Motivación |
|---|---|---|---|
| `orchestrator` (principal) | `claude-opus-5-5` | `medium` | Coordinación compleja, criterio de delegación |
| `plan` | `claude-opus-5-5` | `medium` | Diseño, dependencias y TODO |
| `research`, `create`, `debug`, `test`, `review`, `refactor`, `docs`, `skill-creator`, `quality-gate` | `claude-haiku-5-5` | `low` | Rol especializado, latencia y coste reducidos |

**Alternativa cuando Haiku se quede corto en tareas de desarrollo:** usar `claude-sonnet-5-5` / `low` para `create`, `debug`, `test`, `refactor` o `review`. Requiere cambiar deliberadamente el frontmatter del agente correspondiente y probarlo; no hay escalado automático ni promesa de equivalencia de calidad exacta.

Los modelos dependen de tu cuenta y proveedor. Con Claude Code actualizado, los IDs están documentados por Anthropic. Los límites por organización y las variables `CLAUDE_CODE_SUBAGENT_MODEL*` / `CLAUDE_CODE_EFFORT_LEVEL` pueden alterar el resultado: compruébalo con `/status` y `/tasks`.

## Árbol principal

```text
CLAUDE.md                        # Instrucciones globales del proyecto, pequeñas
.mcp.json                        # Context7 HTTP oficial, sin credenciales
.claude/
  settings.json                  # agente principal, Opus/medium, sin memoria nativa paralela
  agents/
    orchestrator.md              # agente principal con allowlist de delegación
    plan.md                      # Opus / medium + skill plan
    create.md, debug.md, ...     # Haiku / low + una skill precargada
  skills/
    _shared/                     # estándares, catálogo, memoria y arquitectura
      memory/                    # prevención de duplicados en Engram
      architecture/              # clean, hexagonal, capas (lectura condicional)
      minimal-complete-change.md # criterio selectivo de Ponytail
    plan/references/             # TODO crear/auditar/continuar/actualizar/replanificar
    concise-output/SKILL.md      # salida breve manual: /concise-output (no agente)
    quality-gate/scripts/        # runner determinista
    skill-creator/scripts/       # catálogo + scaffold
scripts/
  install.py                     # instalador no destructivo, con respaldos
  validate.py                    # valida estructura y enlaces
  git_init.py                    # git init opt-in, sin commits
  context_profile.py             # proxy de palabras, no tokens reales
  audit_integrity.py             # auditoría de rutas Markdown y comandos
tests/                          # tests de agentes, MCP, memoria, Git, quality gates
examples/                       # políticas de calidad y CI
```

## Prerrequisitos

- **Claude Code** actualizado (se recomienda versión ≥2.1.296 por soporte actual de frontmatter). Ejecuta `claude --version` y `claude update`. Autentícate con tu plan o proveedor.
- Python **3.11+**, usado para el instalador y scripts; no para ejecutar Claude Code.
- **Engram** local ya instalado para la memoria, con el binario `engram` en `PATH`.
- Node.js y `npx` para Playwright MCP cuando se use una interfaz web; el proyecto no descarga nada por sí solo durante la instalación.
- Git es opcional; solo se inicializa por petición explícita.

## Instalación en Windows (PowerShell)

Extrae este ZIP y abre la terminal en su carpeta:

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto" --dry-run
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto"
```

Si ya instalaste una versión anterior **para Claude Code** y quieres reemplazar archivos gestionados, revisa los cambios y usa `--force` (se crean respaldos). El instalador copia `.claude/agents/`, `.claude/skills/`, `scripts/git_init.py`, `scripts/validate.py`, `scripts/context_profile.py`, `scripts/audit_integrity.py`, añade un bloque delimitado a `CLAUDE.md`, fusiona `.claude/settings.json` y añade **solo** Context7 a `.mcp.json`. No borra otras configuraciones, agentes, skills ni MCP existentes. Al terminar, **regenera el catálogo generado con las skills realmente presentes en el destino** (con respaldo si cambia), sin modificar los estándares aprobados.

`--force` puede reemplazar los campos gestionados de `.claude/settings.json` (`agent`, `model`, `effortLevel`, `autoMemoryEnabled`), creando respaldo, pero **no** sustituye definiciones MCP ya personalizadas. Sin `--force`, los ajustes existentes tienen prioridad. Los conflictos se muestran en la salida; revísalos.

Para iniciar Git solo si no existe repositorio propio o padre:

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto" --init-git
# O en un proyecto ya instalado:
py -3 scripts/git_init.py --project-root "C:\ruta\a\mi-proyecto"
```

El script nunca crea commits ni remotos; evita repositorios anidados.

## Engram local — sin duplicaciones

La opción recomendada por el proyecto oficial Engram para Claude Code es **instalar su plugin y registrar el MCP**. Como ya tienes Engram local, **no** se copia su base de datos ni se añade otro servidor Engram al `.mcp.json` de este paquete:

```powershell
engram setup claude-code
claude mcp list
```

El setup completo puede requerir `jq` y `curl` y una versión actual de Claude Code. Si no están disponibles, sigue la opción MCP-only descrita por Engram en su documentación oficial, sin sobrescribir conexiones preexistentes. Reinicia Claude Code para cargar hooks actualizados. El `CLAUDE.md` y las referencias `_shared/memory/` fijan la política de escrituras: **buscar, verificar, reutilizar `topic_key`, actualizar** antes de crear observaciones y no guardar logs de pruebas o secretos. Se desactiva la memoria nativa automática del proyecto mediante `autoMemoryEnabled: false` para no mantener un segundo sistema de memoria paralelo, siempre que ninguna política superior la reemplace.

## Context7 y Playwright MCP

- **Context7:** `.mcp.json` registra `https://mcp.context7.com/mcp` con `type: http`. Claude Code puede pedir aprobación al abrir el proyecto; la autenticación opcional se configura fuera del repositorio. No se incluyen tokens.
- **Playwright:** se define *inline y bajo demanda* en los agentes `create`, `debug`, `test`, `review` y `quality-gate`, mediante `npx -y @playwright/mcp@latest --headless --isolated`. Claude Code puede requerir aceptar la confianza del proyecto; no se activa globalmente para el coordinador. Los demás agentes no lanzan navegador.

La interacción exploratoria con Playwright MCP no sustituye Playwright Test automatizado ni una prueba ejecutada por el Quality Gate.

## Iniciar Claude Code con tu orquestador

```powershell
cd "C:\ruta\a\mi-proyecto"
claude --agent orchestrator
```

El archivo `.claude/settings.json` ya contiene `"agent": "orchestrator"`, por lo que `claude` también puede arrancar en ese modo si no existe una configuración de mayor prioridad. Verifica en la cabecera `@orchestrator`, `/status` y `/agents`. Si `claude --agent orchestrator` reemplaza el prompt predeterminado de la sesión, eso es el comportamiento esperado del subagente configurado como hilo principal.

Prueba inicial: «Usa `research` para inspeccionar la estructura sin modificar archivos. Después dame los siguientes pasos». El orquestador escoge el mínimo número de especialistas; `plan` no participa en toda tarea. Puedes solicitar `@agent-test` cuando necesites delegar explícitamente.

## Carga progresiva y catálogo

Cada `.claude/agents/<nombre>.md` declara `skills: [<nombre>]`; el contenido de su `SKILL.md` se precarga una vez en su contexto. No se relee. Cada skill enlaza sus referencias condicionales, y el orquestador solo inyecta hasta cinco estándares aprobados, no catálogos completos. El script de generación nunca altera esas reglas humanas:

```powershell
py -3 .claude/skills/skill-creator/scripts/build_registry.py --project-root .
py -3 .claude/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 .claude/skills/skill-creator/scripts/scaffold_skill.py mi-agente "Descripción concreta" --project-root . --with-agent
```

## Quality Gates y validación

**Desde el ZIP fuente**, se pueden ejecutar los tests del paquete. **Desde el proyecto instalado**, los scripts de validación y auditoría están disponibles, pero el instalador no copia `tests/` ni los ejemplos para evitar introducir pruebas ajenas en tu proyecto.

```powershell
py -3 scripts/validate.py --project-root .
py -3 scripts/audit_integrity.py --project-root .
py -3 scripts/context_profile.py --project-root . --json
# Solo desde el ZIP fuente:
py -3 scripts/audit_integrity.py --project-root . --source
py -3 -m unittest discover -s tests -q
```

Para evaluar un proyecto de verdad, configura `quality-gates.toml` según los ejemplos. La ausencia de política produce `BLOCKED`, nunca `PASS` inventado. El análisis de `context_profile.py` es una **estimación estática de palabras**; el gasto real solo puede medirse con Claude Code ejecutándose.

## Limitaciones

- No se ha probado con una sesión Claude Code real ni el MCP de tu ordenador (el binario `claude` y `engram` no están disponibles en el entorno de construcción).
- Es posible que políticas de la organización, permisos, modelos no habilitados o versiones antiguas de Claude Code impidan activar determinados agentes o MCP. Comprueba `/doctor`, `/mcp`, `/status` y `/tasks`.
- El orquestador tiene limitaciones de herramientas intencionales, pero la prohibición de editar código inline es sobre todo una **instrucción de rol**, no una garantía de sandbox. Para reglas de seguridad reales usa permisos de Claude Code.
- La nueva instalación **no modifica ni elimina** una antigua configuración Codex. Puedes conservar ambas herramientas en paralelo.

## Documentación oficial

- https://code.claude.com/docs/en/sub-agents
- https://code.claude.com/docs/en/skills
- https://code.claude.com/docs/en/mcp
- https://code.claude.com/docs/en/settings
- https://code.claude.com/docs/en/model-config
- https://platform.claude.com/docs/en/models/overview
- https://github.com/Gentleman-Programming/engram/blob/main/docs/AGENT-SETUP.md
