# Agent Teams Lean — Claude Code

Este proyecto utiliza el agente principal `orchestrator` definido en `.claude/agents/orchestrator.md` y habilitado en `.claude/settings.json`. El coordinador delega en especialistas independientes; no implementa código. Cada agente precarga **una** skill `.claude/skills/<rol>/SKILL.md` y abre referencias solo cuando aplique.

Fuente de verdad: código, Git y pruebas. Engram únicamente para decisiones duraderas curadas (no logs ni duplicados); Context7 para documentación de APIs y Playwright para navegación real selectiva. `quality-gate` independiente y evidencia antes de afirmar éxito.

No cargar catálogo completo al iniciar. Estándares aprobados: `.claude/skills/_shared/project-skill-registry.md`. Catálogo descubierto: `.claude/skills/_shared/skill-catalog.md`. Validar con `python scripts/validate.py --project-root .`. No crear commits ni inicializar Git sin petición. Preferir el menor cambio completo según `changed-code-tests`; `/concise-output` es una skill manual de salida, no un cambio de modelos, herramientas ni aceptación.
