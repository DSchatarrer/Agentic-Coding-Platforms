# Agent Teams Lean — Claude Code

Este proyecto usa `orchestrator` como agente principal definido en `.claude/agents/orchestrator.md` y seleccionado mediante `.claude/settings.json`. No implementa código: delega en diez especialistas, cada uno con **una skill de rol** y referencias progresivas. Calidad y pruebas reales antes de afirmar éxito.

## I Have ADHD: siempre activo (solo presentación pública del coordinador)

@.claude/skills/_shared/adhd-always-on.md

Aplicar permanentemente las diez reglas en **respuestas al usuario** del coordinador, sin `/i-have-adhd`. Los especialistas reciben solo su perfil operativo en la política importada; handoffs, evidencia, logs, formatos estructurados y contratos de salida nunca se comprimen. No añadir hooks ni precargar la skill como segunda skill en los subagentes.

## Integridad del equipo

Fuente de verdad: código, Git y pruebas. Engram solo para decisiones duraderas curadas; Context7 para APIs y Playwright bajo demanda. `quality-gate` independiente. Catálogo progresivo: `.claude/skills/_shared/project-skill-registry.md` y `.claude/skills/_shared/skill-catalog.md`. No cargar catálogos completos al iniciar. Validar con `python scripts/validate.py --project-root .`; aplicar `changed-code-tests` de Ponytail. No inicializar Git ni crear commits sin solicitud explícita.
