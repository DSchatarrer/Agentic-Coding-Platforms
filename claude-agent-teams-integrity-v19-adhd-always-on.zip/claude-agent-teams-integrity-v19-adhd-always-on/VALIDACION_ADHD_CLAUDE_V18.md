# Validación de la integración — Claude Agent Teams v18 (I Have ADHD)

Fecha: 2026-11-03.

## Resultados locales

- Se ejecutaron **78 pruebas** en total (cinco módulos de tests, ejecutados por separado), todas correctas. La distribución fue: `test_claude_package` 35, `test_integrity` 5, `test_memory_git` 11, `test_quality_gate` 9 y `test_ponytail_adhd_v18` 18.
- `python scripts/validate.py --project-root .`: **OK**, once definiciones de agentes (un coordinador + diez especialistas), diez skills de rol y una skill auxiliar manual `i-have-adhd`.
- `python scripts/audit_integrity.py --project-root . --source`: **OK**, 74 ficheros Markdown, 137 enlaces locales, 14 rutas Python documentadas.
- `python .claude/skills/skill-creator/scripts/build_registry.py --project-root . --check`: **OK**, 11 skills reconocidas, convenciones y cinco estándares aprobados intactos.
- Skill upstream: diez reglas originales conservadas, `disable-model-invocation: true`, `user-invocable: true`, licencia MIT copiada y referencia de integración propia del proyecto.
- `.claude/settings.json` y `.mcp.json`: **sin cambios respecto a v17**. Ningún nuevo agente, hook, plugin, servidor MCP ni dependencia.

## Migración real v17 → v18

Se hizo una prueba separada con el ZIP **original** `claude-agent-teams-integrity-v17.zip`:

1. Instalar v17 en un proyecto temporal con ajustes, hook y MCP personalizados.
2. Capturar hashes de los diez agentes especialistas, Ponytail y el runner de Quality Gate.
3. Ejecutar `install.py --force --dry-run` de v18 y comprobar **cero cambios** en archivos.
4. Ejecutar `install.py --force` de v18, comprobar que `concise-output` original desaparece y su respaldo `.bak` existe; `i-have-adhd` queda instalada.
5. Comparar SHA-256 de los diez especialistas, Ponytail y runner Quality Gate (**todos idénticos**). Confirmar que se conservan las reglas fuera del bloque gestionado `CLAUDE.md`, hook y MCP personalizados. Ejecutar validador, auditoría y comprobación de catálogo del proyecto instalado (**OK**).

En este escenario de prueba se crearon nueve respaldos; el número cambia según los archivos preexistentes. Las pruebas de regresión adicionales cubren la conservación obligatoria de una `concise-output` modificada, symlinks, `--dry-run`, reinstalación idempotente y fallo de validación si la invocación implícita se reactiva.

## Límites

- Estas pruebas **no ejecutan Claude Code** ni garantizan el comportamiento de una conversación real, la persistencia tras compaction ni ahorro de tokens.
- El modo de salida lo aplica el modelo según la skill y las instrucciones actuales; no se mantiene un interruptor técnico de sesión externo ni un hook automatizado.
- Una antigua `concise-output` personalizada se **conserva con conflicto**, incluso con `--force`, y requiere revisión manual antes de finalizar la migración.
- Los documentos `MIGRACION_CLAUDE_V17.md` y `VALIDACION_INTEGRACION_V17.md` son registros históricos; el estado vigente se describe en `README.md` y `MIGRACION_CLAUDE_ADHD_V18.md`.
