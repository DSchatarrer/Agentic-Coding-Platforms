# Compatibilidad — I Have ADHD + Agent Teams Lean (Claude Code v19)

**Activación por defecto:** el proyecto incluye la política [adhd-always-on](../../_shared/adhd-always-on.md), importada por `CLAUDE.md` cada sesión. **No se requiere** `/i-have-adhd` y no hay hooks ni plugins externos. La skill canónica se conserva con sus diez reglas; su comando manual es opcional y redundante mientras se use este proyecto.

## Perfiles y prioridad

- El `orchestrator` aplica **las diez reglas** a todas las respuestas destinadas al usuario. Esta configuración se vuelve a cargar desde `CLAUDE.md` tras compaction; no se basa en recordar un turno anterior.
- Los diez especialistas **no precargan** `i-have-adhd` como segunda skill. Solo aplican sus perfiles operativos declarados en la política permanente y en el archivo del agente. No se les impone tope a listas, código, opciones, logs ni formatos.
- Un usuario puede solicitar otro formato para una respuesta concreta, pero el proyecto continúa configurado como always-on para sesiones nuevas. No se modifica la configuración global de Claude.
- Contratos superiores, seguridad, solicitud de explicación completa y evidencia real prevalecen. No cambiar modelos, agentes, herramientas, Ponytail, Engram, MCP ni decisiones de calidad.

## Integridad del handoff

Conservar literalmente código, JSON, SQL, comandos, diffs, rutas, parámetros y payloads contractuales. `status: success|partial|blocked`, `quality_gate: PASS|FAIL|BLOCKED|not_run|not_applicable`, exit codes, pruebas ejecutadas/fallidas/no ejecutadas, hallazgos, riesgos y bloqueos no se ocultan. `not_run` nunca es PASS. Si se ofrece un extracto público, identificarlo y conservar el registro íntegro.

Estimaciones solo para acciones humanas y solo cuando hay fundamento; no prometer ejecución asíncrona ni inventar tiempos. Calidad y Ponytail conservan plena independencia.
