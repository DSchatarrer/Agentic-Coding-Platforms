# Handoff escalonado al coordinador

**Simple (por defecto):** `status` (`success|partial|blocked`), resumen, archivos, pruebas ejecutadas (comando + exit code, si hubo) y bloqueos. `quality_gate` distinto del `status`: `PASS|FAIL|BLOCKED|not_run|not_applicable`. No enviar campos vacíos ni JSON extenso si no hace falta.

**Complejo / cierre formal:** añadir evidencias y rutas verificables, riesgos, `skill_resolution` (`injected|none|registry-missing|not_applicable`, con IDs aprobados reales), resultados de Quality Gate e IDs reales de Engram si se consultó/guardó. No confundir `not_run` con `PASS`.

**Presentación ADHD permanente (v19):** el `CLAUDE.md` del proyecto importa la [política siempre activa](adhd-always-on.md). El coordinador adapta **toda respuesta destinada al usuario** (acción inmediata, pasos acotados, progreso visible), sin invocación explícita. Los especialistas mantienen **sus handoffs técnicos íntegros** y solo aplican microhábitos operativos por rol: ni resumen de logs, ni límite a cinco hallazgos, ni manipulación de resultados. Conservar `status`, `quality_gate`, archivos, pruebas ejecutadas/fallidas/no ejecutadas y riesgos/bloqueos pertinentes. Un resumen público nunca sustituye las evidencias originales.

Los especialistas no inventan pruebas ni memorias. Referencias de calidad provienen del runner; decisiones persistentes siguen el [contrato de Engram](engram.md); solo quien verificó un hallazgo lo guarda, y el coordinador no duplica su observación.
