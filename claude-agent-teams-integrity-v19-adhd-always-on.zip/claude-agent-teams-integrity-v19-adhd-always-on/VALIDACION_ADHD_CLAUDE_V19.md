# Validación v19 — I Have ADHD always-on y perfiles selectivos

Fecha: 2026-11-03.

## Resultado ejecutado

**82/82 pruebas correctas** en cinco módulos de test, ejecutados individualmente: `test_claude_package` (35), `test_integrity` (5), `test_memory_git` (11), `test_ponytail_adhd_v19` (22), `test_quality_gate` (9).

Comprobaciones complementarias:

- `python scripts/validate.py --project-root .`: **OK** (once agentes, diez perfiles y política always-on).
- `python scripts/audit_integrity.py --project-root . --source`: **OK** (77 Markdown, 140 enlaces locales, 14 comandos Python documentados).
- `python .claude/skills/skill-creator/scripts/build_registry.py --project-root . --check`: **OK** (11 skills, cinco estándares originales intactos).

## Actualización real usando el ZIP v18 original

- Instalado `claude-agent-teams-integrity-v18-adhd.zip` en un destino temporal con su instalador original.
- Añadido un bloque de usuario fuera de los marcadores gestionados en `CLAUDE.md`, un hook `SessionStart` y un MCP de prueba.
- `--force --dry-run` v19: **0 archivos modificados** (76 archivos existentes).
- `--force` v19: import always-on instalado, agente coordinador actualizado, 10 perfiles operativos reconocidos.
- Hashes SHA-256 de cuatro skills Ponytail, política de cambio mínimo y runner de Quality Gate: **6/6 idénticos** respecto a v18.
- Bloque de usuario de `CLAUDE.md`, hook y MCP personalizado: **conservados**; `validate.py` sobre el destino: **OK**; segunda instalación idéntica en `CLAUDE.md`. Respaldo automático de archivos gestionados modificado: comprobado (16 copias en esa simulación).

Esta prueba usa efectivamente el ZIP de v18 suministrado, no una reconstrucción basada en el estado de v19.

## Controles

- Import always-on presente en `CLAUDE.md`; el archivo de política existe, conserva las diez reglas y define los diez perfiles.
- `orchestrator` aplica perfil completo; `plan`, `debug`, `create`, `refactor`, `research`, `docs`, `test`, `review`, `skill-creator` y `quality-gate` aplican las excepciones por rol.
- Handoff mantiene `status`, `quality_gate`, evidencias, rutas, casos y bloqueos sin tope artificial de cinco elementos.
- Instalación inicial, migración v18 → v19, reinstalación, conflictos `CLAUDE.md`, `--dry-run`, `--no-claude-md`, hooks y MCP preexistentes.
- Integridad de Ponytail, Engram, Context7, Playwright, modelos, diez especialistas y Quality Gate.

**Límite:** test estático y de instalación no sustituye pruebas reales ejecutando Claude Code. La aplicación del estilo depende de las instrucciones cargadas y de la jerarquía del proveedor.
