# Migración Claude Agent Teams v18 → v19: I Have ADHD siempre activo

## Qué cambia

- `i-have-adhd` queda activo por defecto **en las respuestas del orquestador al usuario**, sin invocar slash command, mediante el import de `.claude/skills/_shared/adhd-always-on.md` desde `CLAUDE.md`.
- Los diez especialistas reciben **perfiles operativos diferenciados** (sin segunda skill y sin acortar evidencias); `quality-gate` mantiene la integridad total de los informes.
- Se actualiza el handoff, guía de compatibilidad, validador, instalador y README; Ponytail, modelos, MCP, Engram, configuración y estándares aprobados no se tocan.
- No se instalan hooks ni el plugin global. La skill upstream y su comando `/i-have-adhd` se mantienen para compatibilidad, pero el comando ya no es necesario.

## Instalación PowerShell

Descomprime el paquete v19 y ejecuta:

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto" --force --dry-run
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto" --force
```

El instalador hace respaldo de los archivos gestionados que reemplaza. Conservará cualquier sección de `CLAUDE.md` fuera del bloque `<!-- agent-teams-claude:start -->` y `<!-- agent-teams-claude:end -->`. Revisa el dry-run antes de usar `--force`, especialmente si personalizaste agentes. **No uses `--no-claude-md`** si quieres que esté activo desde el primer turno.

Si tu proyecto aún no tenía un bloque gestionado `CLAUDE.md`, se agrega uno sin borrar tus instrucciones. Si tu `CLAUDE.md` tiene instrucciones contradictorias propias, revisa el conflicto y unifica la política manualmente; la instalación no puede garantizar cuál seguirá el modelo.

## Verificar

```powershell
py -3 scripts/validate.py --project-root "C:\ruta\a\mi-proyecto"
py -3 .claude/skills/skill-creator/scripts/build_registry.py --project-root "C:\ruta\a\mi-proyecto" --check
```

En una **sesión nueva** de Claude Code, dentro del proyecto, revisa `/memory` o `/context`: deben cargar `CLAUDE.md` y `adhd-always-on.md`. Pide una tarea con varios pasos **sin ejecutar** `/i-have-adhd`; comprueba la salida pública y los handoffs de prueba/revisión/quality-gate.

## Límites

Solo afecta al **proyecto donde se instala**, no a todas las sesiones globales de Claude Code. Se trata de instrucciones persistentes de proyecto, no de un mecanismo que imponga formalmente cada palabra; no se prueba el cumplimiento real del modelo sin ejecutar Claude Code. No garantiza el aislamiento de instrucciones externas con mayor prioridad. El `--force` protege otros bloques de `CLAUDE.md` pero puede actualizar otros archivos gestionados, siempre con copia de respaldo.
