"""Regresiones migración Caveman -> ADHD (v18) y always-on (v19)."""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
LEGACY = ROOT/'tests/fixtures/concise-output-v17.SKILL.md'


def load(path):
    spec = importlib.util.spec_from_file_location('adhd_'+path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


install = load(ROOT/'scripts/install.py')
validate = load(ROOT/'scripts/validate.py')


class ADHDClaudeIntegration(unittest.TestCase):
    def test_manual_only_skill(self):
        p = ROOT/'.claude/skills/i-have-adhd/SKILL.md'
        meta, _ = validate.frontmatter(p.read_text(encoding='utf8'))
        self.assertEqual('i-have-adhd', meta['name'])
        self.assertEqual('true', meta['disable-model-invocation'])
        self.assertEqual('true', meta['user-invocable'])
        self.assertEqual('MIT', meta['license'])
        self.assertTrue((p.parent/'LICENSE').exists())
        self.assertTrue((p.parent/'references/agent-teams-compat.md').exists())
        self.assertFalse((ROOT/'.claude/skills/concise-output/SKILL.md').exists())

    def test_upstream_ten_rules_and_stop_modes(self):
        contents = (ROOT/'.claude/skills/i-have-adhd/SKILL.md').read_text()
        for i in range(1, 11):
            self.assertIn(f'### {i}. ', contents)
        self.assertIn('stop adhd mode', contents)
        self.assertIn('normal mode', contents)
        self.assertIn('agent-teams-compat.md', contents)

    def test_no_new_agents_or_standard(self):
        self.assertEqual(11, len(list((ROOT/'.claude/agents').glob('*.md'))))
        for name in ('i-have-adhd', 'concise-output'):
            self.assertFalse((ROOT/f'.claude/agents/{name}.md').exists())
        reg = (ROOT/'.claude/skills/_shared/project-skill-registry.md').read_text()
        self.assertEqual(5, reg.count('### '))
        self.assertEqual(1, reg.count('### changed-code-tests'))

    def test_ponytail_affected_roles_unchanged(self):
        for role in ('create', 'debug', 'refactor', 'review'):
            self.assertIn('../_shared/minimal-complete-change.md',
                          (ROOT/f'.claude/skills/{role}/SKILL.md').read_text())

    def test_handoff_preserves_evidence(self):
        text = (ROOT/'.claude/skills/_shared/handoff.md').read_text()
        for value in ('toda respuesta destinada al usuario', 'quality_gate',
                      'pruebas ejecutadas/fallidas/no ejecutadas', 'adhd-always-on.md'):
            self.assertIn(value, text)

    def test_orchestrator_public_style_and_subagents_role_profiles(self):
        text = (ROOT/'.claude/agents/orchestrator.md').read_text()
        self.assertIn('siempre activa', text)
        self.assertIn('cada respuesta pública', text)
        for role in validate.ROLES:
            s = (ROOT/f'.claude/agents/{role}.md').read_text()
            self.assertIn('Perfil ADHD operativo', s)
            self.assertNotIn('skills:\n  - i-have-adhd', s)
        q = (ROOT/'.claude/agents/quality-gate.md').read_text()
        self.assertIn('no aplicar reglas de concisión', q)

    def test_auto_policy_import_and_ten_rules(self):
        policy = (ROOT/'.claude/skills/_shared/adhd-always-on.md').read_text()
        root_md=(ROOT/'CLAUDE.md').read_text()
        self.assertIn('@.claude/skills/_shared/adhd-always-on.md', root_md)
        for i in range(1,11):
            self.assertIn(f'\n{i}. **',policy)
        for role in validate.ROLES:
            self.assertIn(f'`{role}`',policy)
        self.assertIn('orchestrator',policy)
        self.assertIn('ni plugin global',policy)

    def test_no_new_hooks_settings_mcp(self):
        settings = json.loads((ROOT/'.claude/settings.json').read_text())
        self.assertNotIn('hooks', settings)
        self.assertEqual('claude-opus-5-5', settings['model'])
        self.assertEqual('medium', settings['effortLevel'])
        self.assertEqual(False, settings['autoMemoryEnabled'])
        self.assertEqual({'context7'}, set(json.loads((ROOT/'.mcp.json').read_text())['mcpServers']))

    def test_project_structure_valid(self):
        self.assertEqual([], validate.validate(ROOT))

    def test_installer_fresh(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            install.install(p)
            self.assertTrue((p/'.claude/skills/i-have-adhd/SKILL.md').is_file())
            self.assertFalse((p/'.claude/skills/concise-output/SKILL.md').exists())
            catalog = (p/'.claude/skills/_shared/skill-catalog.md').read_text()
            self.assertIn('`i-have-adhd`', catalog)
            self.assertNotIn('`concise-output`', catalog)
            self.assertEqual([], validate.validate(p))

    def test_installation_always_on_present_without_manual_invocation(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            install.install(p)
            self.assertIn('@.claude/skills/_shared/adhd-always-on.md', (p/'CLAUDE.md').read_text())
            self.assertTrue((p/'.claude/skills/_shared/adhd-always-on.md').is_file())
            self.assertEqual([],validate.validate(p))
            before=(p/'CLAUDE.md').read_bytes()
            events=install.install(p,force=True)
            self.assertEqual(before,(p/'CLAUDE.md').read_bytes())
            self.assertFalse(any('ACTUALIZAR CLAUDE.md' in e for e in events))

    def test_no_claude_md_flag_explicitly_warns_always_on_unavailable(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)
            events=install.install(p,no_claude_md=True)
            self.assertTrue(any('ADVERTENCIA' in e and '--no-claude-md' in e for e in events))
            self.assertFalse((p/'CLAUDE.md').exists())

    def test_validator_detects_missing_import_and_profile(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)
            install.install(p)
            md=p/'CLAUDE.md'
            md.write_text(md.read_text().replace('@.claude/skills/_shared/adhd-always-on.md',''))
            q=p/'.claude/agents/quality-gate.md'
            q.write_text(q.read_text().replace('Perfil ADHD operativo',''))
            errors=validate.validate(p)
            self.assertTrue(any('no importa' in e for e in errors))
            self.assertTrue(any('quality-gate no define' in e for e in errors))

    def test_installer_dry_run_no_write(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            install.install(p, dry_run=True)
            self.assertFalse((p/'.claude').exists())

    def test_migrates_exact_v17_skill_even_without_force(self):
        self.assertEqual(install.LEGACY_CONCISE_SHA256, hashlib.sha256(LEGACY.read_bytes()).hexdigest())
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            old = p/'.claude/skills/concise-output/SKILL.md'
            old.parent.mkdir(parents=True)
            old.write_bytes(LEGACY.read_bytes())
            events = install.install(p)
            self.assertFalse(old.exists())
            self.assertEqual(1, len(list(old.parent.glob('SKILL.md.bak.*'))))
            self.assertTrue(any('MIGRACIÓN: retirar concise-output' in e for e in events))
            self.assertTrue((p/'.claude/skills/i-have-adhd/SKILL.md').exists())
            self.assertEqual([], validate.validate(p))
            self.assertNotIn('`concise-output`', (p/'.claude/skills/_shared/skill-catalog.md').read_text())
            # La instalación repetida no vuelve a migrar ni duplicar backups.
            more = install.install(p)
            self.assertFalse(any('MIGRACIÓN: retirar concise-output' in e for e in more))
            self.assertEqual(1, len(list(old.parent.glob('SKILL.md.bak.*'))))

    def test_dry_run_does_not_migrate_old(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            old = p/'.claude/skills/concise-output/SKILL.md'
            old.parent.mkdir(parents=True)
            old.write_bytes(LEGACY.read_bytes())
            events = install.install(p, dry_run=True, force=True)
            self.assertEqual(LEGACY.read_bytes(), old.read_bytes())
            self.assertFalse(list(old.parent.glob('SKILL.md.bak.*')))
            self.assertFalse((p/'.claude/skills/i-have-adhd/SKILL.md').exists())
            self.assertTrue(any('MIGRACIÓN: retirar concise-output' in e for e in events))

    def test_custom_old_skill_never_deleted_even_force(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            old = p/'.claude/skills/concise-output/SKILL.md'
            old.parent.mkdir(parents=True)
            custom = LEGACY.read_text() + '\n# Mi personalización\n'
            old.write_text(custom)
            events = install.install(p, force=True)
            self.assertEqual(custom, old.read_text())
            self.assertTrue(any('personalizada' in e and 'CONFLICTO' in e for e in events))
            self.assertTrue(any('migración pendiente' in e for e in validate.validate(p)))
            catalog = (p/'.claude/skills/_shared/skill-catalog.md').read_text()
            self.assertIn('`concise-output`', catalog)
            self.assertIn('`i-have-adhd`', catalog)

    def test_old_symlink_is_not_removed(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            external = p/'custom.SKILL.md'
            external.write_bytes(LEGACY.read_bytes())
            old = p/'.claude/skills/concise-output/SKILL.md'
            old.parent.mkdir(parents=True)
            try:
                old.symlink_to(external)
            except (OSError, NotImplementedError):
                self.skipTest('OS does not allow symlink')
            events = install.install(p, force=True)
            self.assertTrue(old.is_symlink())
            self.assertEqual(LEGACY.read_bytes(), external.read_bytes())
            self.assertTrue(any('archivo regular' in e for e in events))

    def test_installer_preserves_custom_hooks_models_and_mcp(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            (p/'.claude').mkdir()
            custom_hooks = {'SessionStart': [{'hooks': [{'type':'command', 'command':'echo ok'}]}]}
            (p/'.claude/settings.json').write_text(json.dumps({'agent':'custom', 'model':'my-model', 'hooks':custom_hooks}))
            (p/'.mcp.json').write_text(json.dumps({'mcpServers':{'mine':{'type':'http', 'url':'https://example.invalid'}}}))
            install.install(p)
            s = json.loads((p/'.claude/settings.json').read_text())
            self.assertEqual('custom', s['agent'])
            self.assertEqual('my-model', s['model'])
            self.assertEqual(custom_hooks, s['hooks'])
            self.assertIn('mine', json.loads((p/'.mcp.json').read_text())['mcpServers'])

    def test_validator_catches_auto_invocation(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            install.install(p)
            file = p/'.claude/skills/i-have-adhd/SKILL.md'
            file.write_text(file.read_text().replace('disable-model-invocation: true',
                                                     'disable-model-invocation: false'))
            self.assertTrue(any('opt-in' in e for e in validate.validate(p)))

    def test_validator_catches_missing_license(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            install.install(p)
            (p/'.claude/skills/i-have-adhd/LICENSE').unlink()
            self.assertTrue(any('licencia MIT' in e for e in validate.validate(p)))

    def test_managed_v17_upgrade_replaces_stale_refs_with_force(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)
            install.install(p)
            old = p/'.claude/skills/concise-output/SKILL.md'
            old.parent.mkdir(parents=True)
            old.write_bytes(LEGACY.read_bytes())
            c = p/'CLAUDE.md'
            c.write_text(c.read_text().replace('@.claude/skills/_shared/adhd-always-on.md', '/concise-output'))
            o = p/'.claude/agents/orchestrator.md'
            o.write_text(o.read_text().replace('siempre activa', '/concise-output'))
            events = install.install(p, force=True)
            self.assertFalse(old.exists())
            self.assertTrue(any('MIGRACIÓN:' in x for x in events))
            self.assertNotIn('/concise-output', c.read_text())
            self.assertNotIn('/concise-output', o.read_text())
            self.assertEqual([], validate.validate(p))


if __name__ == '__main__':
    unittest.main()
