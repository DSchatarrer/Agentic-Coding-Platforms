#!/usr/bin/env python3
"""Instalador no destructivo para Claude Code: preserva ajustes y MCP preexistentes.

Python >=3.11, solo biblioteca estándar. No instala Claude Code, Engram ni Node.
"""
from __future__ import annotations
import argparse
import hashlib
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
BEGIN='<!-- agent-teams-claude:start -->'
END='<!-- agent-teams-claude:end -->'
PROJECT_CONFIG = {'agent':'orchestrator','model':'claude-opus-5-5','effortLevel':'medium','autoMemoryEnabled':False}
MCP_CONTEXT7={'type':'http','url':'https://mcp.context7.com/mcp'}
# Huella de la skill Caveman adaptada incluida en la distribución Claude v17.
# Nunca borrar una variante modificada, ni siquiera con --force.
LEGACY_CONCISE_SHA256='802cfe7ce8585c570f7acdf6bfb8ec8a4319f2e91af9eee75ff0c7aa5d1c47e7'


def backup(path:Path, dry_run:bool, events:list[str]):
    if not path.exists(): return
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    target=path.with_name(path.name+'.bak.'+stamp)
    events.append(f'RESPALDO: {path} -> {target}')
    if not dry_run:
        shutil.copy2(path,target)


def read_json(path:Path)->dict:
    if not path.exists(): return {}
    data=json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data,dict): raise ValueError(f'Se esperaba objeto JSON en {path}')
    return data


def json_merge(target:Path, desired:dict, force:bool, dry_run:bool, events:list[str], heading:str):
    try:
        old=read_json(target)
    except (OSError,ValueError,json.JSONDecodeError) as exc:
        events.append(f'BLOQUEADO {target}: JSON previo inválido: {exc}'); return
    updated=dict(old)
    for key,value in desired.items():
        if key not in updated:
            updated[key]=value
        elif key=='mcpServers' and isinstance(updated[key],dict):
            servers=dict(updated[key]);
            for name,server in value.items():
                if name not in servers: servers[name]=server
                elif servers[name]!=server: events.append(f'CONSERVADO MCP preexistente: {name}')
            updated[key]=servers
        elif updated[key]!=value:
            if force:
                updated[key]=value
            else:
                events.append(f'CONSERVADO ajuste personalizado {key} de {target}; --force para cambiarlo')
    if old==updated:
        events.append(f'IGUAL {heading}: {target}');return
    backup(target,dry_run,events)
    events.append(f'ACTUALIZAR {heading}: {target}')
    if not dry_run:
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text(json.dumps(updated,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def copy_file(src:Path,dst:Path,force:bool,dry_run:bool,events:list[str]):
    if dst.is_file() and dst.read_bytes()==src.read_bytes():
        events.append(f'IGUAL {dst}');return
    if dst.exists() and not force:
        events.append(f'CONFLICTO, conservado {dst}; usa --force con respaldo para actualizar');return
    backup(dst,dry_run,events)
    events.append(f'ESCRIBIR {dst}')
    if not dry_run:
        dst.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(src,dst)


def migrate_legacy_concise(project_root:Path,dry_run:bool,events:list[str]):
    """Elimina solamente la skill antigua *exacta* de v17 (con respaldo).

    Nunca elimina skills editadas, otros ficheros ni symlinks gestionados por usuario.
    """
    legacy=project_root/'.claude/skills/concise-output/SKILL.md'
    folder=legacy.parent
    if not (legacy.exists() or legacy.is_symlink()): return
    if folder.is_symlink() or legacy.is_symlink() or not legacy.is_file():
        events.append(f'CONFLICTO: antigua concise-output no es archivo regular: {legacy}; revisar manualmente')
        return
    if hashlib.sha256(legacy.read_bytes()).hexdigest()!=LEGACY_CONCISE_SHA256:
        events.append(f'CONFLICTO: antigua concise-output personalizada: {legacy}; conservada incluso con --force')
        return
    backup(legacy,dry_run,events)
    events.append(f'MIGRACIÓN: retirar concise-output v17 original: {legacy}')
    if not dry_run:
        legacy.unlink()


def merge_claude_md(target:Path,force:bool,dry_run:bool,events:list[str]):
    body=(ROOT/'CLAUDE.md').read_text(encoding='utf-8').strip()
    managed=BEGIN+'\n'+body+'\n'+END
    old=target.read_text(encoding='utf-8') if target.is_file() else ''
    if BEGIN in old or END in old:
        if old.count(BEGIN)!=1 or old.count(END)!=1 or old.index(BEGIN)>old.index(END):
            events.append(f'CONFLICTO marcadores CLAUDE.md no equilibrados: {target}');return
        left, rest=old.split(BEGIN,1); _,right=rest.split(END,1)
        new=left+managed+right
        if old==new: events.append(f'IGUAL {target}');return
        if not force: events.append(f'CONFLICTO bloque CLAUDE.md: --force actualiza con respaldo');return
    else:
        new=old.rstrip()+'\n\n'+managed+'\n' if old.strip() else managed+'\n'
    backup(target,dry_run,events)
    events.append(f'ACTUALIZAR CLAUDE.md preservando resto: {target}')
    if not dry_run: target.write_text(new,encoding='utf-8')


def install(project_root:Path,*,force=False,dry_run=False,init_git=False,no_context7=False,no_settings=False,no_claude_md=False):
    project_root=Path(project_root).expanduser().resolve()
    if not project_root.is_dir(): raise ValueError(f'No existe directorio: {project_root}')
    events=[]
    for source_dir in [ROOT/'.claude/agents',ROOT/'.claude/skills']:
        for src in sorted(source_dir.rglob('*')):
            if src.is_file() and '__pycache__' not in src.parts and src.suffix !='.pyc':
                copy_file(src,project_root/src.relative_to(ROOT),force,dry_run,events)
    # Migración acotada: no conservamos la antigua skill Caveman si era original.
    migrate_legacy_concise(project_root,dry_run,events)
    for tool in ('git_init.py', 'validate.py', 'context_profile.py', 'audit_integrity.py'):
        copy_file(ROOT/'scripts'/tool, project_root/'scripts'/tool,force,dry_run,events)
    if not no_settings:
        json_merge(project_root/'.claude/settings.json',PROJECT_CONFIG,force,dry_run,events,'settings Claude Code')
    if not no_context7:
        json_merge(project_root/'.mcp.json',{'mcpServers':{'context7':MCP_CONTEXT7}},False,dry_run,events,'Context7 HTTP')
    if not no_claude_md:
        merge_claude_md(project_root/'CLAUDE.md',force,dry_run,events)
    if init_git:
        from importlib.util import spec_from_file_location, module_from_spec
        module_spec=spec_from_file_location('_agent_teams_git_init',ROOT/'scripts/git_init.py')
        git_module=module_from_spec(module_spec)
        module_spec.loader.exec_module(git_module)
        ensure_git,GitInitError=git_module.ensure_git,git_module.GitInitError
        try:
            message,_=ensure_git(project_root,dry_run=dry_run)
            events.append('GIT: '+message)
        except GitInitError as exc: events.append('BLOQUEADO Git: '+str(exc))
    # Inventario local: el catálogo generado en el paquete fuente no puede
    # representar skills ya presentes en el proyecto destino. Actualízalo
    # desde el destino sin alterar las normas aprobadas ni memorias Engram.
    builder=project_root/'.claude/skills/skill-creator/scripts/build_registry.py'
    catalog=project_root/'.claude/skills/_shared/skill-catalog.md'
    if dry_run:
        events.append('CATÁLOGO: se verificará y regenerará si hace falta (sin cambios durante --dry-run)')
    elif builder.is_file():
        checked=subprocess.run([sys.executable, str(builder), '--project-root', str(project_root), '--check'],
                               capture_output=True,text=True,check=False)
        if checked.returncode == 1:
            backup(catalog,False,events)
            updated=subprocess.run([sys.executable, str(builder), '--project-root', str(project_root)],
                                   capture_output=True,text=True,check=False)
            events.append('CATÁLOGO: '+('actualizado desde las skills reales' if updated.returncode==0 else 'BLOQUEADO: '+updated.stdout+' '+updated.stderr))
        elif checked.returncode == 0:
            events.append('CATÁLOGO: actualizado, sin cambios')
        else:
            events.append('CATÁLOGO BLOQUEADO: '+checked.stdout+' '+checked.stderr)
    else:
        events.append('CATÁLOGO BLOQUEADO: generador ausente')
    events.append('I Have ADHD: activo por defecto en cada sesion a traves del CLAUDE.md del proyecto y el import local (sin hooks ni plugins).') if not no_claude_md else events.append('ADVERTENCIA: --no-claude-md desactiva la activacion automatica de I Have ADHD; instalar el CLAUDE.md si quieres always-on.')
    events.append('Engram: ejecutar voluntariamente `engram setup claude-code`; no se han modificado ajustes globales.')
    events.append('Regenerar catálogo si añades skills: python .claude/skills/skill-creator/scripts/build_registry.py --project-root .')
    return events


def main():
    ap=argparse.ArgumentParser(description='Instala Agent Teams Lean para Claude Code sin sobrescribir personalizaciones')
    ap.add_argument('--project-root',type=Path,required=True)
    ap.add_argument('--dry-run',action='store_true')
    ap.add_argument('--force',action='store_true',help='Reemplazar archivos y claves de modelo gestionados, con respaldo')
    ap.add_argument('--init-git',action='store_true',help='Git init seguro, opcional, sin commits')
    ap.add_argument('--no-context7',action='store_true')
    ap.add_argument('--no-settings',action='store_true')
    ap.add_argument('--no-claude-md',action='store_true')
    args=ap.parse_args()
    try:
        print('\n'.join(install(args.project_root,force=args.force,dry_run=args.dry_run,init_git=args.init_git,no_context7=args.no_context7,no_settings=args.no_settings,no_claude_md=args.no_claude_md)))
    except (OSError,ValueError) as exc:
        ap.exit(2,f'ERROR: {exc}\n')

if __name__=='__main__':main()
