# Migración Claude Code Agent Teams v17 → v18: Caveman → I Have ADHD

Fecha: 2026-11-03. Origen del proyecto: `claude-agent-teams-integrity-v17.zip` proporcionado por el usuario. Origen de la skill: `i-have-adhd-main.zip` proporcionado por el usuario (plugin original 0.4.1, licencia MIT).

## Qué cambia

- Se retira la adaptación de Caveman (`.claude/skills/concise-output/SKILL.md`) del paquete fuente.
- Se incorpora **la skill original de I Have ADHD**, con sus diez reglas intactas, en `.claude/skills/i-have-adhd/SKILL.md`. Se añade `user-invocable: true` y una única referencia local al contrato de compatibilidad; `disable-model-invocation: true` sigue evitando la activación autónoma.
- La invocación pasa a ser `/i-have-adhd` (no `$i-have-adhd`); el modo busca persistir durante la conversación hasta `normal mode` o `stop adhd mode`, sujeto a preservación del contexto de Claude.
- Se actualizan el orquestador, `CLAUDE.md`, `handoff.md`, catálogo, instalador, validador, pruebas y README. El estilo no se inyecta en los especialistas, no comprime logs y no sustituye evidencia de tests ni Quality Gate.
- **Ponytail continúa intacto**: `changed-code-tests`, `minimal-complete-change.md`, las referencias bajo demanda en los cuatro roles y los cinco estándares aprobados.
- No se cambian los 10 especialistas, modelos/effort, `.claude/settings.json`, `.mcp.json`, Engram, Context7, Playwright, calidad ni permisos. No se instalan hooks ni el plugin de terceros global.

## Instalar o actualizar desde PowerShell

Desde la carpeta extraída de **este ZIP v18**:

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto" --dry-run
py -3 scripts/install.py --project-root "C:\ruta\a\mi-proyecto" --force
```

El modo sin `--force` conserva archivos personalizados preexistentes; para una migración coherente desde v17 se recomienda revisar primero el `--dry-run` y usar luego `--force` si procede. `--force` reemplaza archivos gestionados **con respaldo**, por lo que debes revisar los conflictos si personalizaste el coordinador o `CLAUDE.md`. Las claves no gestionadas y los MCP preexistentes se conservan.

### Retirada segura del componente anterior

- Si `concise-output/SKILL.md` coincide byte a byte con la versión oficial del **ZIP Claude v17**, el instalador crea una copia `.bak.<timestamp>` y retira el archivo activo automáticamente, incluso sin `--force`.
- Si el archivo fue personalizado, **no lo borra ni siquiera con `--force`**: emite `CONFLICTO`, mantiene el contenido y el validador informa que la migración está pendiente. Haz una revisión manual antes de quitarlo.
- Si no existe esa skill, no toca nada. Los backups, plugins globales y otras skills no se eliminan.
- Después del cambio, el catálogo se reconstruye a partir de las skills efectivamente activas. Si conservaste una variante personalizada de `concise-output`, continuará registrada hasta que decidas retirarla.

## Uso

```text
/i-have-adhd Implementa esta funcionalidad, prueba el resultado y dime el siguiente paso.
normal mode
```

Invoca `/i-have-adhd` en una **nueva sesión** tras instalar y reiniciar Claude Code si no aparece en el autocompletado. Se activa a petición de usuario: no se precarga como skill de ningún especialista. Es un modo de salida de la conversación, no una reducción garantizada del consumo de tokens.

Si compactar el contexto hace que se pierda el modo, vuelve a invocarlo. Si necesitas estado persistente independientemente del contexto, sería otra implementación (por ejemplo, hook explícito), **no forma parte de este paquete**.

## Validación técnica

Ejecutar en el directorio del ZIP fuente:

```powershell
py -3 scripts/validate.py --project-root .
py -3 scripts/audit_integrity.py --project-root . --source
py -3 .claude/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 -m unittest discover -s tests -q
```

La validación cubre estructura, instalador y migración con fixtures. **No** demuestra comportamiento conversacional real en una sesión Claude Code, eficacia sobre lectura, consumo de tokens o continuidad tras compaction. Compruébalo con un proyecto de prueba y el comando `/i-have-adhd` en Claude.

## Licencias y referencias

- Skill upstream: https://github.com/ayghri/i-have-adhd (MIT, copia de licencia incluida)
- Sintaxis Claude Code: https://code.claude.com/docs/en/skills
- Ponytail: https://github.com/DietrichGebert/ponytail
- La documentación `MIGRACION_CLAUDE_V17.md` y `VALIDACION_INTEGRACION_V17.md` permanece únicamente para reproducir el historial de la **versión anterior**, no como guía de configuración vigente.
