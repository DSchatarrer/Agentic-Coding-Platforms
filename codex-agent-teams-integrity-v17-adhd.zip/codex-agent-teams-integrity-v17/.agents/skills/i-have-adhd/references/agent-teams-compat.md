# Compatibilidad — I Have ADHD + Agent Teams Lean

**Ámbito:** solo formato de respuesta orientado a la persona usuaria, cuando se invoque `$i-have-adhd` de forma explícita. No cambia el enrutamiento, roles, modelos, herramientas, trabajo técnico, pruebas ni aceptación. No presupone que la persona usuaria tenga TDAH: el nombre identifica la skill de origen.

## Activación y persistencia

- `$i-have-adhd <petición>` activa el estilo de salida. Sigue para los turnos siguientes de la **misma conversación** hasta `stop adhd mode` o `normal mode` (también se admite «desactiva el modo ADHD»). Este comportamiento depende de que el agente mantenga las instrucciones en contexto; no es un interruptor persistido fuera de la sesión ni un hook instalado.
- Sin activación previa, responder normalmente; mencionar ADHD, su nombre o la habilidad en un texto **no** basta para activarla. No activar una skill por coincidencia semántica.
- La salida pública del coordinador puede usar el estilo activo. Las instrucciones a especialistas y sus handoffs siguen el contrato de su rol; no propagues este estilo a subagentes por defecto.

## Precedencia y garantías

1. La petición explícita de explicación detallada, formato concreto o respuesta completa prevalece sobre las pautas breves. Las reglas sobre listas de cinco elementos limitan la **presentación**, nunca la búsqueda ni la cobertura exigida.
2. Conservar **sin modificación** código, JSON, SQL, diffs, comandos, rutas, estructuras solicitadas, parámetros, salidas de herramientas y mensajes de error necesarios. No reinterpretar ni compactar payloads contractuales.
3. Preservar `status`, `quality_gate`, `success|partial|blocked`, `PASS|FAIL|BLOCKED|not_run|not_applicable`, pruebas ejecutadas, exit codes, rutas, limitaciones y evidencias trazables. La salida pública orientada a acciones **no puede** transformar `not_run` en `PASS`.
4. No truncar salidas o logs para ocultar fallos. Se pueden mostrar extractos identificados si la fuente original está disponible, sin destruirla. Seguridad, permisos, datos sensibles, calidad y accesibilidad prevalecen.
5. Ponytail sigue siendo guía de **menor cambio completo** independiente, no una regla de formato. No crear agente nuevo, estándar aprobado adicional ni hooks de sesión.

Para el handoff técnico se aplica [handoff.md](../../_shared/handoff.md), independientemente del estilo de respuesta pública.
