# Changelog

## v17 — I Have ADHD sustituye la adaptación Caveman

- La skill `concise-output` deja de distribuirse; nueva skill local `i-have-adhd` basada en la fuente original MIT del ZIP proporcionado, con integración acotada a salida pública.
- Invocación opt-in `$i-have-adhd`, modo por conversación hasta `stop adhd mode` / `normal mode`; sin hooks, plugins externos ni cambio de modelos, MCP, roles o estándares.
- Compatibilidad explícita con handoff y Quality Gate; mantiene intacta la integración de Ponytail.
- El instalador migra instalaciones v16: solo retira y respalda `concise-output` si coincide exactamente con los dos archivos originales. Los cambios propios no se borran.
- Pruebas específicas de migración, idempotencia, validación y regresión; ver [informe v17](INTEGRACION_ADHD_V17.md).

## v16 — Ponytail y Caveman nativos y reversibles

- Adaptación propia de «menor cambio completo» de Ponytail dentro del estándar aprobado `changed-code-tests`; no añade un sexto estándar.
- Ajustados procedimientos `create`, `debug`, `refactor` y `review`, con guía de revisión verificable y una referencia compartida de lectura progresiva.
- Refinado el contrato de handoff: formato conciso sin perder estados, evidencias, exit codes, rutas ni JSON contractual.
- Nueva skill **opt-in** `concise-output`, inspirada en Caveman, con `allow_implicit_invocation: false`; sin agente ni hooks de sesión.
- Conservados modelos, MCP, diez roles, runner y política del Quality Gate; sin auto-routing, proxy ni instalación de dependencias externas.
- Nuevas pruebas de integración, instalación, límites y no regresión. Más detalles en [informe v16](INTEGRACION_CAVEMAN_PONYTAIL_V16.md).


## v14 — Memory Hygiene y Git opcional

- Engram curado: filtrado previo a escritura, upserts por `topic_key`, recuperación progresiva y mantenimiento solo bajo demanda.
- Política explícita contra logs, duplicados entre agentes, datos sensibles, borrados y limpieza automática.
- Nuevo `scripts/git_init.py` que ejecuta `git init` solo si no existe Git en el proyecto ni en un ancestro; sin commits ni remotos.
- Opción `--init-git` del instalador, opt-in, respetando `--dry-run`.
- Tests de regresión para memoria, Git propio/ancestro/ausente, idempotencia y modo simulación.
- Se mantienen todos los agentes, modelos, MCP, estándares y selección de referencias de v13.

# Historial

## v13 — Agent Teams Lean
- `AGENTS.md` reducido a contrato de coordinación (menos de 300 palabras).
- Separados estándares aprobados (`project-skill-registry.md`) y catálogo de descubrimiento (`skill-catalog.md`); el generador no altera estándares.
- Diez skills y TOMLs compactados sin perder contratos de rol ni modelos.
- `plan` decide directamente la acción TODO sin leer índice intermedio; conserva referencias originales.
- Handoff mínimo por defecto; estructurado solo si importa la trazabilidad.
- Contrato único de Engram (`engram.md`); eliminadas dos referencias duplicadas del paquete nuevo.
- Validaciones de contexto, presupuesto, rutas, catálogo y tests negativos; informe [eficiencia](EFICIENCIA_CONTEXTO.md).

## v12 y anteriores
Se mantiene la funcionalidad anterior de registry, Quality Gate, Engram, Context7 y Playwright. Los informes históricos pueden recuperarse de los ZIP anteriores; no son instrucciones operativas de v13.

## v15 — Auditoría de integridad y cohesión (Codex)
- Instalar `validate.py`, `audit_integrity.py`, `context_profile.py` y `git_init.py`, todos utilizables desde el destino.
- Auditoría ejecutable de enlaces Markdown, comandos locales, agentes y config TOML, con pruebas negativas.
- Actualización automática del catálogo generado sobre las skills reales del proyecto de destino; estándares aprobados y catálogos ajenos se preservan.
- Configuración Codex consolidada en una escritura y un respaldo como máximo por instalación; no se duplican backups por MCP.
- Validación explícita para configuraciones globales optativas: `--allow-inherited-mcp` y `--allow-inherited-model`.
- README y contrato de coherencia distinguen claramente paquete fuente, proyecto instalado y verificación en un Codex real.
