"""Validación Ponytail + I Have ADHD v17 sin interferir con los diez roles."""
from pathlib import Path
import importlib.util
import hashlib
import json
import re
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
SKILLS = ROOT / '.agents/skills'
REGISTRY = SKILLS / '_shared/project-skill-registry.md'


def load(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


installer = load(ROOT / 'scripts/install.py', 'v16_installer_tests')
validator = load(ROOT / 'scripts/validate.py', 'v16_validator_tests')
registry = load(SKILLS / 'skill-creator/scripts/build_registry.py', 'v16_catalog_tests')


class PonytailADHDV17Tests(unittest.TestCase):
    def test_five_approved_standards_not_six(self):
        text = REGISTRY.read_text(encoding='utf-8')
        approved = re.findall(r'^### ([a-z0-9]+(?:-[a-z0-9]+)*)$', text, re.M)
        self.assertEqual(len(approved), 5)
        self.assertEqual(approved.count('changed-code-tests'), 1)
        self.assertNotIn('### ponytail', text)
        self.assertNotIn('### caveman', text)
        self.assertNotIn('### i-have-adhd', text)
        self.assertIn('[minimal-complete-change.md](minimal-complete-change.md)', text)
        self.assertIn('menor cambio **completo**', text)
        self.assertIn('pruebas', text)

    def test_reference_loaded_only_for_design_decisions(self):
        guide = SKILLS / '_shared/minimal-complete-change.md'
        self.assertTrue(guide.is_file())
        body = guide.read_text(encoding='utf-8')
        self.assertIn('No la leas para un typo', body)
        self.assertIn('quality-gate', body)
        for role in ('create', 'debug', 'refactor', 'review'):
            content = (SKILLS / role / 'SKILL.md').read_text(encoding='utf-8')
            self.assertIn('(../_shared/minimal-complete-change.md)', content, role)
            self.assertIn('menor cambio', content.lower(), role)
        for role in ('plan', 'quality-gate', 'docs', 'research', 'test'):
            content = (SKILLS / role / 'SKILL.md').read_text(encoding='utf-8')
            self.assertNotIn('(../_shared/minimal-complete-change.md)', content, role)

    def test_review_keeps_read_only_boundary(self):
        content = (SKILLS / 'review/SKILL.md').read_text(encoding='utf-8')
        checklist = (SKILLS / 'review/references/reviewing.md').read_text(encoding='utf-8')
        self.assertIn('Solo lectura', content)
        self.assertIn('El rol no modifica archivos', checklist)
        self.assertIn('Seguridad y límites de confianza', checklist)
        self.assertIn('Complejidad evitable', checklist)
        self.assertIn('prueba no ejecutada', checklist)

    def test_adhd_skill_explicit_only_and_no_new_agent(self):
        skill = SKILLS / 'i-have-adhd/SKILL.md'
        metadata = skill.parent / 'agents/openai.yaml'
        self.assertTrue(skill.is_file())
        self.assertRegex(skill.read_text(encoding='utf-8'), r'(?m)^name: i-have-adhd$')
        self.assertIn('disable-model-invocation: true', skill.read_text(encoding='utf-8'))
        self.assertIn('allow_implicit_invocation: false', metadata.read_text(encoding='utf-8'))
        self.assertTrue((skill.parent/'LICENSE').exists())
        self.assertTrue((skill.parent/'references/agent-teams-compat.md').exists())
        self.assertFalse((SKILLS/'concise-output').exists())
        self.assertFalse((ROOT/'.codex/agents/i-have-adhd.toml').exists())
        self.assertEqual(len(list((ROOT/'.codex/agents').glob('*.toml'))),10)

    def test_evidence_takes_precedence_over_adhd_format(self):
        handoff = (SKILLS / '_shared/handoff.md').read_text(encoding='utf-8')
        compat = (SKILLS / 'i-have-adhd/references/agent-teams-compat.md').read_text(encoding='utf-8')
        skill = (SKILLS / 'i-have-adhd/SKILL.md').read_text(encoding='utf-8')
        for term in ('status', 'quality_gate', 'not_run', 'códigos de salida'):
            self.assertIn(term, handoff)
        for term in ('JSON', 'seguridad', 'truncar', 'PASS', 'FAIL'):
            self.assertIn(term.lower(), compat.lower())
        self.assertIn('agent-teams-compat.md', skill)
        self.assertIn('normal mode', skill)
        self.assertIn('normal mode', (ROOT/'AGENTS.md').read_text(encoding='utf-8'))

    def test_no_routing_or_lifecycle_hooks_added(self):
        self.assertFalse((ROOT / 'hooks').exists())
        self.assertFalse((ROOT / '.codex/hooks').exists())
        self.assertFalse((ROOT / 'package.json').exists())
        self.assertFalse((ROOT / '.caveman.json').exists())
        self.assertFalse((ROOT / '.ponytail.json').exists())
        self.assertEqual(validator.validate(ROOT), [])

    def test_catalog_discovers_skill_without_approving_it(self):
        self.assertEqual(registry.run(ROOT, check=True)[0], 0)
        self.assertIn('`i-have-adhd`', (SKILLS / '_shared/skill-catalog.md').read_text(encoding='utf-8'))
        self.assertNotIn('`concise-output`', (SKILLS / '_shared/skill-catalog.md').read_text(encoding='utf-8'))
        self.assertNotIn('### i-have-adhd', REGISTRY.read_text(encoding='utf-8'))

    def test_fresh_install_keeps_role_count_and_optin_metadata(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest)
            self.assertEqual(validator.validate(dest), [])
            self.assertEqual(len(list((dest / '.codex/agents').glob('*.toml'))), 10)
            self.assertTrue((dest / '.agents/skills/i-have-adhd/agents/openai.yaml').is_file())
            self.assertFalse((dest / '.agents/skills/concise-output').exists())
            self.assertTrue((dest / '.agents/skills/_shared/minimal-complete-change.md').is_file())
            self.assertEqual(registry.run(dest, check=True)[0], 0)

    def test_update_preserves_customization_without_force(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest)
            guide = dest / '.agents/skills/_shared/minimal-complete-change.md'
            guide.write_text('PERSONALIZADA\n', encoding='utf-8')
            logs = installer.install(dest)
            self.assertTrue(any('CONFLICTO' in item and 'minimal-complete-change.md' in item for item in logs))
            self.assertEqual(guide.read_text(encoding='utf-8'), 'PERSONALIZADA\n')
            installer.install(dest, force=True)
            self.assertEqual(guide.read_bytes(), (SKILLS / '_shared/minimal-complete-change.md').read_bytes())
            self.assertTrue(list(guide.parent.glob('minimal-complete-change.md.bak.*')))
            self.assertEqual(validator.validate(dest), [])

    @staticmethod
    def _write_legacy(dest: Path, *, modified=False):
        fixture = json.loads((ROOT/'tests/fixtures/concise-output-v16.json').read_text(encoding='utf-8'))
        legacy = dest/'.agents/skills/concise-output'
        for name, value in fixture.items():
            file = legacy/name
            file.parent.mkdir(parents=True, exist_ok=True)
            if modified and name == 'SKILL.md':
                value += '\n# Personalización local\n'
            file.write_text(value, encoding='utf-8')
            if not modified:
                assert hashlib.sha256(file.read_bytes()).hexdigest() == installer.LEGACY_CONCISE_V16[name]
        return legacy

    def test_v16_migration_removes_only_legacy_known_files_and_backs_up(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest)
            legacy = self._write_legacy(dest)
            output = installer.install(dest)
            self.assertTrue(any('RETIRAR skill legada' in msg for msg in output))
            self.assertFalse(legacy.exists())
            self.assertEqual(validator.validate(dest), [])
            backs = list((dest/'.agent-teams-backups').glob('concise-output-v16-*/SKILL.md'))
            self.assertEqual(len(backs), 1)
            self.assertEqual(hashlib.sha256(backs[0].read_bytes()).hexdigest(), installer.LEGACY_CONCISE_V16['SKILL.md'])
            self.assertEqual(registry.run(dest, check=True)[0], 0)
            self.assertFalse(any('RETIRAR skill legada' in x for x in installer.install(dest)))

    def test_v16_custom_skill_never_removed_even_force(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest)
            legacy = self._write_legacy(dest, modified=True)
            output = installer.install(dest, force=True)
            self.assertTrue(any('CONFLICTO skill legada personalizada' in x for x in output))
            self.assertTrue(legacy.exists())
            self.assertIn('Coexiste la skill legada', '\n'.join(validator.validate(dest)))
            self.assertIn('Personalización local', (legacy/'SKILL.md').read_text(encoding='utf-8'))

    def test_dry_run_of_migration_preserves_legacy(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest)
            legacy = self._write_legacy(dest)
            out = installer.install(dest, dry_run=True)
            self.assertTrue(any('SIMULACIÓN: RETIRAR' in x for x in out))
            self.assertTrue(legacy.exists())
            self.assertFalse((dest/'.agent-teams-backups').exists())

    def test_dry_run_does_not_create_optin_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            installer.install(dest, dry_run=True)
            self.assertEqual(list(dest.iterdir()), [])


if __name__ == '__main__':
    unittest.main()
