# Integración v17 — Reemplazo de Caveman por I Have ADHD

Fecha: 03-11-2026. Base: paquete v16 del proyecto y ZIP `i-have-adhd-main` entregados.

## Decisión de arquitectura

En v16 Caveman **no** se instaló como plugin; se representaba mediante la skill local `concise-output`. Por eso se sustituye **esa skill** por `.agents/skills/i-have-adhd/` sin superponer el plugin completo ni añadir un agente.

| Responsabilidad | Fuente de verdad | Activación |
|---|---|---|
| Coordinación y delegación | [AGENTS.md](AGENTS.md) | Siempre, sin cargar skill de estilo |
| Formato orientado a acciones | [i-have-adhd/SKILL.md](.agents/skills/i-have-adhd/SKILL.md) | Solo `$i-have-adhd` |
| Salvaguardas del proyecto | [agent-teams-compat.md](.agents/skills/i-have-adhd/references/agent-teams-compat.md) | Solo junto con la skill |
| Handoff técnico y Quality Gate | [handoff.md](.agents/skills/_shared/handoff.md) | Sin cambios ni supresión de evidencia |
| Ponytail | [minimal-complete-change.md](.agents/skills/_shared/minimal-complete-change.md) | Como antes, bajo demanda en decisiones de diseño |

## Qué integra

Se conserva el texto de las **diez reglas** originales y el metadato `disable-model-invocation: true` de la skill upstream (con una sección final que enlaza la compatibilidad local), su archivo `agents/openai.yaml` intacto y su licencia MIT en `.agents/skills/i-have-adhd/LICENSE`.

El modo cambia el **orden y presentación** de las respuestas: acción concreta primero, pasos pequeños, estado visible, errores directos y sin introducciones vacías. No se reduce la profundidad interna del análisis, ni se elimina código/JSON, ni se altera el status, evidencias, comandos o rutas. Las salidas técnicas entre agentes mantienen su handoff propio. El límite de cinco elementos no es un límite a resultados solicitados ni búsquedas.

### Uso en Codex

```text
$i-have-adhd Corrige este fallo y verifica la solución.
```

En turnos posteriores del mismo hilo, el modo **se solicita** que continúe hasta indicar:

```text
normal mode
```

También admite `stop adhd mode` o `desactiva el modo ADHD` según la política de integración. Esto es una instrucción de conversación, **no un switch global garantizado** por Codex: ante compactación o nueva sesión puede requerir invocación nueva. No se habilita siempre activo para evitar precarga y activaciones inesperadas. La skill no se invoca implícitamente por contexto o parecido semántico.

## Migración conservadora v16 -> v17

```powershell
py -3 scripts/install.py --project-root "C:\ruta\a\proyecto" --dry-run
py -3 scripts/install.py --project-root "C:\ruta\a\proyecto" --force
```

- Los nuevos archivos se copian con los mecanismos habituales del instalador; `--force` respalda los archivos de destino sobrescritos. Para un `AGENTS.md` gestionado por v16, `--force` actualiza solo el bloque entre marcadores.
- Se retira `concise-output` **solo si** contiene exactamente los dos archivos originales de v16 con sus hashes SHA-256 conocidos. Se respaldan en `.agent-teams-backups/concise-output-v16-<fecha>/` antes de eliminarlos de `.agents/skills/`. `--dry-run` no toca el destino.
- Si se personalizó la skill antigua o tiene otros archivos, el instalador **no la borra ni con `--force`**: informa de `CONFLICTO`; el validador señala la convivencia para resolver manualmente, sin perder cambios.
- Si tenías el plugin Caveman **instalado externamente** en tu equipo, el ZIP no puede desinstalarlo: retíralo desde su gestor, si procede.
- El cambio no toca `.codex/config.toml`, modelos asignados, diez perfiles TOML, Engram, Context7, Playwright, Quality Gate ni el registro de cinco estándares aprobados.

## Validación

```powershell
py -3 scripts/validate.py --project-root .
py -3 scripts/audit_integrity.py --project-root . --source
py -3 .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
py -3 -m unittest discover -s tests -q
```

Estas pruebas verifican archivos, instalación, regresiones y consistencia. No equivalen a una sesión real con Codex ni garantizan fidelidad de estilo durante una compactación. [Historial v16](INTEGRACION_CAVEMAN_PONYTAIL_V16.md) y [validación histórica v16](VALIDACION_V16.md) se conservan como documentos anteriores, no como instrucciones vigentes.

## Procedencia y licencia

Origen: [ayghri/i-have-adhd](https://github.com/ayghri/i-have-adhd) (ZIP proporcionado). MIT, copyright 2026 Ayoub Ghriss. Se distribuye la licencia upstream y se declara la sección local de compatibilidad. Ponytail es una adaptación conceptual preexistente; no se copia el plugin upstream. No se instala JavaScript, hooks, `.claude-plugin`, `.opencode`, extensiones ni manifests de los otros agentes.
