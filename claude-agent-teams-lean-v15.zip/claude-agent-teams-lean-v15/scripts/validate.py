#!/usr/bin/env python3
"""Validación estructural para Claude Code, stdlib only."""
from __future__ import annotations
import argparse,json,re,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ROLES=('research','plan','create','debug','test','review','refactor','docs','skill-creator','quality-gate')
LINK=re.compile(r'\[[^\]]+\]\(([^)]+\.md)(?:#[^)]*)?\)')
FIELD=re.compile(r'^([A-Za-z][A-Za-z-]*):\s*(.*)$')
BROWSER={'create','debug','test','review','quality-gate'}
READONLY={'research','review','quality-gate'}

def frontmatter(text):
    if not text.startswith('---\n'):raise ValueError('frontmatter ausente')
    mark=text.find('\n---\n',4)
    if mark<0: raise ValueError('frontmatter sin cierre')
    front=text[4:mark].splitlines()
    meta={}
    for line in front:
        if line.startswith(' ') or not line.strip():continue
        m=FIELD.match(line)
        if not m: raise ValueError('campo YAML inválido: '+line)
        meta[m[1]]=m[2]
    return meta,front

def validate(root:Path):
    root=Path(root).resolve();errors=[]
    skills=root/'.claude/skills';agents=root/'.claude/agents'
    for name in ('CLAUDE.md','.claude/settings.json','.mcp.json','scripts/git_init.py',
                 '.claude/skills/_shared/project-skill-registry.md','.claude/skills/_shared/skill-catalog.md',
                 '.claude/skills/_shared/engram.md', '.claude/skills/quality-gate/scripts/run_gates.py'):
        if not (root/name).is_file():errors.append('Falta '+name)
    for role in ('orchestrator',*ROLES):
        p=agents/f'{role}.md'
        if not p.is_file(): errors.append(f'Falta agente {role}');continue
        try: meta,rows=frontmatter(p.read_text(encoding='utf-8'))
        except (OSError,ValueError) as exc: errors.append(f'Frontmatter {role}: {exc}');continue
        if meta.get('name')!=role:errors.append(f'Nombre agente incorrecto: {role}')
        if not meta.get('description'):errors.append(f'Descripción ausente: {role}')
        expected='claude-opus-5-5' if role in ('orchestrator','plan') else 'claude-haiku-5-5'
        effort='medium' if role in ('orchestrator','plan') else 'low'
        if meta.get('model')!=expected or meta.get('effort')!=effort:errors.append(f'Modelo/esfuerzo: {role}')
        if role=='orchestrator':
            if 'tools: Agent(' not in p.read_text(encoding='utf-8'): errors.append('Orquestador no delega con allowlist')
        else:
            if 'Agent' not in meta.get('disallowedTools',''):errors.append(f'{role} puede subdelegar')
            if 'skills:' not in '\n'.join(rows) or f'  - {role}' not in '\n'.join(rows):errors.append(f'{role} no precarga skill')
            if role in BROWSER and 'mcpServers:' not in '\n'.join(rows):errors.append(f'{role} no dispone Playwright MCP bajo demanda')
            if role in READONLY and not all(x in meta.get('disallowedTools','') for x in ('Write','Edit')):errors.append(f'{role} no es solo lectura')
    for role in ROLES:
        p=skills/role/'SKILL.md'
        if not p.is_file():errors.append(f'Skill ausente: {role}');continue
        try:meta,lines=frontmatter(p.read_text(encoding='utf-8'))
        except (OSError,ValueError) as exc:errors.append(f'Skill {role}: {exc}');continue
        if meta.get('name')!=role:errors.append(f'Skill incorrecta: {role}')
        if not meta.get('description'):errors.append(f'Skill sin trigger: {role}')
        if len(p.read_text(encoding='utf-8').splitlines())>500:errors.append(f'Skill demasiado larga: {role}')
        if not LINK.findall(p.read_text(encoding='utf-8')):errors.append(f'Skill sin referencias: {role}')
    for p in skills.rglob('*.md'):
        text=p.read_text(encoding='utf-8')
        for link in LINK.findall(text):
            if link.startswith(('https://','http://')):continue
            if not (p.parent/link).resolve().is_file():errors.append(f'Referencia rota: {p.relative_to(root)} -> {link}')
    sfile=root/'.claude/settings.json'; mfile=root/'.mcp.json'
    if sfile.exists():
        try:
            s=json.loads(sfile.read_text(encoding='utf8'))
            if s.get('agent')!='orchestrator':errors.append('Settings: agente principal incorrecto')
            if s.get('model')!='claude-opus-5-5':errors.append('Settings: modelo principal incorrecto')
            if s.get('autoMemoryEnabled') is not False:errors.append('Settings: memoria paralela activa')
        except Exception as exc:errors.append(f'Settings JSON inválido: {exc}')
    if mfile.exists():
        try:
            m=json.loads(mfile.read_text(encoding='utf8')).get('mcpServers',{})
            if m.get('context7',{}).get('url')!='https://mcp.context7.com/mcp' or m['context7'].get('type')!='http': errors.append('Context7 MCP incorrecto')
            if 'engram' in m:errors.append('Engram duplicado en MCP de proyecto (debe registrarse desde instalación local)')
            if 'playwright' in m:errors.append('Playwright debe estar scoped a agentes')
        except Exception as exc:errors.append(f'MCP JSON inválido: {exc}')
    if (root/'CLAUDE.md').exists():
        instructions=(root/'CLAUDE.md').read_text(encoding='utf8')
        if '<!-- agent-teams-claude:start -->' in instructions and '<!-- agent-teams-claude:end -->' in instructions:
            instructions=instructions.split('<!-- agent-teams-claude:start -->',1)[1].split('<!-- agent-teams-claude:end -->',1)[0]
        if len(instructions.split())>310:
            errors.append('Bloque gestionado CLAUDE.md demasiado largo; objetivo lean')
    if (skills/'_shared'/'SKILL.md').exists():errors.append('_shared no es skill')
    for p in root.rglob('*.toml'):
        if '/.claude/agents/' in p.as_posix():errors.append('Agente TOML legado: '+str(p))
    return errors

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--project-root',type=Path,default=ROOT); a=ap.parse_args()
    errors=validate(a.project_root)
    if errors:
        print('\n'.join('ERROR: '+x for x in errors));return 1
    print('OK: 11 agentes Claude Code (orquestador + 10 especialistas), 10 skills, referencias, modelo/effort, Engram, MCP y calidad')
    return 0
if __name__=='__main__': sys.exit(main())
