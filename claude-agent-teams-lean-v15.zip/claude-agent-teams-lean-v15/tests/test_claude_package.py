"""Regresiones estructurales y semánticas de migración Claude Code."""
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def load(path):
    spec=importlib.util.spec_from_file_location('tested_'+path.stem,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=module
    spec.loader.exec_module(module)
    return module

install=load(ROOT/'scripts/install.py')
validate=load(ROOT/'scripts/validate.py')
registry=load(ROOT/'.claude/skills/skill-creator/scripts/build_registry.py')
scaffold=load(ROOT/'.claude/skills/skill-creator/scripts/scaffold_skill.py')

class ClaudePackage(unittest.TestCase):
    def test_package_valid(self):self.assertEqual([],validate.validate(ROOT))
    def test_agent_role_count(self):self.assertEqual(11,len(list((ROOT/'.claude/agents').glob('*.md'))))
    def test_specialist_skill_count(self):self.assertEqual(10,len(list((ROOT/'.claude/skills').glob('*/SKILL.md'))))
    def test_main_model(self):
        settings=json.loads((ROOT/'.claude/settings.json').read_text())
        self.assertEqual('claude-opus-5-5',settings['model'])
        self.assertEqual('orchestrator',settings['agent'])
        self.assertFalse(settings['autoMemoryEnabled'])
    def test_agents_models_effort_and_skill_preload(self):
        for role in validate.ROLES:
            meta,_=validate.frontmatter((ROOT/f'.claude/agents/{role}.md').read_text())
            self.assertEqual('claude-opus-5-5' if role=='plan' else 'claude-haiku-5-5',meta['model'])
            self.assertEqual('medium' if role=='plan' else 'low',meta['effort'])
            self.assertIn('skills:',(ROOT/f'.claude/agents/{role}.md').read_text())
            self.assertIn('Agent',meta['disallowedTools'])
    def test_models_no_codex(self):
        self.assertFalse((ROOT/'.codex').exists()); self.assertFalse((ROOT/'.agents').exists())
        text='\n'.join(p.read_text(encoding='utf-8') for p in (ROOT/'.claude').rglob('*.md'))
        self.assertNotIn('gpt-6',text)
        self.assertNotIn('engram setup codex',text)
    def test_orchestrator_can_delegate_and_read_engram(self):
        contents=(ROOT/'.claude/agents/orchestrator.md').read_text()
        self.assertIn('Agent(research, plan, create',contents)
        self.assertIn('mcp__engram__*',contents)
        self.assertIn('mcp__context7__*',contents)
    def test_playwright_only_in_5_agents(self):
        for role in validate.ROLES:
            content=(ROOT/f'.claude/agents/{role}.md').read_text()
            self.assertEqual(role in validate.BROWSER,'@playwright/mcp@latest' in content)
        self.assertNotIn('playwright',json.loads((ROOT/'.mcp.json').read_text())['mcpServers'])
    def test_no_duplicate_engram_server(self):
        self.assertNotIn('engram',json.loads((ROOT/'.mcp.json').read_text())['mcpServers'])
    def test_skill_registry_check(self):
        rc,msg=registry.run(ROOT,check=True)
        self.assertEqual(0,rc,msg)
    def test_archive_containing_no_sdd_docs(self):
        for p in (ROOT/'.claude').rglob('*.md'):
            self.assertNotIn('sdd-',p.read_text(encoding='utf8').lower(),str(p))
    def test_real_plan_references(self):
        p=ROOT/'.claude/skills/plan/references'
        for action in ('create','audit','continue','update','replan'):
            self.assertTrue((p/f'todo-{action}.md').is_file())
    def test_accepted_quality_script(self):
        self.assertTrue((ROOT/'.claude/skills/quality-gate/scripts/run_gates.py').exists())
    def test_memory_curated_references(self):
        for file in ('write-policy.md','topic-keys.md','retrieval-policy.md','maintenance.md'):
            self.assertTrue((ROOT/'.claude/skills/_shared/memory'/file).is_file())
    def test_invalid_agent_model_detected(self):
        with tempfile.TemporaryDirectory() as td:
            target=Path(td)
            # one false model in a copy of known-valid package
            import shutil
            shutil.copytree(ROOT/'.claude',target/'.claude')
            shutil.copy2(ROOT/'.mcp.json',target/'.mcp.json');shutil.copy2(ROOT/'CLAUDE.md',target/'CLAUDE.md')
            (target/'scripts').mkdir();shutil.copy2(ROOT/'scripts/git_init.py',target/'scripts/git_init.py')
            p=target/'.claude/agents/plan.md';p.write_text(p.read_text().replace('claude-opus-5-5','claude-haiku-5-5'))
            self.assertTrue(any('Modelo/esfuerzo: plan' in x for x in validate.validate(target)))
    def test_missing_reference_detected(self):
        with tempfile.TemporaryDirectory() as td:
            target=Path(td)
            import shutil
            shutil.copytree(ROOT/'.claude',target/'.claude')
            shutil.copy2(ROOT/'.mcp.json',target/'.mcp.json');shutil.copy2(ROOT/'CLAUDE.md',target/'CLAUDE.md')
            (target/'scripts').mkdir();shutil.copy2(ROOT/'scripts/git_init.py',target/'scripts/git_init.py')
            (target/'.claude/skills/_shared/memory/write-policy.md').unlink()
            self.assertTrue(any('Referencia rota' in x for x in validate.validate(target)))

class Installer(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def test_dry_run_never_writes(self):
        install.install(self.root,dry_run=True)
        self.assertFalse((self.root/'.claude').exists())
        self.assertFalse((self.root/'.mcp.json').exists())
    def test_install_files(self):
        install.install(self.root)
        self.assertTrue((self.root/'.claude/agents/plan.md').is_file())
        self.assertTrue((self.root/'scripts/git_init.py').is_file())
        self.assertTrue((self.root/'CLAUDE.md').is_file())
    def test_preserve_unmanaged_claude_content(self):
        (self.root/'CLAUDE.md').write_text('Mis reglas privadas\n')
        install.install(self.root)
        s=(self.root/'CLAUDE.md').read_text()
        self.assertTrue(s.startswith('Mis reglas privadas'))
        self.assertIn('agent-teams-claude:start',s)
    def test_installer_idempotent(self):
        install.install(self.root); before=(self.root/'CLAUDE.md').read_text()
        install.install(self.root)
        self.assertEqual(before,(self.root/'CLAUDE.md').read_text())
    def test_preserves_custom_mcp(self):
        (self.root/'.mcp.json').write_text(json.dumps({'mcpServers':{'engram':{'type':'stdio','command':'my-engram'},'custom':{'type':'http','url':'https://other.invalid'}}}))
        install.install(self.root)
        result=json.loads((self.root/'.mcp.json').read_text())['mcpServers']
        self.assertEqual('my-engram',result['engram']['command'])
        self.assertIn('custom',result)
        self.assertIn('context7',result)
    def test_preserves_existing_context7(self):
        (self.root/'.mcp.json').write_text(json.dumps({'mcpServers':{'context7':{'type':'http','url':'https://myproxy.test/mcp'}}}))
        install.install(self.root)
        self.assertEqual('https://myproxy.test/mcp',json.loads((self.root/'.mcp.json').read_text())['mcpServers']['context7']['url'])
    def test_settings_unknown_fields_preserved(self):
        (self.root/'.claude').mkdir()
        (self.root/'.claude/settings.json').write_text(json.dumps({'model':'claude-sonnet-5-5','hooks':{'foo':[]}}))
        install.install(self.root)
        settings=json.loads((self.root/'.claude/settings.json').read_text())
        self.assertEqual('claude-sonnet-5-5',settings['model'])
        self.assertEqual({'foo':[]},settings['hooks'])
        self.assertEqual('orchestrator',settings['agent'])
    def test_force_changes_model_and_backup(self):
        (self.root/'.claude').mkdir()
        (self.root/'.claude/settings.json').write_text(json.dumps({'model':'custom'}))
        install.install(self.root,force=True)
        self.assertEqual('claude-opus-5-5',json.loads((self.root/'.claude/settings.json').read_text())['model'])
        self.assertTrue(list((self.root/'.claude').glob('settings.json.bak.*')))
    def test_install_avoids_existing_agent_when_no_force(self):
        p=self.root/'.claude/agents/create.md';p.parent.mkdir(parents=True)
        p.write_text('CUSTOM')
        install.install(self.root)
        self.assertEqual('CUSTOM',p.read_text())
    def test_existing_agent_replaced_with_backup_when_force(self):
        p=self.root/'.claude/agents/create.md';p.parent.mkdir(parents=True)
        p.write_text('CUSTOM')
        install.install(self.root,force=True)
        self.assertIn('skills:',p.read_text());self.assertTrue(list(p.parent.glob('create.md.bak.*')))
    def test_invalid_mcp_no_overwrite(self):
        (self.root/'.mcp.json').write_text('NOT JSON')
        events=install.install(self.root)
        self.assertEqual('NOT JSON',(self.root/'.mcp.json').read_text())
        self.assertTrue(any('BLOQUEADO' in e for e in events))
    def test_git_not_init_without_explicit_flag(self):
        install.install(self.root)
        self.assertFalse((self.root/'.git').exists())
    def test_git_init_when_requested(self):
        if not __import__('shutil').which('git'):self.skipTest('git no disponible')
        install.install(self.root,init_git=True)
        self.assertTrue((self.root/'.git').exists())
    def test_git_init_no_commit(self):
        if not __import__('shutil').which('git'):self.skipTest('git no disponible')
        install.install(self.root,init_git=True)
        cp=subprocess.run(['git','-C',str(self.root),'rev-list','--count','HEAD'],capture_output=True)
        self.assertNotEqual(0,cp.returncode)
    def test_init_existing_parent_repo_safe(self):
        if not __import__('shutil').which('git'):self.skipTest('git no disponible')
        subprocess.run(['git','-C',str(self.root),'init'],check=True,capture_output=True)
        nested=self.root/'child';nested.mkdir()
        install.install(nested,init_git=True)
        self.assertFalse((nested/'.git').exists())

class SkillCreator(unittest.TestCase):
    def test_scaffold_new_agent_and_skill(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            paths=scaffold.create_skill(root,'my-worker','Ejecuta operaciones especiales',with_agent=True)
            self.assertEqual(3,len(paths))
            self.assertTrue((root/'.claude/agents/my-worker.md').is_file())
            self.assertIn('skills:',(root/'.claude/agents/my-worker.md').read_text())
            self.assertTrue((root/'.claude/skills/my-worker/references/guidance.md').is_file())
    def test_scaffold_cannot_overwrite(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            scaffold.create_skill(root,'my-worker','Tarea concreta',with_agent=True)
            with self.assertRaises(FileExistsError):scaffold.create_skill(root,'my-worker','Otro cambio',with_agent=True)
    def test_scaffold_dryrun(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            scaffold.create_skill(root,'my-worker','Tarea concreta',dry_run=True)
            self.assertFalse((root/'.claude').exists())
    def test_scaffold_bad_name(self):
        with tempfile.TemporaryDirectory() as td:
            with self.assertRaises(ValueError):scaffold.create_skill(td,'Invalid Name','Tarea')

if __name__=='__main__':unittest.main()
