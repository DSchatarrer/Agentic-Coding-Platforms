---
name: debug
description: Reproduce y corrige fallos; usa cuando hay un error que investigar.
---
# Depurar

## Procedimiento mínimo
1. Reproduce el error, identifica su causa y corrige el mínimo con prueba de regresión.
2. No cargues referencias salvo activación específica. Ejecuta las herramientas que necesites, no leas sus scripts completos salvo depuración.

## Referencias bajo demanda
- [depuración](references/debugging.md) — fallo difícil o varias hipótesis.
- [Playwright MCP](../_shared/playwright-mcp.md) — bug que exige navegador real.
- [Engram](../_shared/engram.md) — recuperar/guardar decisiones duraderas relevantes.
- [Context7](../_shared/context7.md) — duda externa real de versión/API.
- [Handoff](../_shared/handoff.md) — traspaso complejo o formal.

## Ejemplos de activación
- Sí: una tarea correspondiente a debug.
- No: acciones de otro rol o pasos redundantes.

## Entrega
Estado `success|partial|blocked`; `quality_gate` por separado (`PASS|FAIL|BLOCKED|not_run|not_applicable`). Comunica comandos/resultados reales. Handoff extendido solo si hace falta.
