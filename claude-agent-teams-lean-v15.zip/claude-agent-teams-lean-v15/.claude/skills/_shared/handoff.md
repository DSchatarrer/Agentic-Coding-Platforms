# Handoff escalonado al coordinador

**Simple (por defecto):** `status` (`success|partial|blocked`), resumen, archivos, pruebas ejecutadas (comando + exit code, si hubo) y bloqueos. `quality_gate` distinto del `status`: `PASS|FAIL|BLOCKED|not_run|not_applicable`. No enviar campos vacíos ni JSON extenso si no hace falta.

**Complejo / cierre formal:** añadir evidencias y rutas verificables, riesgos, `skill_resolution` (`injected|none|registry-missing|not_applicable`, con IDs aprobados reales), resultados de Quality Gate e IDs reales de Engram si se consultó/guardó. No confundir `not_run` con `PASS`.

Los especialistas no inventan pruebas ni memorias. Referencias de calidad provienen del runner; decisiones persistentes siguen el [contrato de Engram](engram.md); solo quien verificó un hallazgo lo guarda, y el coordinador no duplica su observación.
