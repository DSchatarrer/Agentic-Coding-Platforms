---
name: review
description: Audita código sin editar; usa para riesgos, seguridad y regresiones.
---
# Revisar

## Procedimiento mínimo
1. Solo lectura: inspecciona cambios, regresiones, seguridad y límites; ordena hallazgos por severidad.
2. No cargues referencias salvo activación específica. Ejecuta las herramientas que necesites, no leas sus scripts completos salvo depuración.

## Referencias bajo demanda
- [revisión](references/reviewing.md) — revisión profunda.
- [verificación arquitectónica](../_shared/architecture/verification.md) — límites/capas comprometidos.
- [Playwright MCP](../_shared/playwright-mcp.md) — flujo web verificable.
- [librerías Python](../_shared/python-libraries.md) — compatibilidad de API.
- [Engram](../_shared/engram.md) — recuperar/guardar decisiones duraderas relevantes.
- [Context7](../_shared/context7.md) — duda externa real de versión/API.
- [Handoff](../_shared/handoff.md) — traspaso complejo o formal.

## Ejemplos de activación
- Sí: una tarea correspondiente a review.
- No: acciones de otro rol o pasos redundantes.

## Entrega
Estado `success|partial|blocked`; `quality_gate` por separado (`PASS|FAIL|BLOCKED|not_run|not_applicable`). Comunica comandos/resultados reales. Handoff extendido solo si hace falta.
