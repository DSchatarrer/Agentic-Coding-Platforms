# Migración v14 Codex → v15 Claude Code

| En v14 | En v15 | Cambio técnico |
|---|---|---|
| `AGENTS.md` | `CLAUDE.md` + `.claude/agents/orchestrator.md` | Contrato de proyecto separado del prompt del agente principal |
| `.codex/config.toml` | `.claude/settings.json` | `agent`, `model`, `effortLevel`, `autoMemoryEnabled` nativos |
| `.codex/agents/*.toml` | `.claude/agents/*.md` | Subagentes con frontmatter YAML real |
| `.agents/skills/*` | `.claude/skills/*` | Descubrimiento oficial de skills Claude Code |
| `developer_instructions` para leer SKILL.md | `skills: [<rol>]` | Claude precarga skill exactamente una vez |
| GPT Astra `medium` | Claude Opus 5.5 `medium` | Coordinador y planificador |
| GPT Sol `low` | Claude Haiku 5.5 `low` | Nueve roles especializados (modificables a Sonnet) |
| Context7 `[mcp_servers.context7]` | `.mcp.json` HTTP | Esquema MCP nativo de Claude |
| Playwright MCP global | `mcpServers` solo en 5 agentes | Servidor inline, menor contexto del coordinador |
| `engram setup codex` | `engram setup claude-code` | MCP local y hooks/plugin oficiales de Engram |
| `scripts/git_init.py` | mismo archivo | Sin commits; detección de repositorio padre |
| `quality-gates.toml` y runner | mismos contratos y runner | `PASS/FAIL/BLOCKED`, preservados |
| `TODO.md` y referencias modulares | mismos disparadores en `plan` | Sin volver a cargar índices innecesarios |

## Diferencias de comportamiento importantes

1. **No trasladar `.codex` ni `.agents/skills` al proyecto Claude**. El ZIP ya tiene rutas nativas.
2. El `orchestrator` es el agente principal con `claude --agent orchestrator` o `settings.json`. Sus especialistas **no subdelegan**.
3. Los MCP no están en TOML; Context7 está en `.mcp.json`, Playwright en frontmatter de agentes, y Engram se registra **una sola vez** con el método oficial del usuario.
4. La memoria automática propia de Claude Code se desactiva en los settings compartidos para reducir duplicados con Engram. El comportamiento definitivo depende de prioridad de ajustes de organización.
5. Los IDs fijan modelos; si el proveedor los rechaza se debe elegir un modelo disponible conscientemente, no mentir sobre el cambio.
6. El instalador conserva ajustes existentes cuando `--force` no está presente. Comprueba conflictos; no supone que instalar en un proyecto existente garantice la política por defecto.
7. El flujo se organiza por tareas y responsabilidades, sin fases metodológicas obligatorias.

## Verificación local obligatoria en tu equipo

```powershell
claude --version
engram setup claude-code
claude mcp list
py -3 scripts/validate.py --project-root .
py -3 -m unittest discover -s tests -q
claude --agent orchestrator
```

Ya dentro de Claude, prueba un bug simple con `debug`, una auditoría `TODO.md` con `plan`, una verificación `quality-gate` sin política (debe bloquearse) y una prueba de UI con Playwright si tienes navegador instalado. El instalador no toca tu base de datos Engram.
