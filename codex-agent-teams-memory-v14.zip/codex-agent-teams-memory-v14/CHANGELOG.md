# Changelog

## v14 — Memory Hygiene y Git opcional

- Engram curado: filtrado previo a escritura, upserts por `topic_key`, recuperación progresiva y mantenimiento solo bajo demanda.
- Política explícita contra logs, duplicados entre agentes, datos sensibles, borrados y limpieza automática.
- Nuevo `scripts/git_init.py` que ejecuta `git init` solo si no existe Git en el proyecto ni en un ancestro; sin commits ni remotos.
- Opción `--init-git` del instalador, opt-in, respetando `--dry-run`.
- Tests de regresión para memoria, Git propio/ancestro/ausente, idempotencia y modo simulación.
- Se mantienen todos los agentes, modelos, MCP, estándares y selección de referencias de v13.

# Historial

## v13 — Agent Teams Lean
- `AGENTS.md` reducido a contrato de coordinación (menos de 300 palabras).
- Separados estándares aprobados (`project-skill-registry.md`) y catálogo de descubrimiento (`skill-catalog.md`); el generador no altera estándares.
- Diez skills y TOMLs compactados sin perder contratos de rol ni modelos.
- `plan` decide directamente la acción TODO sin leer índice intermedio; conserva referencias originales.
- Handoff mínimo por defecto; estructurado solo si importa la trazabilidad.
- Contrato único de Engram (`engram.md`); eliminadas dos referencias duplicadas del paquete nuevo.
- Validaciones de contexto, presupuesto, rutas, catálogo y tests negativos; informe [eficiencia](EFICIENCIA_CONTEXTO.md).

## v12 y anteriores
Se mantiene la funcionalidad anterior de registry, Quality Gate, Engram, Context7 y Playwright. Los informes históricos pueden recuperarse de los ZIP anteriores; no son instrucciones operativas de v13.
