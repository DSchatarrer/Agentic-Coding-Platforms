# Validación v14 — Memory Hygiene + Git opt-in

Desde la raíz del paquete extraído:

```bash
python .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
python scripts/validate.py --project-root .
python -m unittest discover -s tests -q
python scripts/context_profile.py --project-root .
```

## Comprobaciones realizadas

- **86 tests correctos** (Python 3.13, Git disponible) sobre el paquete fuente.
- Instalación conservadora en directorios temporales y validación de todos los enlaces/referencias.
- Git: ausencia de repo, existencia de repo propio, pertenencia a repo padre, metadata `.git` inválida, dry-run, idempotencia y ausencia de commits o remoto.
- Engram: contrato escrito, carga bajo demanda, anti-duplicación, claves de actualización y ausencia de limpieza automática.
- `AGENTS.md` permanece por debajo del presupuesto Lean de 300 palabras.

**Límites:** no se ha accedido al Engram del usuario ni se han ejecutado agentes con modelos o servidores MCP de su equipo. La higiene de memoria implementada son instrucciones y pruebas documentales, no una purga real de registros. El comando Git sí se ha probado creando repositorios temporales reales.

Consultar [MEMORIA_V14.md](MEMORIA_V14.md) para diseño y [EFICIENCIA_CONTEXTO.md](EFICIENCIA_CONTEXTO.md) para presupuestos estáticos.
