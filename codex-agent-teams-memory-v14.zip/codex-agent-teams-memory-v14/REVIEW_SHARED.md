# Reutilización de ideas de Agent Teams Lite

Adaptamos resolución de skills, memoria compartida, handoffs y referencias bajo demanda, sin heredar fases específicas de otro proceso. Las reglas sobre Engram ya viven en [engram.md](.agents/skills/_shared/engram.md). El inventario informativo está en [skill-catalog.md](.agents/skills/_shared/skill-catalog.md) y los estándares seleccionables en [project-skill-registry.md](.agents/skills/_shared/project-skill-registry.md). No duplicar ni cargar todo en cada tarea.
