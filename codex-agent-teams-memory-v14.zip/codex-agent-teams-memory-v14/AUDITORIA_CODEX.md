# Auditoría de integración v13

- Modelos y roles declarados en `.codex/config.toml` y diez `.codex/agents/*.toml`.
- Emparejamiento agente/skill comprobado en `scripts/validate.py`.
- MCP: Engram local, Context7 HTTP y Playwright MCP stdio, heredados de la sesión cuando están disponibles; no se prueba conectividad real aquí.
- Estándares aprobados, catálogo autogenerado, referencias y links verificados por tests.
- Quality Gates necesitan `quality-gates.toml` real, no se autoaprueban por tener una skill.
- La lectura de referencias bajo demanda es una instrucción comprobada estáticamente; necesita telemetría real para evaluar cumplimiento.


## Anexo v14

El cambio amplía solo el contrato Engram y añade Git opt-in: no cambia modelos, identidades de agentes, configuración MCP ni `SKILL.md` de roles. Se han validado las rutas Markdown directas y la instalación del nuevo script para poder ejecutarlo desde el destino. Detalles de tests en [VALIDACION.md](VALIDACION.md).
