# Evaluaciones de selección, memoria y contexto — v14

Los tests estáticos validan estructura, pero no equivalen a una ejecución real de modelos.

| Caso | Agente | Referencias permitidas, si hacen falta | No debe precargar |
|---|---|---|---|
| Typo simple | `create` | Ninguna | Playwright, arquitectura, plan, Engram |
| Fallo de frontend reproducible | `debug` | Playwright MCP si hay navegador real | guías de Clean, TODO |
| Diseñar API compleja | `plan` | planning, decision-guide, arquitectura elegida | todo-tracker |
| Auditar TODO.md | `plan` | todo-audit y todo-evidence | todo-create, todo-replan |
| Duda API externa | `research` | Context7 si faltan docs locales | Playwright, Engram |

Medir en sesiones reales: tokens de entrada y salida, número de agentes, lecturas de Markdown, herramientas MCP, coste, duración, éxito en pruebas y falsos PASS. Compara v12 y v13 sobre los mismos repositorios y prompts; el número de palabras de `AGENTS.md` es solo un indicador estático.

Pruebas automáticas: `py -3 -m unittest discover -s tests -q`, `py -3 scripts/validate.py`, `py -3 scripts/context_profile.py`.


## Escenarios de memoria y Git (v14)

- Hallazgo trivial: no guardar memoria y no abrir `memory/maintenance.md`.
- Decisión evolutiva ya existente: buscar, recuperar observación íntegra, actualizar misma `topic_key`, no crear otra.
- Contradicción Engram vs. Git: prevalece evidencia actual; proponer revisión, no borrar automáticamente.
- Dos especialistas detectan el mismo dato: solo uno lo persiste y retorna ID al coordinador.
- Proyecto sin `.git` ni padre Git: `git_init.py --dry-run` informa acción y no cambia nada; ejecución crea `.git` sin commit.
- Proyecto con Git propio, worktree o repositorio padre: no ejecutar `git init`.
- Git ausente, `.git` inválido o estado ambiguo: bloquear e informar, nunca inicializar a ciegas.

Estas son pruebas de diseño/ejecución local; comprobar el comportamiento de Engram conectado en Codex requiere la instalación real del usuario.
