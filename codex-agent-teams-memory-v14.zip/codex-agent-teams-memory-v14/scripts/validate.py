#!/usr/bin/env python3
"""Comprueba integridad estructural del paquete ya instalado o extraído."""
import argparse
from pathlib import Path
import re
import sys
import tomllib

REF_RE = re.compile(r'\[[^\]]+\]\(([^)]+\.md)\)')
VALID_NAME = re.compile(r'[a-z0-9]+(?:-[a-z0-9]+)*\Z')

REQUIRED = ('research', 'plan', 'create', 'debug', 'test', 'review', 'refactor', 'docs', 'skill-creator', 'quality-gate')
MODEL_COORDINATOR = ('gpt-6-astra', 'medium')
MODEL_WORKER = ('gpt-6-sol', 'low')


def validate(project_root: Path):
    project_root = Path(project_root).expanduser().resolve()
    errors = []
    agents = project_root / '.codex' / 'agents'
    skills = project_root / '.agents' / 'skills'
    for name in REQUIRED:
        afile = agents / f'{name}.toml'
        sfile = skills / name / 'SKILL.md'
        if not afile.is_file():
            errors.append(f'Falta agente: {afile}')
        else:
            try:
                data = tomllib.loads(afile.read_text(encoding='utf-8'))
                if data.get('name') != name:
                    errors.append(f'Nombre del agente incorrecto: {afile}')
                if not data.get('description') or not data.get('developer_instructions'):
                    errors.append(f'Agente incompleto: {afile}')
                if f'.agents/skills/{name}/SKILL.md' not in data.get('developer_instructions', ''):
                    errors.append(f'Agente no apunta a su skill: {afile}')
                expected = MODEL_COORDINATOR if name == 'plan' else MODEL_WORKER
                if (data.get('model'), data.get('model_reasoning_effort')) != expected:
                    errors.append(f'Modelo o razonamiento incorrecto de {name}: {afile}')
            except Exception as exc:
                errors.append(f'TOML invalido en {afile}: {exc}')
        if not sfile.is_file():
            errors.append(f'Falta skill: {sfile}')
        else:
            text = sfile.read_text(encoding='utf-8')
            # Frontmatter YAML mínimo y límites oficiales de Agent Skills (Anthropic).
            lines = text.splitlines()
            if not lines or lines[0] != '---' or '---' not in lines[1:]:
                errors.append(f'Frontmatter invalido en {sfile}')
            else:
                closing = lines[1:].index('---') + 1
                header = lines[1:closing]
                fields = {}
                for line in header:
                    if ':' in line and not line.lstrip().startswith('#'):
                        key, val = line.split(':', 1)
                        fields[key.strip()] = val.strip().strip('"\'')
                sname = fields.get('name', '')
                desc = fields.get('description', '')
                if sname != name or len(sname) > 64 or not VALID_NAME.fullmatch(sname):
                    errors.append(f'Nombre no valido en frontmatter: {sfile}')
                if not desc or len(desc) > 1024 or '<' in desc or '>' in desc:
                    errors.append(f'Descripcion no valida en frontmatter: {sfile}')
                if not any(x in desc.lower() for x in ('úsala', 'úsalo', 'usa ', 'cuando ', 'para ')):
                    errors.append(f'Descripcion sin contexto de activacion: {sfile}')
                if len(lines) - closing - 1 >= 500:
                    errors.append(f'SKILL.md supera 500 lineas: {sfile}')
                if '## Procedimiento mínimo' not in text or '## Entrega' not in text:
                    errors.append(f'Skill sin procedimiento o entrega: {sfile}')
            if not REF_RE.findall(text):
                errors.append(f'Skill sin referencias: {sfile}')
            for target in REF_RE.findall(text):
                resolved = (sfile.parent / target).resolve()
                if not resolved.is_file():
                    errors.append(f'Enlace roto: {sfile}: {target}')
    config = project_root / '.codex' / 'config.toml'
    if config.exists():
        try:
            data = tomllib.loads(config.read_text(encoding='utf-8'))
            if (data.get('model'), data.get('model_reasoning_effort')) != MODEL_COORDINATOR:
                errors.append(f'Modelo del coordinador incorrecto: {config}')
            ag = data.get('agents', {})
            if (ag.get('default_subagent_model'), ag.get('default_subagent_reasoning_effort')) != MODEL_WORKER:
                errors.append(f'Modelo predeterminado de los subagentes incorrecto: {config}')
            mcp = data.get('mcp_servers', {})
            for extra in ('playwright', 'engram'):
                server = mcp.get(extra)
                if not isinstance(server, dict) or not (server.get('command') or server.get('url')):
                    errors.append(f'Falta servidor MCP {extra} o su comando/URL: {config}')
            ctx = mcp.get('context7', {})
            if ctx and 'auth' in ctx:
                errors.append(f'Context7 usa una clave TOML no documentada (auth): {config}')
            if ctx and not (ctx.get('url') or ctx.get('command')):
                errors.append(f'Context7 necesita url o command: {config}')
        except (ValueError, OSError) as exc:
            errors.append(f'Config de modelos inválida: {config}: {exc}')
    # Valida las integraciones compartidas adicionales y la separación entre
    # la skill de rol, el resolvedor del coordinador y los estándares técnicos.
    for expected in ('skill-resolver.md', 'engram.md', 'handoff.md', 'loading-policy.md', 'python-libraries.md', 'context7.md', 'playwright-mcp.md', 'project-skill-registry.md', 'skill-catalog.md'):
        if not (skills/'_shared'/expected).is_file():
            errors.append(f'Falta referencia compartida: {expected}')
    for required in ('README.md', 'decision-guide.md', 'clean.md', 'hexagonal.md', 'layered.md', 'verification.md'):
        if not (skills/'_shared'/'architecture'/required).is_file():
            errors.append(f'Falta guía de arquitectura compartida: {required}')
    # Registro local real: fuente única para estándares complementarios. Cada regla debe
    # disponer de disparadores comprobables y una referencia completa que exista.
    registry_path = skills / '_shared' / 'project-skill-registry.md'
    resolver_path = skills / '_shared' / 'skill-resolver.md'
    if registry_path.is_file():
        registry_text = registry_path.read_text(encoding='utf-8')
        entries = re.findall(r'(?ms)^### ([a-z0-9]+(?:-[a-z0-9]+)*)\n(.*?)(?=^### |^## |\Z)', registry_text)
        if not entries or len({name for name, _ in entries}) != len(entries):
            errors.append('Registro de skills sin entradas únicas y legibles')
        for name, content in entries:
            for field in ('**Acción:**', '**Rutas/tecnología:**', '**Referencia completa:**', '**Reglas compactas:**'):
                if field not in content:
                    errors.append(f'Regla {name} sin campo obligatorio: {field}')
            if not REF_RE.findall(content):
                errors.append(f'Regla {name} sin referencia concreta')
        # Cinco es el máximo de *selección por delegación*, no el máximo de
        # estándares disponibles en el registro; añadir entradas es legítimo.
        # Separación estricta: ninguna entrada generada puede ser aprobada por accidente.
        if '<!-- BEGIN AUTO-DISCOVERED SKILLS' in registry_text or '## Catálogo descubierto automáticamente' in registry_text:
            errors.append('Los estándares aprobados no pueden contener un catálogo generado')
    catalog_path = skills / '_shared' / 'skill-catalog.md'
    if catalog_path.is_file():
        catalog = catalog_path.read_text(encoding='utf-8')
        if not catalog.startswith('# Catálogo descubierto automáticamente'):
            errors.append('Catálogo sin cabecera generada correcta')
        for target in re.findall(r'(?m)^\| `[^`]+` \| [^\n]* \| `([^`]+/SKILL\.md)` \|$', catalog):
            if not (project_root / target).is_file():
                errors.append(f'Skill del catálogo no encontrada: {target}')
    if registry_path.is_file() and catalog_path.is_file():
        # Detecta catálogo obsoleto sin coste ni dependencias de red.
        import importlib.util
        generator = skills/'skill-creator'/'scripts'/'build_registry.py'
        if generator.is_file():
            try:
                spec = importlib.util.spec_from_file_location('lean_registry_check', generator)
                module = importlib.util.module_from_spec(spec)
                sys.modules[spec.name] = module
                spec.loader.exec_module(module)
                if module.run(project_root, check=True)[0] != 0:
                    errors.append('Catálogo desactualizado: ejecuta build_registry.py')
            except Exception as exc:
                errors.append(f'Imposible verificar catálogo: {exc}')
    if resolver_path.is_file():
        content = resolver_path.read_text(encoding='utf-8')
        if 'project-skill-registry.md' not in content:
            errors.append('El resolvedor no apunta al registro real')
        if 'mem_search(' in content:
            errors.append('El resolvedor intenta recuperar estándares de Engram')
    # Todos los Markdown del paquete deben enlazar a recursos existentes,
    # incluidos README, changelog, protocolos y evaluaciones.
    for md in project_root.rglob('*.md'):
        if any(part.startswith('.bak.') for part in md.parts):
            continue
        for target in REF_RE.findall(md.read_text(encoding='utf-8')):
            if target.startswith(('http://', 'https://')):
                continue
            if not (md.parent / target).resolve().is_file():
                errors.append(f'Enlace Markdown roto: {md.relative_to(project_root)} -> {target}')
    # Terminología heredada induce a buscar archivos que no se instalan.
    for name in ('AGENTS.md', 'README.md', 'EVALUACIONES.md', 'REVIEW_SHARED.md'):
        f = project_root / name
        if f.is_file() and ('.atl/skill-registry.md' in f.read_text(encoding='utf-8') or 'architecture-selection.md' in f.read_text(encoding='utf-8')):
            errors.append(f'Documentación vigente con ruta obsoleta: {name}')
    if not (skills/'skill-creator'/'scripts'/'build_registry.py').is_file():
        errors.append('Falta el generador/auditor de registro de skills')
    if not (skills/'skill-creator'/'references'/'registry-maintenance.md').is_file():
        errors.append('Falta referencia de mantenimiento del catálogo')
    if not (project_root/'scripts'/'git_init.py').is_file():
        errors.append('Falta comando seguro scripts/git_init.py')
    if not (skills/'quality-gate'/'scripts'/'run_gates.py').is_file():
        errors.append('Falta runner determinista del quality-gate')
    snippet = project_root / 'AGENTS.md'
    if not snippet.is_file():
        errors.append(f'Falta punto de entrada AGENTS.md: {snippet}')
    else:
        st = snippet.read_text(encoding='utf-8')
        if 'agent-teams-basic:start' not in st or 'agent-teams-basic:end' not in st:
            errors.append('Marcadores AGENTS.md ausentes')
        if len(st.split()) > 300:
            errors.append('AGENTS.md excede presupuesto lean de 300 palabras')
        for expected in ('project-skill-registry.md', 'skill-catalog.md', 'quality-gate', 'Playwright'):
            if expected not in st:
                errors.append(f'Falta regla esencial en AGENTS.md: {expected}')
    # La skill plan enruta a la operación directa sin exigir lectura de índice previo.
    plan_text = (skills/'plan'/'SKILL.md').read_text(encoding='utf-8') if (skills/'plan'/'SKILL.md').is_file() else ''
    if 'no abras un índice antes' not in plan_text:
        errors.append('plan no evita lectura de índice TODO innecesaria')
    for afile in agents.glob('*.toml'):
        if afile.stem not in REQUIRED:
            continue
        agent = tomllib.loads(afile.read_text(encoding='utf-8'))
        instructions = agent.get('developer_instructions', '')
        if 'Project Standards (auto-resolved)' not in instructions or 'skill_resolution' not in instructions:
            errors.append(f'Agente sin soporte de estándares y handoff: {afile}')
    if (skills/'_shared'/'SKILL.md').exists():
        errors.append('_shared debe ser carpeta auxiliar, no una skill con SKILL.md')
    for link in (skills/'_shared').rglob('*.md'):
        for target in REF_RE.findall(link.read_text(encoding='utf-8')):
            if target.startswith(('https://', 'http://')):
                continue
            if not (link.parent/target).resolve().is_file():
                errors.append(f'Enlace roto compartido: {link}: {target}')
    return errors


def main():
    ap = argparse.ArgumentParser(description='Valida Agent Teams Basic')
    ap.add_argument('--project-root', type=Path, default=Path(__file__).resolve().parent.parent)
    args = ap.parse_args()
    errors = validate(args.project_root)
    if errors:
        print('\n'.join('ERROR '+e for e in errors))
        return 1
    print('OK: 10 agentes y skills lean, estándares + catálogo separados, enlaces, Engram/Context7/Playwright y quality gate')
    return 0

if __name__=='__main__':
    sys.exit(main())
