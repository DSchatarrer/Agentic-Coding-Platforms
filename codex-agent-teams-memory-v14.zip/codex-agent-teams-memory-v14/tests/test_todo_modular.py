"""Tests de enrutamiento progresivo de TODO.md y paquete instalado."""
from pathlib import Path
import tempfile
import unittest
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import install
import validate

MODES = ("create", "audit", "continue", "update", "replan")

class TodoModularTests(unittest.TestCase):
    def test_todo_references_one_level(self):
        base = ROOT / ".agents/skills/plan"
        skill = (base / "SKILL.md").read_text(encoding="utf8")
        router = (base / "references/todo-tracker.md").read_text(encoding="utf8")
        for name in ("tracker", "core", "structure", "evidence", *MODES):
            filename = f"todo-{name}.md"
            self.assertTrue((base / "references" / filename).is_file(), filename)
            self.assertIn(f"references/{filename}", skill)
            self.assertIn("TODO.md", (base / "references" / filename).read_text(encoding="utf8"))
        self.assertIn("solo", router.lower())
        self.assertIn("Mantén el seguimiento según el trabajo solicitado", router)

    def test_all_todo_reference_links_resolve(self):
        import re
        base = ROOT / ".agents/skills/plan/references"
        for ref in base.glob("todo-*.md"):
            for link in re.findall(r"\[[^]]+\]\(([^)]+\.md)\)", ref.read_text(encoding="utf8")):
                self.assertTrue((ref.parent / link).is_file(), f"{ref.name}: {link}")

    def test_action_boundaries_and_no_fake_closure(self):
        base = ROOT / ".agents/skills/plan/references"
        continue_text = (base / "todo-continue.md").read_text(encoding="utf8")
        audit_text = (base / "todo-audit.md").read_text(encoding="utf8")
        evidence = (base / "todo-evidence.md").read_text(encoding="utf8")
        self.assertIn("no implementa código", continue_text.lower())
        self.assertIn("quality-gate", continue_text)
        self.assertIn("solo lectura", audit_text.lower())
        self.assertIn("[x]", evidence)
        self.assertIn("[ ]", evidence)
        self.assertIn("No afirmes", evidence)

    def test_todo_original_rules_preserved(self):
        base = ROOT / ".agents/skills/plan/references"
        combined = "\n".join(p.read_text(encoding="utf8") for p in base.glob("todo-*.md"))
        for rule in (
            "nunca marques como completada una tarea sin evidencia suficiente",
            "trazabilidad", "dependencias", "reproducibilidad", "no regresión",
            "actualizar seguimiento", "## Próxima tarea concreta", "T03a", "Pruebas necesarias",
            "recursos reales o simulados", "No elimines el historial", "CREAR", "AUDITAR", "CONTINUAR",
            "ACTUALIZAR", "REPLANIFICAR"
        ):
            self.assertIn(rule.lower(), combined.lower(), rule)

    def test_installed_modular_refs_and_validation(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            install.install(root)
            self.assertEqual(validate.validate(root), [])
            for name in MODES:
                self.assertTrue((root / f".agents/skills/plan/references/todo-{name}.md").exists())
            (root / ".agents/skills/plan/references/todo-audit.md").unlink()
            self.assertTrue(any("Enlace roto" in e for e in validate.validate(root)))
