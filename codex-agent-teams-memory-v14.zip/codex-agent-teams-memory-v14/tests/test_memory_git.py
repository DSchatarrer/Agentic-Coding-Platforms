"""Verifica higiene documental de memoria e inicialización Git sin efectos sorpresa."""
from pathlib import Path
import importlib.util
import shutil
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'scripts'))
import git_init
import install
import validate


class MemoryPolicyTests(unittest.TestCase):
    def test_memory_policy_on_demand_and_direct_links(self):
        engram = (ROOT / '.agents/skills/_shared/engram.md').read_text(encoding='utf-8')
        self.assertIn('memory/write-policy.md', engram)
        self.assertIn('memory/topic-keys.md', engram)
        self.assertIn('memory/retrieval-policy.md', engram)
        self.assertIn('memory/maintenance.md', engram)
        self.assertIn('mem_get_observation', engram)
        self.assertIn('topic_key', engram)
        self.assertIn('no', (ROOT/'.agents/skills/_shared/memory/write-policy.md').read_text().lower())
        self.assertIn('expected_project', (ROOT/'.agents/skills/_shared/memory/maintenance.md').read_text())

    def test_no_auto_cleanup_and_no_double_write(self):
        base = ROOT / '.agents/skills/_shared'
        policy = (base / 'memory/write-policy.md').read_text(encoding='utf-8')
        maintenance = (base / 'memory/maintenance.md').read_text(encoding='utf-8')
        handoff = (base / 'handoff.md').read_text(encoding='utf-8')
        self.assertIn('no vuelve a guardar', policy)
        self.assertIn('no duplica', handoff)
        self.assertIn('No programar limpieza automática', maintenance)
        self.assertIn('confirmación explícita', maintenance)
        self.assertIn('scope + topic_key', (base/'memory/topic-keys.md').read_text())

    def test_memory_files_installed_and_links_valid(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp)
            install.install(target)
            self.assertTrue((target / 'scripts/git_init.py').is_file())
            for name in ('write-policy.md', 'topic-keys.md', 'retrieval-policy.md', 'maintenance.md'):
                self.assertTrue((target / '.agents/skills/_shared/memory' / name).is_file())
            self.assertEqual(validate.validate(target), [])


@unittest.skipUnless(shutil.which('git'), 'Git no está instalado en el entorno de pruebas')
class GitInitTests(unittest.TestCase):
    def test_create_only_when_missing_and_idempotent(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / 'project'
            root.mkdir()
            message, created = git_init.ensure_git(root)
            self.assertTrue(created, message)
            self.assertTrue((root/'.git').is_dir())
            msg2, created2 = git_init.ensure_git(root)
            self.assertFalse(created2, msg2)
            self.assertIn('ya está', msg2)
            self.assertFalse((root/'.git/HEAD').is_dir())

    def test_dry_run_is_read_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            msg, created=git_init.ensure_git(root,dry_run=True)
            self.assertFalse(created)
            self.assertIn('DRY-RUN',msg)
            self.assertFalse((root/'.git').exists())

    def test_existing_parent_repo_is_never_nested(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            git_init.ensure_git(root)
            nested=root/'src'/'demo';nested.mkdir(parents=True)
            message, created=git_init.ensure_git(nested)
            self.assertFalse(created)
            self.assertIn('repositorio padre',message)
            self.assertFalse((nested/'.git').exists())

    def test_malformed_git_file_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            (root/'.git').write_text('gitdir: /nonexistent-git-dir\n',encoding='utf-8')
            with self.assertRaises(git_init.GitInitError):
                git_init.ensure_git(root)
            self.assertEqual((root/'.git').read_text(), 'gitdir: /nonexistent-git-dir\n')

    def test_installer_does_not_create_git_unless_opt_in(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            install.install(root)
            self.assertFalse((root/'.git').exists())
            logs=install.install(root,init_git=True)
            self.assertTrue((root/'.git').exists())
            self.assertTrue(any('GIT: CREADO' in log for log in logs))

    def test_installed_script_supports_dry_run(self):
        with tempfile.TemporaryDirectory() as pkg, tempfile.TemporaryDirectory() as project:
            target = Path(pkg)
            install.install(target)
            import subprocess
            call = subprocess.run([sys.executable, str(target/'scripts/git_init.py'), '--project-root', project, '--dry-run'], capture_output=True, text=True)
            self.assertEqual(call.returncode, 0, call.stderr)
            self.assertIn('DRY-RUN', call.stdout)
            self.assertFalse((Path(project)/'.git').exists())

    def test_installer_dry_run_with_init_git(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            logs=install.install(root,dry_run=True,init_git=True)
            self.assertTrue(any('DRY-RUN' in log for log in logs))
            self.assertFalse((root/'.git').exists())
            self.assertEqual(list(root.iterdir()), [])

    def test_git_no_commit_no_remote(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            git_init.ensure_git(root)
            import subprocess
            result=subprocess.run(['git','-C',str(root),'rev-list','--count','--all'],capture_output=True,text=True)
            self.assertEqual(result.stdout.strip(),'0')
            remote=subprocess.run(['git','-C',str(root),'remote'],capture_output=True,text=True)
            self.assertEqual(remote.stdout.strip(),'')


if __name__ == '__main__':
    unittest.main()
