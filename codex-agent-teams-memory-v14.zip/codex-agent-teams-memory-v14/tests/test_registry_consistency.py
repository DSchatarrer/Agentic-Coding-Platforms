"""Regresiones de integridad de documentación y registro local."""
import importlib.util
from pathlib import Path
import re
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
spec = importlib.util.spec_from_file_location('consistency_validator', ROOT/'scripts'/'validate.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
spec = importlib.util.spec_from_file_location('consistency_installer', ROOT/'scripts'/'install.py')
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)

class CoherenceTests(unittest.TestCase):
    def test_real_registry_and_single_source(self):
        registry = ROOT/'.agents/skills/_shared/project-skill-registry.md'
        self.assertTrue(registry.is_file())
        resolver = (registry.parent/'skill-resolver.md').read_text(encoding='utf-8')
        self.assertIn('project-skill-registry.md', resolver)
        self.assertNotIn('mem_search(', resolver)
        self.assertIn('estándares aprobados', (ROOT/'AGENTS.md').read_text(encoding='utf-8'))
        self.assertEqual(mod.validate(ROOT), [])

    def test_legacy_registry_not_required(self):
        for name in ('AGENTS.md', 'README.md', 'EVALUACIONES.md'):
            text = (ROOT/name).read_text(encoding='utf-8')
            self.assertNotIn('.atl/skill-registry.md', text)

    def test_missing_registry_detected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); installer.install(root)
            (root/'.agents/skills/_shared/project-skill-registry.md').unlink()
            self.assertTrue(any('project-skill-registry' in error for error in mod.validate(root)))

    def test_missing_entry_field_detected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); installer.install(root)
            registry=root/'.agents/skills/_shared/project-skill-registry.md'
            registry.write_text(registry.read_text(encoding='utf-8').replace('**Acción:**', '**Operacion:**',1),encoding='utf-8')
            self.assertTrue(any('sin campo obligatorio' in error for error in mod.validate(root)))

    def test_broken_reference_in_registry_detected(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); installer.install(root)
            registry=root/'.agents/skills/_shared/project-skill-registry.md'
            registry.write_text(registry.read_text(encoding='utf-8').replace('[python-libraries.md](python-libraries.md)', '[referencia](sin-existir.md)',1),encoding='utf-8')
            self.assertTrue(any('Enlace' in error for error in mod.validate(root)))

    def test_replaced_registry_is_not_silently_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); installer.install(root)
            registry=root/'.agents/skills/_shared/project-skill-registry.md'
            registry.write_text('PERSONALIZADO\n',encoding='utf-8')
            lines=installer.install(root)
            self.assertTrue(any('CONFLICTO' in x and 'project-skill-registry.md' in x for x in lines))
            self.assertEqual(registry.read_text(), 'PERSONALIZADO\n')

    def test_every_role_has_same_execution_status_convention(self):
        skills=ROOT/'.agents/skills'
        for name in mod.REQUIRED:
            text=(skills/name/'SKILL.md').read_text(encoding='utf-8')
            self.assertIn('success|partial|blocked',text,name)
            self.assertIn('quality_gate',text,name)
        handoff=(skills/'_shared/handoff.md').read_text(encoding='utf-8')
        self.assertIn('not_run',handoff)
        self.assertIn('registry-missing',handoff)

    def test_no_stale_linked_documents(self):
        self.assertEqual(mod.validate(ROOT), [])

if __name__ == '__main__': unittest.main()
