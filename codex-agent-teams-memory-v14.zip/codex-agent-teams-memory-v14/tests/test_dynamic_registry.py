"""Contratos deterministas de descubrimiento, catálogo y vigencia de skills."""
from pathlib import Path
import importlib.util
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent.parent
BUILDER = ROOT / '.agents/skills/skill-creator/scripts/build_registry.py'
REGISTRY = Path('.agents/skills/_shared/skill-catalog.md')
STANDARDS = Path('.agents/skills/_shared/project-skill-registry.md')

spec = importlib.util.spec_from_file_location('dynamic_registry_v12', BUILDER)
registry = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = registry
spec.loader.exec_module(registry)

spec = importlib.util.spec_from_file_location('installer_registry_v12', ROOT / 'scripts/install.py')
installer = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = installer
spec.loader.exec_module(installer)


def add_skill(root, name, description='Úsala cuando se diseñen datos', body=''):
    folder = root / '.agents/skills' / name
    folder.mkdir(parents=True, exist_ok=True)
    manifest = folder / 'SKILL.md'
    manifest.write_text(
        f'---\nname: {name}\ndescription: {description}\n---\n# {name}\n{body}',
        encoding='utf-8',
    )
    return manifest


class RegistryTests(unittest.TestCase):
    def test_shipped_catalog_is_current_and_repeatable(self):
        self.assertEqual(registry.run(ROOT, check=True)[0], 0)
        original = (ROOT / REGISTRY).read_bytes()
        self.assertEqual(registry.run(ROOT)[0], 0)
        self.assertEqual((ROOT / REGISTRY).read_bytes(), original)

    def test_add_edit_remove_are_detected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            self.assertEqual(registry.run(root, check=True)[0], 0)
            manifest = add_skill(root, 'new-helper')
            self.assertEqual(registry.run(root, check=True)[0], 1)
            self.assertEqual(registry.run(root)[0], 0)
            data = (root / REGISTRY).read_text(encoding='utf-8')
            self.assertIn('`new-helper`', data)
            self.assertEqual(registry.run(root, check=True)[0], 0)
            manifest.write_text(manifest.read_text(encoding='utf-8').replace('diseñen datos', 'validen datos'), encoding='utf-8')
            self.assertEqual(registry.run(root, check=True)[0], 1)
            registry.run(root)
            self.assertIn('validen datos', (root / REGISTRY).read_text(encoding='utf-8'))
            manifest.unlink()
            self.assertEqual(registry.run(root, check=True)[0], 1)
            registry.run(root)
            self.assertNotIn('`new-helper`', (root / REGISTRY).read_text(encoding='utf-8'))

    def test_preserves_approved_standards_and_reports_missing_registry(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            doc = root / STANDARDS
            content = doc.read_text(encoding='utf-8')
            changed = content.replace('## Cómo utilizarlo', '## Cómo utilizarlo\n\nDECISIÓN APROBADA', 1)
            doc.write_text(changed, encoding='utf-8')
            add_skill(root, 'extra-skill')
            self.assertEqual(registry.run(root)[0], 0)
            self.assertIn('DECISIÓN APROBADA', doc.read_text(encoding='utf-8'))
            self.assertIn('`extra-skill`', (root/REGISTRY).read_text(encoding='utf-8'))
            doc.unlink()
            self.assertEqual(registry.run(root)[0], 2)
            self.assertFalse(doc.exists())

    def test_candidate_rules_not_approved_or_injected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            add_skill(root, 'python-special', 'Usa Python cuando necesites validar módulos',
                      '## Compact Rules\n- Verifica interfaces públicas\n- Evita cambios de API incompatibles\n')
            registry.run(root)
            data = (root / REGISTRY).read_text(encoding='utf-8')
            approved = (root/STANDARDS).read_text(encoding='utf-8').split('## Entradas', 1)[1].split('## Mantenimiento', 1)[0]
            generated = data
            self.assertNotIn('python-special', approved)
            self.assertIn('**python-special** (borrador; no inyectar automáticamente)', generated)
            self.assertIn('Verifica interfaces públicas', generated)
            self.assertIn('Evita cambios de API incompatibles', generated)

    def test_project_priority_and_duplicate_warning(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            add_skill(root, 'foo-skill', 'Prioridad principal')
            second = root / '.claude/skills/foo-skill/SKILL.md'
            second.parent.mkdir(parents=True, exist_ok=True)
            second.write_text('---\nname: foo-skill\ndescription: Prioridad secundaria\n---\n', encoding='utf-8')
            skills, logs = registry.discover(root)
            foo = next(s for s in skills if s.name == 'foo-skill')
            self.assertEqual(foo.description, 'Prioridad principal')
            self.assertTrue(any('DUPLICADA:' in log for log in logs))
            registry.run(root)
            self.assertNotIn('Prioridad secundaria', (root / REGISTRY).read_text(encoding='utf-8'))

    def test_conventions_and_direct_links_are_scanned(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            p = root / 'CONVENTIONS.md'
            p.write_text('Convención adicional', encoding='utf-8')
            agents = root / 'AGENTS.md'
            agents.write_text(agents.read_text(encoding='utf-8') + '\n[Guía](CONVENTIONS.md)\n', encoding='utf-8')
            self.assertEqual(registry.run(root, check=True)[0], 1)
            registry.run(root)
            text = (root / REGISTRY).read_text(encoding='utf-8')
            self.assertIn('`CONVENTIONS.md`', text)
            self.assertIn('Referencia directa de AGENTS.md', text)
            self.assertEqual(registry.run(root, check=True)[0], 0)

    def test_invalid_manifest_fails_check_instead_of_silent_skip(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            bad = add_skill(root, 'bad-skill')
            bad.write_text('# no frontmatter\n', encoding='utf-8')
            code, msg = registry.run(root, check=True)
            self.assertEqual(code, 2)
            self.assertIn('metadatos inválidos', msg)

    def test_scaffold_refreshes_catalog(self):
        source = ROOT / '.agents/skills/skill-creator/scripts/scaffold_skill.py'
        spec = importlib.util.spec_from_file_location('scaffold_registry_v12', source)
        creator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(creator)
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            creator.create_skill(root, 'fresh-thing', 'Úsala cuando se creen cosas')
            self.assertEqual(registry.run(root, check=True)[0], 0)
            self.assertIn('`fresh-thing`', (root / REGISTRY).read_text(encoding='utf-8'))

    def test_global_preview_does_not_persist_paths(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            before = (root / REGISTRY).read_bytes()
            code, message = registry.run(root, include_global=True)
            self.assertEqual(code, 0)
            self.assertIn('NO escritas', message)
            self.assertEqual((root / REGISTRY).read_bytes(), before)

    def test_cli_check_exit_and_missing_catalog_detectable(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            installer.install(root)
            add_skill(root, 'invisible-until-refresh')
            cmd = [sys.executable, str(BUILDER), '--project-root', str(root), '--check']
            proc = subprocess.run(cmd, capture_output=True, text=True, check=False)
            self.assertEqual(proc.returncode, 1)
            self.assertIn('DESACTUALIZADO', proc.stdout)
            (root / REGISTRY).unlink()
            self.assertEqual(registry.run(root, check=True)[0], 1)


if __name__ == '__main__':
    unittest.main()
