"""Regresiones específicas de separación de fuentes y carga progresiva."""
import importlib.util
from pathlib import Path
import tempfile
import unittest
import sys
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT/'scripts'))
import install
import validate
import context_profile

BUILDER = ROOT/'.agents/skills/skill-creator/scripts/build_registry.py'
spec = importlib.util.spec_from_file_location('lean_builder_tests', BUILDER)
build = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = build
spec.loader.exec_module(build)

class LeanTests(unittest.TestCase):
    def test_core_words_and_role_budget(self):
        self.assertLessEqual(len((ROOT/'AGENTS.md').read_text().split()),300)
        for agent in validate.REQUIRED:
            text=(ROOT/f'.agents/skills/{agent}/SKILL.md').read_text(encoding='utf-8')
            self.assertLessEqual(len(text.split()),260)
            self.assertIn('Referencias bajo demanda',text) if agent!='plan' else self.assertIn('Operaciones TODO.md',text)
    def test_split_sources_and_no_injection_of_candidates(self):
        standards=(ROOT/'.agents/skills/_shared/project-skill-registry.md').read_text()
        catalog=(ROOT/'.agents/skills/_shared/skill-catalog.md').read_text()
        self.assertIn('## Entradas',standards)
        self.assertNotIn('## Catálogo descubierto automáticamente',standards)
        self.assertNotIn('## Entradas',catalog)
        self.assertIn('`create`',catalog)
    def test_updates_catalog_only_and_detects_outdated(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); install.install(root)
            standards=root/'.agents/skills/_shared/project-skill-registry.md'
            before=standards.read_bytes()
            sample=root/'.agents/skills/sample/SKILL.md'; sample.parent.mkdir(parents=True)
            sample.write_text('---\nname: sample\ndescription: Se utiliza para una prueba\n---\n# sample\n',encoding='utf8')
            self.assertEqual(build.run(root,check=True)[0],1)
            self.assertTrue(any('Catálogo desactualizado' in x for x in validate.validate(root)))
            self.assertEqual(build.run(root)[0],0)
            self.assertEqual(standards.read_bytes(),before)
            self.assertEqual(build.run(root,check=True)[0],0)
    def test_todo_has_direct_action_route(self):
        role=(ROOT/'.agents/skills/plan/SKILL.md').read_text()
        self.assertIn('no abras un índice antes de ella',role)
        self.assertIn('(references/todo-audit.md)',role)
        self.assertIn('(references/todo-continue.md)',role)
    def test_static_profiles_no_unneeded_initial_refs(self):
        profiles=context_profile.measure(ROOT)
        self.assertLess(profiles['orchestrator_words'],300)
        self.assertEqual(profiles['cases']['typo']['reference_files'],[])
        self.assertNotIn('todo-tracker.md', profiles['cases']['todo-audit']['reference_files'])
        self.assertEqual(profiles['cases']['external-api']['selected_role'],'research')
    def test_installer_idempotent_without_reconfiguring_mcp(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d); install.install(root)
            self.assertEqual(validate.validate(root),[])
            first=(root/'.codex/config.toml').read_bytes()
            install.install(root)
            self.assertEqual(first,(root/'.codex/config.toml').read_bytes())
