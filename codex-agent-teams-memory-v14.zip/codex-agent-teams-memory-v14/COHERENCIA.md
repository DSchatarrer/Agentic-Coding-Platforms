# Contrato de coherencia v13

| Responsabilidad | Fuente única | Cuándo se lee |
|---|---|---|
| Enrutamiento | [AGENTS.md](AGENTS.md) | Inicio |
| Identidad de agente | `.codex/agents/<rol>.toml` | Delegación |
| Procedimiento | `.agents/skills/<rol>/SKILL.md` | Al delegar a rol |
| Estándares aprobados | [project-skill-registry.md](.agents/skills/_shared/project-skill-registry.md) | Solo delegar código |
| Inventario | [skill-catalog.md](.agents/skills/_shared/skill-catalog.md) | Crear/descubrir skills |
| Reglas de resolución | [skill-resolver.md](.agents/skills/_shared/skill-resolver.md) | Dudas de selección |
| Memoria | [engram.md](.agents/skills/_shared/engram.md) | Decisiones pertinentes |
| Handoff extendido | [handoff.md](.agents/skills/_shared/handoff.md) | Entregas complejas |
| Calidad ejecutable | [quality-gate/SKILL.md](.agents/skills/quality-gate/SKILL.md) | Cierre formal |

No hay catálogos Engram alternativos ni estándares generados automáticamente. No leer índices intermedios del TODO antes de conocer la operación. No atribuir `PASS` a un especialista que escribió el código.


## Ampliación v14

- [Engram](.agents/skills/_shared/engram.md) es el único contrato general de memoria; sus referencias `memory/*.md` dividen escritura, evolución, recuperación y mantenimiento **bajo demanda**. Ninguna otra skill debe duplicar estas políticas.
- El orquestador no guarda por segunda vez las observaciones creadas por especialistas; `handoff.md` transporta sus IDs reales.
- El registro de skills sigue en `project-skill-registry.md` y `skill-catalog.md`; Engram no actúa como catálogo alternativo.
- `scripts/git_init.py` tiene una única implementación; `scripts/install.py --init-git` llama a esa función. El instalador también copia el script al proyecto conservando conflictos.
- Git no es obligatorio para instalar ni para que los especialistas funcionen; no hay `git init` implícito.
