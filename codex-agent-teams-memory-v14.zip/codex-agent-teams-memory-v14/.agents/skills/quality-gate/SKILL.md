---
name: quality-gate
description: Verifica evidencias y bloquea entregas; usa al cerrar cambios de código.
---
# Aceptar cambios

## Procedimiento mínimo
1. No modificar código, pruebas ni política. Ejecutar runner con la política aprobada; si falta un requisito obligatorio, BLOCKED, no PASS. Perfil full: `python .agents/skills/quality-gate/scripts/run_gates.py --project-root . --profile full`; critical solo con requisitos configurados y aprobados. Sin política verificada, BLOCKED.
2. No cargues referencias salvo activación específica. Ejecuta las herramientas que necesites, no leas sus scripts completos salvo depuración.

## Referencias bajo demanda
- [aceptación](references/acceptance.md) — criterios y perfiles avanzados.
- [verificación arquitectónica](../_shared/architecture/verification.md) — si política lo exige.
- [Playwright MCP](../_shared/playwright-mcp.md) — solo si gate exige navegador exploratorio.
- [Engram](../_shared/engram.md) — recuperar/guardar decisiones duraderas relevantes.
- [Context7](../_shared/context7.md) — duda externa real de versión/API.
- [Handoff](../_shared/handoff.md) — traspaso complejo o formal.

## Ejemplos de activación
- Sí: una tarea correspondiente a quality-gate.
- No: acciones de otro rol o pasos redundantes.

## Entrega
Estado `success|partial|blocked`; `quality_gate` por separado (`PASS|FAIL|BLOCKED|not_run|not_applicable`). Comunica comandos/resultados reales. Handoff extendido solo si hace falta.
