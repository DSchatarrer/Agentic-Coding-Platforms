# TODO.md — CONTINUAR trabajo existente

**Se activa:** ya existe un `TODO.md` y el usuario solicita avanzar en la siguiente tarea viable o un conjunto concreto.

**Leer:** [todo-core.md](todo-core.md). Leer [todo-evidence.md](todo-evidence.md) solo al validar/cerrar tareas o registrar bloqueos.

## Contrato entre agentes Codex

La skill `plan` **solo selecciona, descompone y coordina el seguimiento**. No implementa código ni se delega a sí misma. Entrega al orquestador un handoff para `create`/`debug`/`refactor`, seguido de `test` y `quality-gate` cuando proceda. Las modificaciones de `TODO.md` se hacen después de recibir resultados comprobables. Si se invoca `plan` de manera aislada, no declarar que se ejecutó la implementación.

## 5. Protocolo de ejecución del equipo (coordinador + especialistas)

**Separación de responsabilidades:** los pasos de implementación y verificación que siguen describen el trabajo que debe delegar el coordinador. No autorizan al agente `plan` a editar código, ejecutar cambios de implementación ni dar por realizadas pruebas ajenas. `plan` registra el estado en `TODO.md` únicamente tras recibir evidencias verificables de los ejecutores.

Cuando se solicite continuar el proyecto, sigue este ciclo.

### Fase 1 — Recuperar contexto

1. Leer `TODO.md`.
2. Leer las especificaciones relacionadas.
3. Revisar la memoria disponible.
4. Inspeccionar el estado actual del código.
5. Identificar cambios recientes relevantes.
6. Detectar inconsistencias entre documento y repositorio.

No confiar únicamente en el estado escrito si puede contrastarse con el código.

### Fase 2 — Seleccionar trabajo

1. Identificar la siguiente tarea pendiente y ejecutable.
2. Comprobar sus dependencias.
3. Revisar sus criterios de aceptación.
4. Desglosarla cuando sea demasiado amplia.
5. Identificar las pruebas necesarias.

Respetar las prioridades, salvo que exista una razón técnica justificada para alterar el orden.

### Fase 3 — Implementar

1. Realizar los cambios necesarios.
2. Reutilizar el código y arquitectura existentes cuando resulte apropiado.
3. Evitar cambios no relacionados.
4. Conservar compatibilidad cuando sea un requisito.
5. Añadir o actualizar las pruebas pertinentes.
6. No introducir credenciales en documentación, código generado ni evidencias.

No declarar éxito por el mero hecho de haber escrito código.

### Fase 4 — Verificar

Aplicar las verificaciones adecuadas al proyecto:

- Validación sintáctica.
- Pruebas unitarias.
- Pruebas de integración.
- Pruebas de regresión.
- Pruebas de concurrencia cuando corresponda.
- Comprobación de contratos y formatos.
- Pruebas end-to-end si son pertinentes.
- Verificación en sistemas reales cuando sea posible.

No todas las tareas necesitan todas las categorías de prueba.

No sustituyas silenciosamente una prueba real por un mock.

Si una comprobación no puede ejecutarse, registra el motivo.

### Fase 5 — Actualizar seguimiento

Al terminar:

1. Actualiza la tarea y sus subtareas.
2. Marca `[x]` solo si se cumplen los criterios de aceptación.
3. Registra evidencias concretas.
4. Conserva pendientes que sigan abiertos.
5. Actualiza bloqueos, decisiones y riesgos.
6. Recalcula la próxima tarea.
7. Verifica la coherencia del documento completo.

Si la implementación es parcial, explica exactamente qué falta.

### Fase 6 — Comunicar resultados

Informa brevemente de:

- Qué se ha realizado.
- Qué tareas se han cerrado.
- Qué se ha comprobado.
- Qué no se ha podido comprobar.
- Qué bloqueos permanecen.
- Qué tarea corresponde después.

Evita presentar previsiones como hechos consumados.

---

## Evidencias entre especialistas

Para cerrar tareas, el coordinador debe pasar al responsable del `TODO.md` los IDs de tareas, rutas modificadas, comandos y salidas reales, entorno, fallos, cobertura/quality-gate aplicable y pendientes. Si falta información, conservar `[ ]` e identificar lo que impide marcar `[x]`.
