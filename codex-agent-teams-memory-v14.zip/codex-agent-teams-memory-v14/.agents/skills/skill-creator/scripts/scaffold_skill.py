#!/usr/bin/env python3
"""Simple no-clobber project skill scaffold; optional Codex agent."""
from pathlib import Path
import argparse
import re
import subprocess
import sys

NAME = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')


def create_skill(project, name, description, *, with_agent=False, dry_run=False):
    project = Path(project).resolve()
    if not NAME.fullmatch(name) or len(name) > 64:
        raise ValueError('Nombre no válido: usa a-z, 0-9, guiones')
    if not description.strip() or len(description) > 1024 or '\n' in description:
        raise ValueError('Descripción inválida')
    skill = project/'.agents'/'skills'/name/'SKILL.md'
    agent = project/'.codex'/'agents'/f'{name}.toml'
    reference = skill.parent/'references'/'guidance.md'
    paths = [skill, reference] + ([agent] if with_agent else [])
    if any(p.exists() for p in paths):
        raise FileExistsError('Ya existe un archivo de skill o agente. Se prohíbe sobrescribir.')
    if dry_run:
        return paths
    skill.parent.mkdir(parents=True, exist_ok=True)
    skill.write_text(f'''---\nname: {name}\ndescription: {description.strip()}\n---\n# {name}\n\n## Procedimiento mínimo\n1. Define aceptación observable.\n2. Ejecuta trabajo y valida.\n3. Lee [guidance.md](references/guidance.md) **solo si** el trabajo tiene variantes, límites o decisiones que requieran criterios detallados.\n\n## Entrega\nEstado de tarea `success|partial|blocked`, `quality_gate` separado y evidencias ejecutadas.\n''', encoding='utf8')
    reference.parent.mkdir(parents=True, exist_ok=True)
    reference.write_text(f'''# Guía condicional de {name}\n\nEste fichero es un **esqueleto**, no una norma técnica ya aprobada. Completar con decisiones específicas del dominio y ejemplos comprobables antes de usarlo para tareas complejas.\n\n## Cuándo cargar\nSolo si la skill requiere resolver una variante técnica no cubierta por el procedimiento mínimo. No cargarlo para tareas triviales.\n\n## Qué documentar\n- Disparadores verificables de activación y exclusión.\n- Contratos, restricciones y aceptación observable.\n- Ejemplos contrastados y pruebas reales.\n''', encoding='utf8')
    if with_agent:
        agent.parent.mkdir(parents=True, exist_ok=True)
        agent.write_text(f'''name = "{name}"\ndescription = "Agente especializado para {name}"\nmodel = "gpt-6-sol"\nmodel_reasoning_effort = "low"\ndeveloper_instructions = """Lee .agents/skills/{name}/SKILL.md antes de actuar. No delegues. Registra comandos reales."""\n''', encoding='utf8')
    # Actualiza el inventario en proyectos que tengan instalado este paquete.
    # Nunca cambia normas aprobadas, solo el bloque generado. No crea un
    # registro alternativo ni depende de Engram. Si no está instalado,
    # el scaffold sigue siendo independiente y no modifica otras rutas.
    builder = project/'.agents/skills/skill-creator/scripts/build_registry.py'
    registry = project/'.agents/skills/_shared/project-skill-registry.md'
    if builder.is_file() and registry.is_file():
        result = subprocess.run([sys.executable, str(builder), '--project-root', str(project)],
                                capture_output=True, text=True, check=False)
        if result.returncode:
            raise RuntimeError(f'Skill creada, pero el catálogo no pudo actualizarse: {result.stdout} {result.stderr}')
    return paths


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('name');ap.add_argument('description');ap.add_argument('--project-root',default='.')
    ap.add_argument('--with-agent',action='store_true');ap.add_argument('--dry-run',action='store_true')
    a=ap.parse_args()
    for p in create_skill(a.project_root,a.name,a.description,with_agent=a.with_agent,dry_run=a.dry_run): print(p)
if __name__ == '__main__': main()
