# Mantenimiento del catálogo

- [estándares aprobados](../../_shared/project-skill-registry.md): decisiones humanas, nunca se regeneran automáticamente.
- [catálogo autogenerado](../../_shared/skill-catalog.md): inventario informativo de skills/convenciones. No inyectar candidatas sin revisión.

```bash
python .agents/skills/skill-creator/scripts/build_registry.py --project-root .
python .agents/skills/skill-creator/scripts/build_registry.py --project-root . --check
```

Tras añadir, editar o eliminar SKILL.md refrescar. Se detectan duplicados y errores de metadatos. Las reglas candidatas de `## Compact Rules` se revisan antes de promoverlas manualmente a la sección `## Entradas` del registro aprobado. Las rutas globales solo se muestran en vista previa, no se persisten.
