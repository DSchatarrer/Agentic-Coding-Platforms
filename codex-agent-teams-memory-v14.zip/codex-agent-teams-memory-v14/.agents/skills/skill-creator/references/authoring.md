# Autoría y evolución de skills para Codex

Esta referencia se consulta **solo** al crear, modificar o auditar el diseño de una skill; no es normativa para el resto de agentes.

## Delimitación

1. Definir exactamente **cuándo se activa** y cuándo no; descripción corta que permita su descubrimiento.
2. Separar **agente** (TOML: modelo, instrucciones y delegación) de **skill** (`SKILL.md`: procedimiento y referencias). La nueva skill no necesita un TOML si no se va a delegar como subagente.
3. Mantener `SKILL.md` autocontenido para lo esencial: objetivo, procedimiento mínimo, disparadores para referencias y entregable verificable.
4. Poner casos largos, tecnologías, decisiones de diseño y ejemplos detallados en `references/`; no hacer lectura en cascada obligatoria ni copiar todas las referencias al prompt.
5. Crear scripts solo para operaciones deterministas repetibles, con argumentos explícitos, validación de entradas, salida comprobable y comportamiento seguro frente a sobrescrituras.

## Integración con el equipo

- Si se añade **solo una skill especializada**, puede quedar en `.agents/skills/<nombre>/SKILL.md` sin un agente propio. Si el usuario requiere un especialista delegable, crear `.codex/agents/<nombre>.toml` que ordene leer ese archivo.
- Tras cambios en skills, ejecutar `python .agents/skills/skill-creator/scripts/build_registry.py --project-root .` para actualizar el catálogo. El flujo de mantenimiento está enlazado directamente desde SKILL.md si se necesita.
- Para normas complementarias que apliquen a **varios roles**, consultar y, si procede, ampliar `## Entradas` del [registro local](../../_shared/project-skill-registry.md); una skill nueva no equivale automáticamente a un estándar aprobado.
- Engram conserva decisiones duraderas, no reemplaza el registro ni los archivos actuales.
- Respetar la convención de [handoff](../../_shared/handoff.md) y el estado de calidad independiente cuando el rol produce código.

## Verificación

- Probar activación **positiva** (la skill se escoge para una tarea representativa) y **negativa** (no se carga para tarea ajena).
- Confirmar la apertura bajo demanda y que las referencias enlazadas existen.
- Verificar que el generador no sobrescriba skills de usuario.
- Ejecutar `python scripts/validate.py --project-root .` y `python -m unittest discover -s tests -q` en el paquete; `validate_skill.py` para la skill creada.
- **Limitación:** las pruebas estáticas no acreditan que Codex haya cargado efectivamente la skill ni que MCP funcione en el equipo del usuario.
