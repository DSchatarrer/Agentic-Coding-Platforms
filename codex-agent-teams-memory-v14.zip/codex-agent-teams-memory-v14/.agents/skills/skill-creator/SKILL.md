---
name: skill-creator
description: Crea y valida skills; usa cuando se soliciten nuevas skills o agentes.
---
# Mantener skills

## Procedimiento mínimo
1. Crear/validar sin sobreescribir. Tras altas/bajas/ediciones ejecutar scripts/build_registry.py --project-root .; el catálogo no aprueba reglas. No crear TOML de subagente salvo solicitud explícita.
2. No cargues referencias salvo activación específica. Ejecuta las herramientas que necesites, no leas sus scripts completos salvo depuración.

## Referencias bajo demanda
- [autoría](../_shared/skill-authoring.md) — diseñar skills y referencias.
- [referencias de autoría](references/authoring.md) — caso complejo.
- [mantenimiento de catálogo](references/registry-maintenance.md) — crear/auditar catálogo.
- [estándares aprobados](../_shared/project-skill-registry.md) — solo promover norma revisada.
- [Engram](../_shared/engram.md) — recuperar/guardar decisiones duraderas relevantes.
- [Context7](../_shared/context7.md) — duda externa real de versión/API.
- [Handoff](../_shared/handoff.md) — traspaso complejo o formal.

## Ejemplos de activación
- Sí: una tarea correspondiente a skill-creator.
- No: acciones de otro rol o pasos redundantes.

## Entrega
Estado `success|partial|blocked`; `quality_gate` por separado (`PASS|FAIL|BLOCKED|not_run|not_applicable`). Comunica comandos/resultados reales. Handoff extendido solo si hace falta.
