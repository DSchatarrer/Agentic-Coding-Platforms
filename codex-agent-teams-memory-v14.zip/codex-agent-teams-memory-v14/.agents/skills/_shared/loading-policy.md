# Carga progresiva

1. Coordinador: solo `AGENTS.md`; no precargar catálogos, SKILL.md ni referencias.
2. Antes de delegar **código**, consulta `## Entradas` de [estándares](project-skill-registry.md). Abre [resolvedor](skill-resolver.md) ante dudas. El [catálogo](skill-catalog.md) se usa **solo** al descubrir skills, no rutinariamente.
3. Especialista: lee su `SKILL.md` propio; abre únicamente las referencias enlazadas directamente cuyo disparador aplique. Nunca cargar índices intermedios por defecto.
4. Herramientas externas: Engram/Context7/Playwright solo cuando el caso las requiere. Para Engram, aplicar su contrato de filtrado, deduplicación y recuperación selectiva; no leer todas las subreferencias de memoria por defecto. Scripts deterministas se **ejecutan**, no se cargan completos en contexto.
5. No cargar referencias ausentes ni inferir resultados de herramientas no ejecutadas.
