# Guía breve para crear y actualizar skills

- Cada skill de rol tiene `SKILL.md` con frontmatter `name` y `description` que indiquen **cuándo** usarla, un procedimiento mínimo y una entrega verificable.
- El archivo de agente `.codex/agents/<rol>.toml` enlaza explícitamente a la skill; un `SKILL.md` por sí solo no crea un subagente.
- Mantén el `SKILL.md` corto; referencias de arquitectura, ejemplos y procedimientos largos bajo `references/` o `_shared/` con disparadores precisos.
- Evita referencias circulares o inexistentes. Para referencias generales reutiliza `_shared` y no dupliques su contenido.
- Después de crear/editar/eliminar una skill, actualiza el inventario con `python .agents/skills/skill-creator/scripts/build_registry.py --project-root .`. Esto **sí registra automáticamente** skills disponibles, pero no las aprueba como estándares.
- Si la skill añade una regla **transversal** útil para otras delegaciones de código, edita de forma explícita `## Entradas` en [project-skill-registry.md](project-skill-registry.md); el generador nunca cambia esas normas.
- Verifica con `python scripts/validate.py --project-root .` y los tests. Las pruebas de invocación/no invocación y MCP requieren Codex real.
