# Engram — memoria compartida curada

**Fuente de verdad:** repositorio, código, pruebas y documentos vigentes. Engram conserva decisiones, causas raíz y patrones reutilizables; **no** es un historial de cada acción, ni un almacén de logs, resultados de pruebas, secretos o copias de archivos.

1. Usa solo el Engram local disponible vía MCP; descubre los nombres y esquemas reales. `mem_current_project` si necesitas confirmar el proyecto; busca memorias pertinentes con `mem_search` y abre con `mem_get_observation` antes de fiarte del contenido. Verifica vigencia contra Git/código. Si no está disponible, informa `unavailable` sin bloquear modificar código ni el trabajo ordinario.
2. **Antes de guardar**, exige valor duradero, verificación suficiente, ausencia de otra fuente mejor y búsqueda de duplicados. Sigue [filtro de escritura](memory/write-policy.md) solo si aparece conocimiento que merezca persistir.
3. Para una decisión o configuración evolutiva, reutiliza `topic_key` estable y, si el MCP lo admite, usa `mem_save` (upsert) o `mem_update` con los argumentos y comprobaciones exigidos por la versión. Consulta [claves y revisiones](memory/topic-keys.md) cuando vayas a actualizar.
4. Recupera lo mínimo para la tarea: [política de recuperación](memory/retrieval-policy.md) solo cuando la búsqueda sea compleja. No inyectes memorias extensas en todos los subagentes.
5. **Mantenimiento**: [revisión y consolidación](memory/maintenance.md) solo si se pide limpieza, aparece una contradicción o se detecta crecimiento anómalo. Nunca hagas borrados o consolidaciones destructivas sin vista previa y autorización.
6. El especialista que descubre algo duradero lo guarda **una sola vez** y pasa el ID real al coordinador; este no duplica el guardado. No inventes claves, tipos, IDs ni llamadas. Para integrar Engram en tu equipo, `engram setup codex` y comprobar `codex mcp list`.

Referencias: [Engram oficial](https://github.com/Gentleman-Programming/engram) y [documentación MCP](https://github.com/Gentleman-Programming/engram/blob/main/DOCS.md). Los perfiles MCP y esquemas pueden variar según la versión local.
