# v14 — Diseño de memoria y Git

## Por qué

La v13 recuperaba memoria correctamente, pero no distinguía explícitamente una observación reutilizable de un resultado transitorio, ni imponía buscar duplicados antes del guardado. Esta versión añade controles de **comportamiento**, sin tocar la base SQLite ni pretender purgar memorias locales.

## Responsabilidades

| Archivo | Cargar cuando |
|---|---|
| `.agents/skills/_shared/engram.md` | Un especialista necesite consultar o guardar memoria |
| `memory/write-policy.md` | Encuentre conocimiento potencialmente duradero |
| `memory/topic-keys.md` | Prepare un upsert o revisión de observación evolutiva |
| `memory/retrieval-policy.md` | Busque antecedentes o tenga resultados ambiguos |
| `memory/maintenance.md` | El usuario pida limpieza, haya contradicción o crecimiento anómalo |

El coordinador no duplica los guardados de especialistas. `topic_key` se combina con proyecto y scope según la versión actual de Engram: las claves no deben incluir identificadores aleatorios o nombres de agentes. Nunca eliminar por antigüedad ni consolidar sin inspección previa.

## Git

- `scripts/git_init.py`: comando independiente, sin dependencias de terceros, solo Git y biblioteca estándar.
- `scripts/install.py --init-git`: opt-in equivalente tras la instalación.
- Ambos detectan un repositorio existente en el directorio o en sus padres, respetan `--dry-run`, y bloquean estados ambiguos.
- No crean un remoto, commit, `.gitignore` ni cambian la rama inicial configurada por Git.

## Verificación

La batería `python -m unittest discover -s tests -q` valida scripts e integridad; `python scripts/validate.py --project-root .` verifica referencias. No se afirma que la base Engram del usuario haya sido consolidada o modificada.
