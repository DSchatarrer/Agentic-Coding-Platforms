# Compatibilidad — I Have ADHD + Agent Teams Lean (Claude Code)

**Alcance:** modo opcional de presentación de la respuesta **al usuario** tras `/i-have-adhd`. No presupone ningún diagnóstico, ni cambia los modelos, agentes, permisos, herramientas, decisiones, pruebas, aceptación o reglas de Ponytail.

## Invocación y duración

- Invocar en Claude Code con `/i-have-adhd` (puede acompañarse de una petición). Sin invocación explícita **no se activa**. Mencionar la expresión en otro texto no equivale a invocación.
- Según la skill original, el estilo permanece durante los turnos siguientes de **esa conversación** hasta `stop adhd mode` o `normal mode`. También se entiende «desactiva el modo ADHD». La persistencia depende de que Claude conserve las instrucciones en contexto, no de un estado externo garantizado. Si se pierden tras compactación, volver a invocar la skill.
- No se instalan hooks ni el plugin global; para desactivarlo solo en la conversación, usar `normal mode`. Un plugin instalado globalmente puede operar aparte: revisar `/plugin` y `/hooks` si se duplican comportamientos.

## Contratos superiores e integridad

1. El **orquestador** aplica el modo a su salida pública. Los diez especialistas mantienen sus instrucciones y el handoff habitual: no se precarga `i-have-adhd` en los subagentes ni se inyecta como norma de ingeniería.
2. La petición de respuesta completa, explicación detallada, formato específico y los requisitos de seguridad tienen prioridad. El máximo de cinco elementos afecta a **cómo mostrar** la información, no a la investigación, los resultados, cobertura ni registros originales.
3. Conservar literalmente código, JSON, SQL, comandos, diffs, rutas, parámetros y payloads contractuales. No acortar logs que sean evidencia de fallos; se permiten extractos públicos identificados si el artefacto completo queda disponible.
4. No ocultar `status`, `quality_gate`, `success|partial|blocked`, `PASS|FAIL|BLOCKED|not_run|not_applicable`, pruebas ejecutadas/fallidas/no ejecutadas, exit codes, archivos ni bloqueos/riesgos relevantes. Nunca convertir pruebas `not_run` en `PASS`.
5. La indicación upstream sobre estimaciones de tiempo se dirige a **acciones del usuario** cuando una estimación sea justificable; no prometer ejecución asíncrona del agente, ni inventar tiempos.
6. Ponytail sigue gestionando el **cambio mínimo completo**, independientemente del formato del mensaje. Se conservan cinco estándares aprobados y el Quality Gate separado.

El contrato técnico base sigue siendo [handoff.md](../../_shared/handoff.md).
